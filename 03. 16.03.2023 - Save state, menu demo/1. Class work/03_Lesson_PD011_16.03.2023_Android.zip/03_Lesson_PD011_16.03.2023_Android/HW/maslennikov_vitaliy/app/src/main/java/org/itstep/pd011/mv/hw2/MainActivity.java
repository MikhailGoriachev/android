package org.itstep.pd011.mv.hw2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.itstep.pd011.mv.hw2.activities.PetActivity;
import org.itstep.pd011.mv.hw2.activities.ShipActivity;
import org.itstep.pd011.mv.hw2.models.Pet;
import org.itstep.pd011.mv.hw2.models.Ship;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // коды активностей для вызова
    public static final int ID_PET_ACTIVITY = 1010, ID_SHIP_ACTIVITY = 1020;

    // коды завершения работы активности
    public static final int RESULT_OK = 0, RESULT_ERR = 1;



    private Pet pet;
    private Ship ship;

    private Button btnPetActivity, btnShipActivity, btnExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pet = new Pet();
        ship = new Ship();

        btnPetActivity = findViewById(R.id.btnPetActivity);
        btnShipActivity = findViewById(R.id.btnShipActivity);
        btnExit = findViewById(R.id.btnExit);

        btnPetActivity.setOnClickListener(v -> startPetActivity());
        btnShipActivity.setOnClickListener(v -> startShipActivity());
        btnExit.setOnClickListener(v -> finish());

        updatePetInfo(pet);
        updateShipInfo(ship);
    }

    private void startPetActivity() {
        Intent intent = new Intent(this, PetActivity.class);

        intent.putExtra(Pet.class.getCanonicalName(), pet);

        startActivityForResult(intent, ID_PET_ACTIVITY);
    }

    private void startShipActivity() {
        Intent intent = new Intent(this, ShipActivity.class);

        intent.putExtra(Ship.class.getCanonicalName(), ship);

        startActivityForResult(intent, ID_SHIP_ACTIVITY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK) {
            Toast.makeText(this,
                            String.format(Locale.UK, "Ошибка %d в активности с кодом %d", resultCode, requestCode),
                            Toast.LENGTH_LONG)
                    .show();
            return;
        }

        if(data == null)
            return;

        switch (requestCode) {
            case ID_PET_ACTIVITY:
                pet = data.getParcelableExtra(Pet.class.getCanonicalName());
                updatePetInfo(pet);
                break;
            case ID_SHIP_ACTIVITY:
                ship = data.getParcelableExtra(Ship.class.getCanonicalName());
                updateShipInfo(ship);
                break;
        }
    }

    private void updatePetInfo(Pet pet) {
        ((TextView) findViewById(R.id.txvPetName)).setText(pet.getName());
        ((TextView) findViewById(R.id.txvPetBreed)).setText(pet.getBreed());
        ((TextView) findViewById(R.id.txvPetOwner)).setText(pet.getOwner());
        ((TextView) findViewById(R.id.txvPetAge)).setText(String.valueOf(pet.getAge()));
        ((TextView) findViewById(R.id.txvPetWeight)).setText(String.valueOf(pet.getWeight()));
    }

    private void updateShipInfo(Ship ship) {
        ((TextView) findViewById(R.id.txvShipType)).setText(String.valueOf(ship.getType()));
        ((TextView) findViewById(R.id.txvShipCargoType)).setText(ship.getCargoType());
        ((TextView) findViewById(R.id.txvShipDestination)).setText(ship.getDestination());
        ((TextView) findViewById(R.id.txvShipCargoWeight)).setText(String.valueOf(ship.getCargoWeight()));
        ((TextView) findViewById(R.id.txvShipCapacity)).setText(String.valueOf(ship.getCapacity()));
        ((TextView) findViewById(R.id.txvShipCargoCostPerTon)).setText(String.valueOf(ship.getCostPerTon()));
    }
}