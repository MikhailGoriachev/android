package org.itstep.pd011.step160323.activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.adapters.ShipsOptimizedAdapter;
import org.itstep.pd011.step160323.models.Animal;
import org.itstep.pd011.step160323.models.Ship;
import org.itstep.pd011.step160323.models.TypeShip;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ShipsOptimizedActivity extends AppCompatActivity {

    List<Ship> ships;
    private int position;

    public static final int
            ID_SHIP_ACTIVITY = 1020;

    private ShipsOptimizedAdapter shipsOptimizedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ships_optimized);

        initializer();

        ListView listView = findViewById(R.id.lsvShipsOptimizedAdapter);

        shipsOptimizedAdapter = new ShipsOptimizedAdapter(
                this,
                R.layout.ship_item_action,
                ships, this::startShipsActivity
        );

        listView.setAdapter(shipsOptimizedAdapter);
    }

    private void initializer(){

        ships = new ArrayList<>();

        for (int i = 0; i<9; ++i){
            ships.add(Ship.generate());
        }
    }

    // обработчик клика по кнопке вызова активности для Ships
    private void startShipsActivity(int pos){

        position = pos;
        Intent intent = new Intent(this, ShipsActivity.class);

        // передача параметра в активность
        intent.putExtra(Ship.class.getCanonicalName(), ships.get(pos));

        // запуск активнсти с возвратом результата
        startActivityForResult(intent,ID_SHIP_ACTIVITY);
    }

    // обработчик события получения данных из другой активности
    // (функция обратного вызова)
    // requestCode - идентфикатор активности
    // resultCode - код завершения работы в активности
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK) {
            Toast.makeText(this,
                            String.format(Locale.UK, "Ошибка %d в активности с кодом %d", resultCode, requestCode),
                            Toast.LENGTH_LONG)
                    .show();
            return;
        } // if

        // при успешной работе активностей - принять данные
        if (requestCode == ID_SHIP_ACTIVITY) {
            assert data != null;
            Ship ship = data.getParcelableExtra(Ship.class.getCanonicalName());

            ships.set(position,ship);
            shipsOptimizedAdapter.myNotifyDataSetChanged();
        }
    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected
}