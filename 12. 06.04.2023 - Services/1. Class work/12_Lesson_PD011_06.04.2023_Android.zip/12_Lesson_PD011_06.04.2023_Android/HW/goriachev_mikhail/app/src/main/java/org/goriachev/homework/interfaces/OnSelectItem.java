package org.goriachev.homework.interfaces;

interface OnSelectItem<T> {
    void onSelectItem(T value);
}
