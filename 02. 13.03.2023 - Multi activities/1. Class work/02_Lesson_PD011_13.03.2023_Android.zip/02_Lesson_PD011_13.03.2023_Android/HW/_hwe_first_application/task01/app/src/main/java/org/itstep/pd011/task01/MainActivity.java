package org.itstep.pd011.task01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.itstep.pd011.task01.models.Triangle;

import java.util.Locale;

/*
 * Разработайте приложение с одной активностью для расчета треугольника.
 * Используйте LinearLayout с вертикальной ориентацией, три расположенных
 * один под другим элемента TextView для отображения длин сторон треугольника,
 * три кнопки Button для вычисления площади и периметра треугольника,
 * формирования сторон треугольника генератором случайных чисел. Обработчик
 * клика назначайте в файле разметки. Выводите рассчитанные величины в два
 * TextView, размещенные выше кнопок. Конечно же, используйте модель – класс
 * для треугольника.
 * */
public class MainActivity extends AppCompatActivity {

    private Triangle triangle;

    // элементы вывода текстовых строк
    private TextView txvSideA, txvSideB, txvSideC, txvPerimeter, txvArea;

    // кнопки вычисления площади и периметра
    private Button btnCalcPerimeter, btnCalcArea;

    // обработчик события создание активности
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // создание объекта
        triangle = new Triangle();

        // получение ссылок на элементы интерфейса для отображения значений сторон
        // и вычисленных значений площади и периметра
        txvSideA = findViewById(R.id.txvSideA);
        txvSideB = findViewById(R.id.txvSideB);
        txvSideC = findViewById(R.id.txvSideC);
        txvPerimeter = findViewById(R.id.txvPerimeter);
        txvArea = findViewById(R.id.txvArea);

        // получение ссылок на конпки
        btnCalcPerimeter = findViewById(R.id.btnCalcPerimeter);
        btnCalcArea = findViewById(R.id.btnCalcArea);
    } // onCreate

    // обработчик клика по кнопке "Генерация сторон"
    public void generateSidesClick(View view) {
        final double LO = 0.1, HI = 10.;
        double a, b, c;

        // генерация корректных данных - длин сторон треугольника
        do {
            a = Utils.getRandom(LO, HI);
            b = Utils.getRandom(LO, HI);
            c = Utils.getRandom(LO, HI);
        } while(!Utils.isTriangle(a, b, c));

        // установить новые значения, вывести их в элементы интерфейса
        triangle.setSides(a, b, c);
        txvSideA.setText(String.format(Locale.UK,"Сторона A: %.3f", a));
        txvSideB.setText(String.format(Locale.UK,"Сторона B: %.3f", b));
        txvSideC.setText(String.format(Locale.UK,"Сторона C: %.3f", c));
        txvPerimeter.setText("Периметр:");
        txvArea.setText("Площадь:");

        // разрешить использование кнопок
        btnCalcArea.setEnabled(true);
        btnCalcPerimeter.setEnabled(true);
    } // generateSidesClick

    // обработчик клика по кнопке "Вычислить периметр"
    public void calcPerimeterClick(View view) {
        double perimeter = triangle.perimeter();
        txvPerimeter.setText(String.format(Locale.UK,"Периметр: %.3f", perimeter));
    } // calcPerimeter

    // обработчик клика по кнопке "Вычислить площадь"
    public void calcAreaClick(View view) {
        double area = triangle.area();
        txvArea.setText(String.format(Locale.UK, "Площадь: %.3f", area));
    } // calcArea
} // class MainActivity