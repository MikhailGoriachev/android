package org.itstep.pd011.step270323.models;

import androidx.annotation.NonNull;

public class Comment {

    private long postId;
    private long id;
    private String name;
    private String email;
    private String body;

    public Comment(long postId, long id, String name, String email, String body) {
        this.postId = postId;
        this.id = id;
        this.name = name;
        this.email = email;
        this.body = body;
    }

    public long getPostId() {
        return postId;
    }

    public void setPostId(long postId) {
        this.postId = postId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    @NonNull
    @Override
    public String toString() {
        return
                "Id поста: " + postId + "\n" +
                "Id коментария: " + id + "\n" +
                "Имя отправителя: " + name + "\n" +
                "email: " + email + "\n" +
                "Текст: " + body;
    }
}
