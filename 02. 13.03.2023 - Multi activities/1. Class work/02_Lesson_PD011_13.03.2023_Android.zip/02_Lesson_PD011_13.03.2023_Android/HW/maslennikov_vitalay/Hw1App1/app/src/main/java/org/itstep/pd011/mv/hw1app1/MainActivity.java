package org.itstep.pd011.mv.hw1app1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.itstep.pd011.mv.hw1app1.models.Triangle;

import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView txvSideA, txvSideB, txvSideC, txvPerimeter, txvArea;
    private Button btnGenerate, btnCalcPerimeter, btnCalcArea, btnExit;
    private Triangle triangle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        triangle = new Triangle(1, 1, 1);

        txvSideA = findViewById(R.id.txvSideA);
        txvSideB = findViewById(R.id.txvSideB);
        txvSideC = findViewById(R.id.txvSideC);
        txvPerimeter = findViewById(R.id.txvPerimeter);
        txvArea = findViewById(R.id.txvArea);
        btnGenerate = findViewById(R.id.btnGenerate);
        btnCalcPerimeter = findViewById(R.id.btnCalcPerimeter);
        btnCalcArea = findViewById(R.id.btnCalcArea);
        btnExit = findViewById(R.id.btnExit);

        btnGenerate.setOnClickListener(this::onGenerateButtonClick);
        btnCalcPerimeter.setOnClickListener(this::onPerimeterButtonClick);
        btnCalcArea.setOnClickListener(this::onAreaButtonClick);
        btnExit.setOnClickListener(this::onExitButtonClick);
    }

    private void onGenerateButtonClick(View view) {
        double minSide = 1, maxSide = 10;
        double sideA = getRandomDouble(minSide, maxSide);
        double sideB = getRandomDouble(minSide, maxSide);
        double sideC = getRandomDouble(minSide, maxSide);



        txvSideA.setText(String.format(Locale.UK,"Сторона A: %.2f", sideA));
        txvSideB.setText(String.format(Locale.UK,"Сторона B: %.2f", sideB));
        txvSideC.setText(String.format(Locale.UK,"Сторона C: %.2f", sideC));
        txvPerimeter.setText("Периметр:");
        txvArea.setText("Площадь:");
    }

    private void onPerimeterButtonClick(View view) {
        if (triangle != null) {
            double perimeter = triangle.getPerimeter();
            txvPerimeter.setText(String.format(Locale.UK,"Периметр: %.2f", perimeter));
        }
    }

    private void onAreaButtonClick(View view) {
        double area = triangle.getArea();
        txvArea.setText(String.format(Locale.UK,"Площадь: %.2f", area));
    }

    private void onExitButtonClick(View view) {
        finish();
    }


    public static double getRandomDouble(double min, double max) {
        return Math.random() * (max - min) + min;
    }
}