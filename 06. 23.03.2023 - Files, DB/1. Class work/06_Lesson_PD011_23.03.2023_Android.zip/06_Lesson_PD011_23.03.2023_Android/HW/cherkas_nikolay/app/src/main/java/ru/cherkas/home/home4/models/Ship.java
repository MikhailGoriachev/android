package ru.cherkas.home.home4.models;
/*
* Навалочные грузы
* уголь, зерно, руда, щебень, минеральные удобрения
* на судах - балкерах.
*
* Наливные грузы
* сырая нефть, нефтепродукты, сжиженный природный газ, химвещества
* на судах - танкерах и газовозах
*
* Генеральные (общие) грузы
* оборудование, контейнеры, накатная техника, железобетонные конструкции,
*             металлопродукция, лесные грузы и пиломатериалы
* на судах-контейнеровозах, ролкерах
* */

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Ship implements Parcelable {
    private String title;
    private double capacity; // грузоподъемность
    private String city;     // пункт назначения
    private String type;     // тип груза
    private double weight;   // вес груза
    private Cargo cargo;     // груз
    private String photo;

    private boolean specialPier; // специальный пирс
    private boolean anchorage;   // место на якорной стоянке
    private boolean refill;      // дозаправка

    protected Ship(Parcel in) {
        title = in.readString();
        capacity = in.readDouble();
        city = in.readString();
        type = in.readString();
        weight = in.readDouble();
        photo = in.readString();
        specialPier = in.readByte() != 0;
        anchorage = in.readByte() != 0;
        refill = in.readByte() != 0;
    }

    public static final Creator<Ship> CREATOR = new Creator<Ship>() {
        @Override
        public Ship createFromParcel(Parcel in) {
            return new Ship(in);
        }

        @Override
        public Ship[] newArray(int size) {
            return new Ship[size];
        }
    };

    public String getTitle() { return title; }

    public void setTitle(String title) { this.title = title; }

    public double getCapacity() { return capacity; }

    public void setCapacity(double capacity) { this.capacity = capacity; }

    public String getCity() { return city;}

    public void setCity(String city) { this.city = city; }

    public String getType() { return type; }

    public void setType(String type) { this.type = type; }

    public double getWeight() { return weight; }

    public void setWeight(double weight) {
        if (weight < capacity){
            this.weight = weight;
        }
    }

    public Cargo getCargo() { return cargo;}

    public void setCargo(Cargo cargo) {
        if (cargo.getTitle() == getType()){
            this.cargo = cargo;
        }
    }

    public String getPhoto() { return photo; }

    public void setPhoto(String photo) { this.photo = photo; }

    public boolean isSpecialPier() { return specialPier; }

    public void setSpecialPier(boolean specialPier) { this.specialPier = specialPier; }

    public boolean isAnchorage() { return anchorage; }

    public void setAnchorage(boolean anchorage) { this.anchorage = anchorage; }

    public boolean isRefill() { return refill; }

    public void setRefill(boolean refill) { this.refill = refill; }

    @Override
    public int describeContents() { return 0; }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(title);
        parcel.writeDouble(capacity);
        parcel.writeString(city);
        parcel.writeString(type);
        parcel.writeDouble(weight);
        parcel.writeString(photo);
        parcel.writeByte((byte) (specialPier ? 1 : 0));
        parcel.writeByte((byte) (anchorage ? 1 : 0));
        parcel.writeByte((byte) (refill ? 1 : 0));
    }
}
