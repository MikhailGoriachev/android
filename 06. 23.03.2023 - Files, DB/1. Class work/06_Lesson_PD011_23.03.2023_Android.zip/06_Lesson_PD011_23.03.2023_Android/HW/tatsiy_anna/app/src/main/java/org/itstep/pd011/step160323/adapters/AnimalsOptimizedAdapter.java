package org.itstep.pd011.step160323.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.models.Animal;
import java.util.List;
import java.util.function.Consumer;

public class AnimalsOptimizedAdapter extends RecyclerView.Adapter<AnimalsOptimizedAdapter.ViewHolder> {

    private final LayoutInflater inflater;     // загрузчик разметки элемента - из контекста создания - активность или фрагмент
    private final List<Animal> animalList;      // коллекция данных
    private final Consumer<Animal> consumer;

    // для создания адаптера в точке вызова
    public AnimalsOptimizedAdapter(@NonNull Context context, @NonNull List<Animal> animals, Consumer<Animal> consumer ){
        this.inflater = LayoutInflater.from(context);
        this.animalList = animals;
        this.consumer = consumer;
    }

    // возвращает экземпляр ViewHolder
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        return new ViewHolder(inflater.inflate(R.layout.animal_item_action,parent, false));
    }

    // возвращает количество записей в коллекции
    @Override
    public int getItemCount() {
        return animalList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position){

        // получить элемент коллекции
        Animal animal = animalList.get(position);

        // записать значения полей в элементы интерфейса пользователя
        viewHolder.imgAnimal.setImageResource(animal.getBreed().getImage());
        viewHolder.txvName.setText(animal.getName());
        viewHolder.txvBreed.setText(animal.getBreed().getTitle());
        viewHolder.txvOwner.setText(animal.getOwner());

        // назначаем обработчика клика по элементам разметки, т.к. клик в
        // основной активности блокируется слушателями кнопками
        viewHolder.llTextViews.setOnClickListener(v->onClickListner(v, animalList.get(position)));
        viewHolder.imgAnimal.setOnClickListener(v->onClickListner(v, animalList.get(position)));
        viewHolder.btnDeleteAnimal.setOnClickListener(v->delete(position));

    }

    // класс ViewHolder - хранит ссылки на элементы разметки
    // исключает повторные операции поиска элементов в разметке
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // элементы интерфейса из разметки элемента
        final ImageView imgAnimal;
        final TextView txvName;
        final TextView txvBreed;
        final TextView txvOwner;
        final LinearLayout llTextViews;

        final Button btnDeleteAnimal;

        public ViewHolder(@NonNull View view) {
            super(view);

            // связать разметку и ссылки на элементы отображения
            imgAnimal = view.findViewById(R.id.imgItem);
            txvName = view.findViewById(R.id.txvName);
            txvBreed = view.findViewById(R.id.txvBreed);
            txvOwner = view.findViewById(R.id.txvOwner);
            llTextViews = view.findViewById(R.id.llTextViews);
            btnDeleteAnimal = view.findViewById(R.id.btnDeleteAnimal);

        } // ViewHolder
    } // class ViewHolder

    private void onClickListner(View view, Animal animal) {
         this.consumer.accept(animal);
    }

    // пример удаления записи из коллекции
    private void delete(int position) {
        animalList.remove(position);    // удаление записи по индексу
        myNotifyDataSetChanged();      // применить изменения к адаптеру
    } // delete

    @SuppressLint("NotifyDataSetChanged")
    public void myNotifyDataSetChanged() { notifyDataSetChanged();}
}
