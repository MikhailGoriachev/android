package org.itstep.pd011.mv.hw2.activities;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import com.google.android.material.snackbar.Snackbar;
import org.itstep.pd011.mv.hw2.MainActivity;
import org.itstep.pd011.mv.hw2.R;
import org.itstep.pd011.mv.hw2.databinding.ActivityPetBinding;
import org.itstep.pd011.mv.hw2.models.Pet;
import org.itstep.pd011.mv.hw2.infrastructure.RepeatListener;

@SuppressLint("ClickableViewAccessibility")
public class PetActivity extends AppCompatActivity {
    private final int incrementStep = 1;
    private final int pressButtonFirstInterval = 500;
    private final int pressButtonCyclicInterval = 100;

    Pet pet;

    ActivityPetBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_pet);

        Intent intent = getIntent();
        pet = intent.getParcelableExtra(Pet.class.getCanonicalName());

        binding.setPet(pet);
        binding.setAgeMin(Pet.ageMinValue);
        binding.setWeightMin(Pet.weightMinValue);
        binding.setStep(incrementStep);

        binding.rbgPetBreeds.setOnCheckedChangeListener(this::onChangeBreed);

        binding.btnOk.setOnClickListener(this::onOkClick);
        binding.btnCancel.setOnClickListener(this::onCancelClick);
        binding.btnClear.setOnClickListener(this::onClearClick);

        binding.btnDecAge.setOnTouchListener(ageDecrementListener());
        binding.btnIncAge.setOnTouchListener(ageIncrementListener());
        binding.btnIncWeight.setOnTouchListener(weightIncrementListener());
        binding.btnDecWeight.setOnTouchListener(weightDecrementListener());
    }

    private View.OnTouchListener ageIncrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            pet.setAge(pet.getAge() + incrementStep);
        });
    }

    private View.OnTouchListener ageDecrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            if(pet.getAge() - incrementStep >= Pet.ageMinValue)
                pet.setAge(pet.getAge() - incrementStep);
        });
    }

    private View.OnTouchListener weightIncrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            pet.setWeight(pet.getWeight() + incrementStep);
        });
    }

    private View.OnTouchListener weightDecrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            if(pet.getWeight() - incrementStep >= Pet.weightMinValue)
                pet.setWeight(pet.getWeight() - incrementStep);
        });
    }

    private void onChangeBreed(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.rbRetriever:
                pet.setBreed(binding.rbRetriever.getText().toString());
                pet.setImageFile(binding.rbRetriever.getTag().toString());
                break;
            case R.id.rbPug:
                pet.setBreed(binding.rbPug.getText().toString());
                pet.setImageFile(binding.rbPug.getTag().toString());
                break;
            case R.id.rbDeer:
                pet.setBreed(binding.rbDeer.getText().toString());
                pet.setImageFile(binding.rbDeer.getTag().toString());
        }
    }

    public void onClearClick(View view) {
        binding.edtPetName.setText("");
        binding.edtPetAge.setText(String.valueOf(Pet.ageMinValue));
        binding.edtPetOwner.setText("");
        binding.edtPetWeight.setText(String.valueOf(Pet.weightMinValue));
    }

    public void onOkClick(View view) {

        Integer errorMessage = null;

        if (pet.getName().isBlank()) {
            errorMessage = R.string.petNameRequiredMsg;
        } else if (pet.getBreed().isBlank()) {
            errorMessage = R.string.petBreedRequiredMsg;
        } else if (pet.getOwner().isBlank()) {
            errorMessage = R.string.petOwnerRequiredMsg;
        } else if (pet.getAge() < Pet.ageMinValue) {
            errorMessage = R.string.invalidPetAge;
        } else if (pet.getWeight() <= Pet.weightMinValue) {
            errorMessage = R.string.invalidPetWeight;
        }

        if (errorMessage != null) {
            Snackbar.make(view, errorMessage, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.btnOkTitle, v -> {})
                    .show();
            return;
        }

        Intent intent = new Intent();
        intent.putExtra(Pet.class.getCanonicalName(), pet);

        setResult(MainActivity.RESULT_OK, intent);
        finish();
    }

    public void onCancelClick(View view) {
        finish();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putParcelable(Pet.class.getCanonicalName(), pet);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        pet = savedInstanceState.getParcelable(Pet.class.getCanonicalName());
    }
}

