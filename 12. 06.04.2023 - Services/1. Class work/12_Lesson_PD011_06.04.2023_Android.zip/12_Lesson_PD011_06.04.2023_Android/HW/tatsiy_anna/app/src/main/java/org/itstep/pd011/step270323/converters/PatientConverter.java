package org.itstep.pd011.step270323.converters;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;

import org.itstep.pd011.step270323.helpers.Shell;
import org.itstep.pd011.step270323.helpers.Utils;
import org.itstep.pd011.step270323.entities.Patient;

import java.lang.reflect.Type;
import java.text.ParseException;

public class PatientConverter extends Shell<Patient> {

    public JsonElement serialize(Patient src, Type type,
                                 JsonSerializationContext context){

        JsonObject object = new JsonObject();
        object.addProperty("id", src.getId());
        object.addProperty("surname", src.getSurname());
        object.addProperty("name", src.getName());
        object.addProperty("patronymic", src.getPatronymic());
        object.addProperty("dateOfBirth", Utils.formatter.format(src.getDateOfBirth()));
        object.addProperty("address", src.getAddress());

        return object;
    }

    public Patient deserialize(JsonElement json, Type type,
                               JsonDeserializationContext context) throws JsonParseException {

        JsonObject object = json.getAsJsonObject();

        try {
            return new Patient(
                    object.get("id").getAsLong(),
                    object.get("surname").getAsString(),
                    object.get("name").getAsString(),
                    object.get("patronymic").getAsString(),
                    Utils.formatter.parse(object.get("dateOfBirth").getAsString()),
                    object.get("address").getAsString()

            );
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }
}
