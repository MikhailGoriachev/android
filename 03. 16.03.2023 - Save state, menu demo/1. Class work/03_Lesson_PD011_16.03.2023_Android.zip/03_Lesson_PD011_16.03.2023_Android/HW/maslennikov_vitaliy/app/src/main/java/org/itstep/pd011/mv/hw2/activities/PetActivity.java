package org.itstep.pd011.mv.hw2.activities;

import static org.itstep.pd011.mv.hw2.utils.Common.decimalPlaces;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.material.snackbar.Snackbar;

import org.itstep.pd011.mv.hw2.MainActivity;
import org.itstep.pd011.mv.hw2.R;
import org.itstep.pd011.mv.hw2.models.Pet;
import org.itstep.pd011.mv.hw2.utils.RepeatListener;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

@SuppressLint("ClickableViewAccessibility")
public class PetActivity extends AppCompatActivity {

    EditText edtPetName, edtPetBreed, edtPetOwner, edtPetAge, edtPetWeight;
    ImageView imvPetImage;
    Button btnClear, btnOk, btnCancel, btnIncAge, btnDecAge, btnIncWeight, btnDecWeight;

    Pet pet;

    private final int incrementStep = 1;
    private final int pressButtonFirstInterval = 500;
    private final int pressButtonCyclicInterval = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet);

        edtPetName = findViewById(R.id.edtPetName);
        edtPetBreed = findViewById(R.id.edtPetBreed);
        edtPetOwner = findViewById(R.id.edtPetOwner);
        edtPetAge = findViewById(R.id.edtPetAge);
        edtPetWeight = findViewById(R.id.edtPetWeight);

        imvPetImage = findViewById(R.id.imvPetImage);

        btnClear = findViewById(R.id.btnClear);
        btnOk = findViewById(R.id.btnOk);
        btnCancel = findViewById(R.id.btnCancel);
        btnIncAge = findViewById(R.id.btnIncAge);
        btnDecAge = findViewById(R.id.btnDecAge);
        btnIncWeight = findViewById(R.id.btnIncWeight);
        btnDecWeight = findViewById(R.id.btnDecWeight);


        Intent intent = getIntent();
        pet = intent.getParcelableExtra(Pet.class.getCanonicalName());

        edtPetBreed.setText(pet.getBreed());
        edtPetName.setText(pet.getName());
        edtPetAge.setText(String.valueOf(pet.getAge()));
        edtPetWeight.setText(String.valueOf(pet.getWeight()));
        edtPetOwner.setText(pet.getOwner());

        try (InputStream inputStream = getApplicationContext().getAssets().open(pet.getImageFile())) {
            Drawable drawable = Drawable.createFromStream(inputStream, null);
            imvPetImage.setImageDrawable(drawable);
            imvPetImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        } catch (IOException e) {
            Snackbar.make(imvPetImage, R.string.imageReadErrorMessage, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.btnOkTitle, v -> {})
                    .show();
        }

        edtPetName.addTextChangedListener(getStringInputTextWatcher(edtPetName, R.string.petNameRequiredMsg));
        edtPetBreed.addTextChangedListener(getStringInputTextWatcher(edtPetBreed, R.string.petBreedRequiredMsg));
        edtPetOwner.addTextChangedListener(getStringInputTextWatcher(edtPetOwner, R.string.petOwnerRequiredMsg));
        edtPetAge.addTextChangedListener(petAgeTextWatcher);
        edtPetWeight.addTextChangedListener(petWeightTextWatcher);

        btnOk.setOnClickListener(this::onOkClick);
        btnCancel.setOnClickListener(this::onCancelClick);
        btnClear.setOnClickListener(this::onClearClick);

        btnDecAge.setOnTouchListener(ageDecrementListener());
        btnIncAge.setOnTouchListener(ageIncrementListener());

        btnIncWeight.setOnTouchListener(weightIncrementListener());
        btnDecWeight.setOnTouchListener(weightDecrementListener());
    }

    private TextWatcher getStringInputTextWatcher(EditText edtTxt, int messageId) {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String content = edtTxt.getText().toString();

                if (content.isBlank()) {
                    edtTxt.setBackgroundResource(R.drawable.edit_error);
                    edtTxt.setError(getString(messageId));
                } else {
                    edtTxt.setBackgroundResource(R.drawable.edit_normal);
                }
            }
            @Override
            public void afterTextChanged(Editable s) {}
        };
    }

    private final TextWatcher petAgeTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String ageText = edtPetAge.getText().toString();
            Integer age = ageText.isBlank() ? null : Integer.parseInt(ageText);

            if (age == null || age < Pet.ageMinValue) {
                edtPetAge.setBackgroundResource(R.drawable.edit_error);
                edtPetAge.setError(getString(R.string.invalidPetAge));
            } else {
                edtPetAge.setBackgroundResource(R.drawable.edit_normal);
            }

            btnIncAge.setEnabled(age != null);
            btnDecAge.setEnabled(age != null && age - incrementStep >= Pet.ageMinValue);
        }
        @Override
        public void afterTextChanged(Editable s) {}
    };

    private final TextWatcher petWeightTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String weightText = edtPetWeight.getText().toString();
            Double weight = weightText.isBlank() ? null : Double.parseDouble(weightText);

            if (weight == null || weight < Pet.weightMinValue) {
                edtPetWeight.setBackgroundResource(R.drawable.edit_error);
                edtPetWeight.setError(getString(R.string.invalidPetWeight));
            } else {
                edtPetWeight.setBackgroundResource(R.drawable.edit_normal);
            }

            btnIncWeight.setEnabled(weight != null);
            btnDecWeight.setEnabled(weight != null && weight - incrementStep >= Pet.weightMinValue);
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    private View.OnTouchListener ageIncrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            String ageText = edtPetAge.getText().toString();
            int age = ageText.isBlank() ? Pet.ageMinValue : Integer.parseInt(ageText);
            edtPetAge.setText(String.valueOf(age + incrementStep));
        });
    }

    private View.OnTouchListener ageDecrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            String ageText = edtPetAge.getText().toString();
            int age = ageText.isBlank() ? Pet.ageMinValue : Integer.parseInt(ageText);

            if (age <= Pet.ageMinValue) {
                Snackbar.make(view, R.string.tooLowAgeMessage, Snackbar.LENGTH_INDEFINITE)
                        .setAction(R.string.btnOkTitle, v -> {})
                        .show();
                return;
            }

            if ((age - incrementStep * 2) <= Pet.ageMinValue) {
                btnDecAge.setEnabled(false);
            }

            edtPetAge.setText(String.valueOf(age - incrementStep));
        });
    }


    private View.OnTouchListener weightIncrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            String weightText = edtPetWeight.getText().toString();
            double weight = weightText.isBlank() ? Pet.weightMinValue : Double.parseDouble(weightText);

            int decimals = decimalPlaces(weight);
            edtPetWeight.setText(String.format(Locale.UK,"%." + decimals + "f", weight + incrementStep));
        });
    }

    private View.OnTouchListener weightDecrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            String weightText = edtPetWeight.getText().toString();
            double weight = weightText.isBlank() ? Pet.weightMinValue : Double.parseDouble(weightText);

            if (weight < Pet.weightMinValue) {
                Snackbar.make(view, R.string.tooLowWeightMessage, Snackbar.LENGTH_SHORT)
                        .setAction(R.string.btnOkTitle, v -> {})
                        .show();
                return;
            }

            if ((weight - incrementStep * 2) < Pet.weightMinValue) {
                btnDecWeight.setEnabled(false);
            }

            int decimals = decimalPlaces(weight);
            edtPetWeight.setText(String.format(Locale.UK,"%." + decimals + "f", weight - incrementStep));
        });
    }

    public void onIncWeightClick(View view) {
        String weightText = edtPetWeight.getText().toString();
        double weight = weightText.isBlank() ? Pet.weightMinValue : Double.parseDouble(weightText);

        int decimals = decimalPlaces(weight);
        edtPetWeight.setText(String.format(Locale.UK,"%." + decimals + "f", weight + incrementStep));
    }

    public void onDecWeightClick(View view) {
        String weightText = edtPetWeight.getText().toString();
        double weight = weightText.isBlank() ? Pet.weightMinValue : Double.parseDouble(weightText);

        if (weight < Pet.weightMinValue) {
            Snackbar.make(view, R.string.tooLowWeightMessage, Snackbar.LENGTH_SHORT)
                    .setAction(R.string.btnOkTitle, v -> {})
                    .show();
            return;
        }

        if ((weight - incrementStep * 2) < Pet.weightMinValue) {
            btnDecWeight.setEnabled(false);
        }

        int decimals = decimalPlaces(weight);
        edtPetWeight.setText(String.format(Locale.UK,"%." + decimals + "f", weight - incrementStep));
    }
    
    public void onClearClick(View view) {
        edtPetName.setText("");
        edtPetAge.setText("");
        edtPetBreed.setText("");
        edtPetOwner.setText("");
        edtPetWeight.setText("");
    }

    public void onOkClick(View view) {
        String name = edtPetName.getText().toString().trim();
        String breed = edtPetBreed.getText().toString().trim();
        String owner = edtPetOwner.getText().toString().trim();
        String ageText = edtPetAge.getText().toString();
        String weightText = edtPetWeight.getText().toString();

        Integer age = ageText.isBlank() ? null : Integer.parseInt(ageText);
        Double weight = weightText.isBlank() ? null : Double.parseDouble(edtPetWeight.getText().toString());

        Integer errorMessage = null;

        if (name.isBlank()) {
            errorMessage = R.string.petNameRequiredMsg;
        } else if (breed.isBlank()) {
            errorMessage = R.string.petBreedRequiredMsg;
        } else if (owner.isBlank()) {
            errorMessage = R.string.petOwnerRequiredMsg;
        } else if (age == null || age < Pet.ageMinValue) {
            errorMessage = R.string.invalidPetAge;
        } else if (weight == null || weight <= Pet.weightMinValue) {
            errorMessage = R.string.invalidPetWeight;
        }

        if (errorMessage != null) {
            Snackbar.make(view, errorMessage, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.btnOkTitle, v -> {})
                    .show();
            return;
        }

        Intent intent = new Intent();
        intent.putExtra(Pet.class.getCanonicalName(),
                new Pet(breed, name, age, weight, owner, pet.getImageFile()));

        setResult(MainActivity.RESULT_OK, intent);
        finish();
    }

    public void onCancelClick(View view) {
        finish();
    }
}