package com.step.home_work.intefaces;

public interface ActivitySender {

    void sendQueryNumber(int queryNumber);

}
