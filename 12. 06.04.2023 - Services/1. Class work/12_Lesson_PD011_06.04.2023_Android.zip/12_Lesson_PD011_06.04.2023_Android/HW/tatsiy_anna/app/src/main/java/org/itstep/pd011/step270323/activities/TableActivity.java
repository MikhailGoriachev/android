package org.itstep.pd011.step270323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.adapters.TablePageAdapter;
import org.itstep.pd011.step270323.helpers.Utils;

import java.util.Objects;

public class TableActivity extends AppCompatActivity {

    ViewPager2              pager;         // страничный интерфейс
    TabLayout               tabLayout;     // заголовки для переходов по страницам

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);

        pager = findViewById(R.id.vpgTable);
        tabLayout = findViewById(R.id.tbLTable);

        pager.setAdapter(new TablePageAdapter(this));

        TabLayoutMediator tabLayoutMediator = new TabLayoutMediator(tabLayout,pager,(tab, position) ->{

            // разметка заголовка страницы
            tab.setCustomView(R.layout.tab_header);
            TextView txvHeaderPage = Objects.requireNonNull(tab.getCustomView()).findViewById(R.id.txvHeaderPage);

            // настройка заголовков
            txvHeaderPage.setText(Utils.tableHeadersTables[position+1]);
        });

        // подключить настройщика к области вывода заголовоков
        tabLayoutMediator.attach();
    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected

}