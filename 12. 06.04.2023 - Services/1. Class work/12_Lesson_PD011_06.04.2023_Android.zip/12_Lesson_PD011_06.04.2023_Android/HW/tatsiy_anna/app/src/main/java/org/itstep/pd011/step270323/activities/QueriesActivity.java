package org.itstep.pd011.step270323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.fragments.ResponseFragment;
import org.itstep.pd011.step270323.interfaces.OnFragmentSendDataListener;

public class QueriesActivity extends AppCompatActivity implements OnFragmentSendDataListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_queries);


    }

    // реализация интерфейса передачи данных из одного фрагмента в другой
    // через активность
    @Override
    public void onSendPosition(Integer position){
        // если ориентация горизонтальная, передаем данные фрагменту
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){

            // получаем ссылку на фрагмент-приемник
            ResponseFragment fragment = (ResponseFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.responseFragment);

            assert fragment != null;
            fragment.setResponse(position);
        }else {

            // ориентация вертикальная, вызываем
            // активность, в которой и размещен целевой фрагмент
            Intent intent = new Intent(getApplicationContext(), ResponseActivity.class);
            intent.putExtra(ResponseActivity.POSITION, position);
            startActivity(intent);
        }
    }


    //region Меню активности
    @Override // создание меню
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    @Override // обработчик выбора меню
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.mniBack) {
            // возврат из активности
            finish();
        } // if

        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected
}