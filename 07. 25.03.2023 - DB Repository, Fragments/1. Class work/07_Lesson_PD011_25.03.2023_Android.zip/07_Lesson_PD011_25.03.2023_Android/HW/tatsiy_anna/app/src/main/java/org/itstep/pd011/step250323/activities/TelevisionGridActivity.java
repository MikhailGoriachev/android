package org.itstep.pd011.step250323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.GridView;

import org.itstep.pd011.step250323.R;
import org.itstep.pd011.step250323.adapters.TelevisionGridAdapter;
import org.itstep.pd011.step250323.models.Television;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TelevisionGridActivity extends AppCompatActivity {

    // коллекция данных
    private ArrayList<Television> televisions;

    // элемент интерфейса для отображения коллекции данных
    private GridView grvTelevisions;

    // адаптер для ListView
    TelevisionGridAdapter televisionGridAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_television_grid);

        initializeList();

        // создание адаптера
        televisionGridAdapter = new TelevisionGridAdapter(
                this,
                R.layout.television_item_grid,
                televisions
        );

        grvTelevisions = findViewById(R.id.grvTelevisions);
        grvTelevisions.setAdapter(televisionGridAdapter);
    }

    private void initializeList(){
        televisions = new ArrayList<>();

        for (int i=0; i<15; i++){
            televisions.add(Television.generate(i));
        }
    }

    // обработчик клика по кнопке вызова активности для Animal
    private void startOrderActivity(ArrayList<Television> list){

        Intent intent = new Intent(this, TelevisionRecyclerViewActivity.class);
        Bundle bundle = new Bundle();

        bundle.putParcelableArrayList("mylist", list);

        intent.putExtras(bundle);
        this.startActivity(intent);
    }

    //region Меню активности
    @Override // создание меню
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.televisions_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu


    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        //Упорядочить копию коллекции:
        // ArrayList<Television> t = new ArrayList<>(televisions);

        switch (item.getItemId()) {

            case R.id.mniOrderByPriceDesc:
                startOrderActivity(televisions.stream()
                                        .sorted((a,b) -> b.getPrice() - a.getPrice())
                                        .collect(Collectors.toCollection(ArrayList::new)));
                break;


            case R.id.mniOrderByDiagonal:
                startOrderActivity(televisions.stream()
                                        .sorted(Comparator.comparingDouble(Television::getDiagonal))
                                        .collect(Collectors.toCollection(ArrayList::new)));
                break;

            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected
}