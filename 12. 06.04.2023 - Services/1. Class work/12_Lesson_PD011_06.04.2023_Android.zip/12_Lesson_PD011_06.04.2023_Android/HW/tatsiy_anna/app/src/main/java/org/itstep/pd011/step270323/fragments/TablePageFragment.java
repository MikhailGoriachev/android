package org.itstep.pd011.step270323.fragments;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.repositories.DoctorsDatabaseRepository;
import org.itstep.pd011.step270323.repositories.PatientsDatabaseRepository;
import org.itstep.pd011.step270323.repositories.ReceptsDatabaseRepository;
import org.itstep.pd011.step270323.repositories.SpecialtiesDatabaseRepository;
import java.text.ParseException;

public class TablePageFragment extends Fragment {

    // номер страницы
    private int pageNumber;

    // элемент страницы
    ListView listView;

    // Required empty public constructor
    public TablePageFragment() {  }

    // фабричный метод, возвращающий экземпляр фрагмента
    public static TablePageFragment newInstance(int page) {
        TablePageFragment fragment = new TablePageFragment();

        // номер страницы передать экземпляру фрагмента
        Bundle args = new Bundle();
        args.putInt("num", page);
        fragment.setArguments(args);

        // фрагмент сформирован
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // попытка получения параметров запуска - в д.с. номер страницы
        // если параметров нет - первый запуск, первая страница

        pageNumber = getArguments() != null ? getArguments().getInt("num") : 1;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View result = inflater.inflate(R.layout.fragment_table_page, container, false);

        listView = result.findViewById(R.id.listTable);

        int t = pageNumber + 1;

        switch (t) {
            case 1:

                DoctorsDatabaseRepository repositoryDoctors = new DoctorsDatabaseRepository(getContext());

                repositoryDoctors.open();
                listView.setAdapter(
                        new ArrayAdapter<>(
                                getContext(),
                                android.R.layout.simple_list_item_1,
                                repositoryDoctors.getDoctors()
                        ));

                repositoryDoctors.close();
                break;

            case 2:

                PatientsDatabaseRepository repositoryPatients = new PatientsDatabaseRepository(getContext());
                repositoryPatients.open();

                try {
                    listView.setAdapter(
                            new ArrayAdapter<>(
                                    getContext(),
                                    android.R.layout.simple_list_item_1,
                                    repositoryPatients.getPatients()
                            ));
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }

                repositoryPatients.close();
                break;

            case 3:

                ReceptsDatabaseRepository repositoryReceipt = new ReceptsDatabaseRepository(getContext());
                repositoryReceipt.open();

                try {
                    listView.setAdapter(
                            new ArrayAdapter<>(
                                    getContext(),
                                    android.R.layout.simple_list_item_1,
                                    repositoryReceipt.getReceipts()
                            ));
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }

                repositoryReceipt.close();
                break;

            case 4:

                SpecialtiesDatabaseRepository repositorySpecialties = new SpecialtiesDatabaseRepository(getContext());
                repositorySpecialties.open();

                listView.setAdapter(
                        new ArrayAdapter<>(
                                getContext(),
                                android.R.layout.simple_list_item_1,
                                repositorySpecialties.getSpecialties()
                        ));

                repositorySpecialties.close();

                break;

        }

        return result;
    }

}