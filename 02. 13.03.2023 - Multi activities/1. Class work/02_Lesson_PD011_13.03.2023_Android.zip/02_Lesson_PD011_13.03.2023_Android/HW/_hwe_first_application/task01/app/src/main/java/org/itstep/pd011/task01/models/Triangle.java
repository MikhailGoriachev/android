package org.itstep.pd011.task01.models;

import org.itstep.pd011.task01.Utils;

import java.security.InvalidParameterException;

// класс, представляющий треугольник в задании
public class Triangle {
    // стороны треугольника
    private double a;
    private double b;
    private double c;

    public Triangle() {
        this(1, 1, 1);
    } // Triangle
    public Triangle(double a, double b, double c) {
        setSides(a, b, c);
    } // Triangle

    // получение сторон треугольника
    public double getA() { return a; }
    public double getB() { return b; }
    public double getC() { return c; }

    // установка сторон треугольника
    public void setSides(double a, double b, double c) {
        if (!Utils.isTriangle(a, b, c))
            throw new InvalidParameterException("Значения не образуют треугольник");

        this.a = a;
        this.b = b;
        this.c = c;
    } // setSides

    // вычисление периметра
    public double perimeter() { return a + b + c; }

    // вычисление площади
    public double area() {
        double p = perimeter() / 2;
        return Math.sqrt((p - a) * (p - b) * (p - c));
    } // area
} // class Triangle
