package org.pd011.sotula;

import static org.pd011.sotula.helpers.Utils.getRandDbl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.pd011.sotula.models.Triangle;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // треугольник
    Triangle triangle;

    // поля
    TextView txvSideA,
            txvSideB,
            txvSideC,
            txvArea,
            txvPerimeter;

    // кнопки
    Button btnCalcArea,
            btnCalcPerimeter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // получить поля
        txvSideA = findViewById(R.id.txvSideA);
        txvSideB = findViewById(R.id.txvSideB);
        txvSideC = findViewById(R.id.txvSideC);
        txvArea = findViewById(R.id.txvArea);
        txvPerimeter = findViewById(R.id.txvPerimeter);

        // получить кнопки
        btnCalcArea = findViewById(R.id.btnCalcArea);
        btnCalcPerimeter = findViewById(R.id.btnCalcPerimeter);

    } // onCreate

    // генерация значений
    public void generateValuesClick(View view) {

        if(!btnCalcArea.isEnabled() && !btnCalcPerimeter.isEnabled()){
            btnCalcArea.setEnabled(true);
            btnCalcPerimeter.setEnabled(true);
        }

        final double MIN = 1d, MAX = 10d;

        double sideA, sideB, sideC;

        do {
            sideA = getRandDbl(MIN,MAX);
            sideB = getRandDbl(MIN,MAX);
            sideC = getRandDbl(MIN,MAX);
        } while (!Triangle.isExist(sideA, sideB, sideC));

        txvSideA.setText(String.format(Locale.UK,"%.2f", sideA));
        txvSideB.setText(String.format(Locale.UK,"%.2f", sideB));
        txvSideC.setText(String.format(Locale.UK,"%.2f", sideC));

        txvArea.setText("");
        txvPerimeter.setText("");
    } // generateValuesClick


    // вычисление площади
    public void calcAreaClick(View view) {
        triangle = new Triangle(
                Double.parseDouble(txvSideA.getText().toString()),
                Double.parseDouble(txvSideB.getText().toString()),
                Double.parseDouble(txvSideC.getText().toString())
        );

        txvArea.setText(String.format(Locale.UK,"%.2f", triangle.calculateArea()));

    } // calcAreaClick

    // вычисление периметра

    public void calcPerimeterClick(View view) {

        triangle = new Triangle(
                Double.parseDouble(txvSideA.getText().toString()),
                Double.parseDouble(txvSideB.getText().toString()),
                Double.parseDouble(txvSideC.getText().toString())
                );

        txvPerimeter.setText(String.format(Locale.UK,"%.2f", triangle.calculatePerimeter()));
    } // calcPerimeterClick


    // выход
    public void exitClick(View view) {
        finish();
    }
}