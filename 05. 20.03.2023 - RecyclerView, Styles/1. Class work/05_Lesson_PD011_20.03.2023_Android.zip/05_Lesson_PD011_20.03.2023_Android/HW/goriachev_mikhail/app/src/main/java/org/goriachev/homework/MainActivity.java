package org.goriachev.homework;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.goriachev.homework.activities.AnimalEditActivity;
import org.goriachev.homework.activities.ShipEditActivity;
import org.goriachev.homework.adapters.AnimalAdapter;
import org.goriachev.homework.adapters.ShipAdapter;
import org.goriachev.homework.infrastructure.ResultCode;
import org.goriachev.homework.models.Animal;
import org.goriachev.homework.models.Ship;
import org.goriachev.homework.utils.Utils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    // животные
    private List<Animal> animals;

    // listView для животных
    private ListView lvwAnimals;

    // адаптер животного
    private AnimalAdapter animalAdapter;

    // listView для животных
    private ListView lvwShips;

    // адаптер судна
    private ShipAdapter shipAdapter;

    // судно
    private List<Ship> ships;

    // обработчик события создания активности
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        animals = Arrays.stream((new Animal[12]))
                .map(a -> Animal.factory())
                .collect(Collectors.toList());

        lvwAnimals = findViewById(R.id.lvw_animals);

        animalAdapter = new AnimalAdapter(this, R.layout.animal_view_item, animals, this::onClickAnimalHandler);

        lvwAnimals.setAdapter(animalAdapter);

        ships = Arrays.stream((new Ship[12]))
                .map(a -> Ship.factory())
                .collect(Collectors.toList());

        lvwShips = findViewById(R.id.lvw_ships);

        shipAdapter = new ShipAdapter(this, R.layout.ship_view_item, ships, this::onClickShipHandler);

        lvwShips.setAdapter(shipAdapter);

    }

    // обработчик события выбора животного в списке
    private void onClickAnimalHandler(int position) {
        Intent intent = new Intent(this, AnimalEditActivity.class);
        intent.putExtra(Animal.class.getCanonicalName(), animals.get(position));
        intent.putExtra("position", position);

        startActivityForResult(intent, AnimalEditActivity.ANIMAL_EDIT_ACTIVITY_ID);
    }

    // обработчик события выбора судна в списке
    private void onClickShipHandler(int position) {
        Intent intent = new Intent(this, ShipEditActivity.class);
        intent.putExtra(Ship.class.getCanonicalName(), ships.get(position));
        intent.putExtra("position", position);

        startActivityForResult(intent, ShipEditActivity.SHIP_EDIT_ACTIVITY_ID);
    }

    // завершение активности
    public void finish(View view) {
        finish();
    }

    // обработчик события получения результата из активности
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != ResultCode.RESULT_OK)
            Utils.showSnakeBar(null, "Ошибка с кодом: " + resultCode);
        switch (requestCode) {
            case AnimalEditActivity.ANIMAL_EDIT_ACTIVITY_ID:
                if (data != null) {
                    animals.set(
                            data.getIntExtra("position", -1),
                            data.getParcelableExtra(Animal.class.getCanonicalName())
                    );
                    animalAdapter.notifyDataSetChanged();
                }
                break;

            case ShipEditActivity.SHIP_EDIT_ACTIVITY_ID:
                if (data != null) {
                    ships.set(
                            data.getIntExtra("position", -1),
                            data.getParcelableExtra(Ship.class.getCanonicalName())
                    );
                    shipAdapter.notifyDataSetChanged();
                }
                break;
        }
    }

    // работа с главным меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    // обработка пунктов меню
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
//            case R.id.mni_edit_animal:
//                showAnimalEditActivity(null);
//                break;
//            case R.id.mni_edit_ship:
//                showShipEditActivity(null);
//                break;
            case R.id.mni_exit:
                finish();
        }

        return super.onOptionsItemSelected(item);
    }
}