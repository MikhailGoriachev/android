package org.itstep.pd011.step250323.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import org.itstep.pd011.step250323.R;
import org.itstep.pd011.step250323.helpers.Utils;
import org.itstep.pd011.step250323.models.Television;

import java.util.ArrayList;
import java.util.Locale;

public class TelevisionGridAdapter extends ArrayAdapter<Television> {
    private final Context context;               // пример использования Context в адаптере
    private final LayoutInflater layoutInflater; // загрузчик разметки
    private final int layout;                    // ид разметки одного элемента
    private final ArrayList<Television> televisions;  // ссылка на коллекцию данных

    public TelevisionGridAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Television> televisions) {
        super(context, resource, televisions);

        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.layout = resource;
        this.televisions = televisions;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        /* Использование ViewHolder */
        final ViewHolder viewHolder;

        if (convertView == null) {
            convertView = layoutInflater.inflate(this.layout, parent, false);
            viewHolder = new ViewHolder(convertView, position);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            viewHolder.position = position;
        } // if

        // получить ссылку на элемент коллекции
        Television television = televisions.get(position);

        // вывести данные в элементы разметки view
        Utils.setViewImage(viewHolder.imgTelevision, television.getImage(), context);
        viewHolder.txvModel.setText(television.getModel());
        viewHolder.txvDiagonal.setText(String.format(Locale.UK,"Диагональ: %.2f",television.getDiagonal()));
        viewHolder.txvResolution.setText(String.format(Locale.UK,"Разрешение: %dx%d",television.getVertical(),television.getHorizontal()));
        viewHolder.txvPrice.setText(String.format(Locale.UK,"%d ₽",television.getPrice()));

        // вернуть сформированное представление
        return convertView;
    }

    private class ViewHolder{
        final ImageView imgTelevision;
        final TextView txvModel;
        final TextView txvDiagonal;
        final TextView txvResolution;
        final TextView txvPrice;

        final LinearLayout llTelevision;

        private int position;

        public ViewHolder(View view, int position){
            imgTelevision = view.findViewById(R.id.imgTelevision);
            txvModel = view.findViewById(R.id.txvModel);
            txvDiagonal = view.findViewById(R.id.txvDiagonal);
            txvResolution = view.findViewById(R.id.txvResolution);
            txvPrice = view.findViewById(R.id.txvPrice);

            llTelevision = view.findViewById(R.id.llTelevision);

            this.position = position;

            llTelevision.setOnClickListener(v-> clickListner(llTelevision, this.position));
        }
    }

    private void clickListner(LinearLayout llTelevision, int position) {
    }// clickListner
}
