package org.itstep.pd011.step270323.tasks;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import org.itstep.pd011.step270323.entities.Patient;
import org.itstep.pd011.step270323.repositories.PatientsDatabaseRepository;

import java.text.ParseException;
import java.util.List;

//Выбирает информацию о пациентах с фамилиями, начинающимися на заданную параметром последовательность букв

@SuppressLint("StaticFieldLeak")
public class Query01Task extends AsyncTask<String, Void, List<Patient>> {

    private final Context context;
    private final ListView listView;
    private final TextView textView;

    public Query01Task(Context context ,ListView listView , TextView textView) {

        this.listView = listView;
        this.textView = textView;
        this.context = context;
    }
    @SuppressLint("SetTextI18n")
    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        textView.setText("Информация о пациентах с фамилиями, начинающимися на заданную параметром последовательность букв");
    } // onPreExecute

    @Override
    protected List<Patient> doInBackground(String... params) {

        List<Patient> list = null;

        PatientsDatabaseRepository patientsRepository = new PatientsDatabaseRepository(context);
        patientsRepository.open();
        try {
            list = patientsRepository.selectPatientsBySurnameBegin(params[0]);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        patientsRepository.close();

        return list;
    }

    @Override
    protected void onPostExecute(List<Patient> params) {
        super.onPostExecute(params);

        if(params != null) {
            ArrayAdapter<Patient> arrayAdapter = new ArrayAdapter<>(
                    context,
                    android.R.layout.simple_list_item_1,
                    params);

            listView.setAdapter(arrayAdapter);
        }

    }
}
