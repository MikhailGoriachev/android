package org.itstep.pd011.step160323.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;

import org.itstep.pd011.step160323.helpers.Utils;
import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.models.Animal;
import org.itstep.pd011.step160323.models.Breed;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;
import java.util.Locale;

public class AnimalActivity extends AppCompatActivity {

    private EditText edtName, edtAge, edtWeight, edtOwner;
    private ImageView imageAnimal;
    private Animal animal, oldAnimal;
    private Breed selectBreed;

    Spinner spinner;

    private int newAge;
    private double newWeight;
    private Button saveButton;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch swtSpecialDiet, swtFreeKeeping;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);

        // получить параметр из вызывающей активности
        Intent intent = getIntent();
        animal = intent.getParcelableExtra(Animal.class.getCanonicalName());
        oldAnimal = animal.clone();

        edtName = findViewById(R.id.edtName);
        edtAge = findViewById(R.id.edtAge);
        edtWeight = findViewById(R.id.edtWeight);
        edtOwner = findViewById(R.id.edtOwner);
        imageAnimal = findViewById(R.id.imageAnimal);
        swtSpecialDiet = findViewById(R.id.swt_animal_special_diet);
        swtFreeKeeping = findViewById(R.id.swt_animal_free_keeping);
        saveButton = findViewById(R.id.btnSave);
        spinner = findViewById(R.id.spinnerAnimals);

        // адаптер спиннера
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item, Arrays.stream(Utils.Breeds.stream().map(Breed::toString).toArray()).toArray(String[]::new));

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // установка валидаторов (обработчиков ввода)
        setValidators();

        setParamsForEdit();

        newAge = animal.getAge();
        newWeight = animal.getWeight();

        findViewById(R.id.btnBack).setOnClickListener(v -> backClick());
        findViewById(R.id.btnClear).setOnClickListener(this::reset);
        saveButton.setOnClickListener(this::save);

        findViewById(R.id.btnIncAge).setOnClickListener(v -> edtAge.setText(String.format(Locale.UK, "%d", ++newAge)));
        findViewById(R.id.btnDecAge).setOnClickListener(v -> {

            if (newAge - 1 < 0)
                Utils.showError(edtAge, "Возраст не может быть отрицательным!");
            else
                edtAge.setText(String.format(Locale.UK, "%d", --newAge));
        });

        findViewById(R.id.btnIncWeight).setOnClickListener(view -> edtWeight.setText(String.format(Locale.UK, "%.2f", ++newWeight)));
        findViewById(R.id.btnDecWeight).setOnClickListener(view -> {

            if (newWeight - 1 < 0)
                Utils.showError(edtWeight, "Вес не может быть отрицательным!");
            else
                edtWeight.setText(String.format(Locale.UK, "%.2f", --newWeight));
        });

        spinner.setOnItemSelectedListener(listnerSpinner);
    }

    // обработка выбора в выпадающем списке
    AdapterView.OnItemSelectedListener listnerSpinner = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            selectBreed = Utils.Breeds.get(position);
            Utils.setImage(selectBreed.getImage(), imageAnimal, getApplicationContext());
        } // onItemSelected

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
        }
    };

    private void setParamsForEdit() {

        selectBreed = animal.getBreed();
        spinner.setSelection(Utils.Breeds.indexOf(selectBreed));

        Utils.setImage(animal.getBreed().getImage(), imageAnimal, getApplicationContext());
        edtName.setText(animal.getName());
        edtAge.setText(String.format(Locale.UK, "%d", animal.getAge()));
        edtWeight.setText(String.format(Locale.UK, "%.2f", animal.getWeight()));
        edtOwner.setText(animal.getOwner());
        swtSpecialDiet.setChecked(animal.isSpecialDiet());
        swtFreeKeeping.setChecked(animal.isVoluntary());
    }

    // обработка клика по кнопке выхода из активности
    private void backClick() {
        Intent intent = new Intent();

        // данные, возвращаемые из активности
        intent.putExtra(Animal.class.getCanonicalName(), animal);

        // установить результат работы активности
        setResult(AnimalsOptimizedActivity.RESULT_OK, intent);

        // завершить активность
        finish();
    } // back

    //сохранить изменения
    private void save(View view) {
        try {
            animal.setBreed(selectBreed);
            animal.setName(edtName.getText().toString());
            animal.setAge(Integer.parseInt(edtAge.getText().toString()));
            animal.setWeight(Double.parseDouble(edtWeight.getText().toString()));
            animal.setOwner(edtOwner.getText().toString());
            animal.setSpecialDiet(swtSpecialDiet.isChecked());
            animal.setVoluntary(swtFreeKeeping.isChecked());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // сбросить поля ввода
    public void reset(View view) {
        animal = oldAnimal.clone();
        setParamsForEdit();
    }

    // установка валидаторов (обработчиков ввода)
    private void setValidators() {

        Utils.addTextChangedListener(edtName, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtName, (s) -> !s.isEmpty(),
                        "Поле клички должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtAge, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtAge, (s) -> {
                            if (s.isEmpty()) return false;
                            else return Integer.parseInt(s) >= 0;
                        },
                        "Поле возраста должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtWeight, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtWeight, (s) -> {
                            if (s.isEmpty()) return false;
                            else return Double.parseDouble(s) >= 0.1;
                        },
                        "Поле веса должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtOwner, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtOwner, (s) -> !s.isEmpty(),
                        "Поле владельца должно быть заполнено",
                        getApplicationContext())));
    }

}