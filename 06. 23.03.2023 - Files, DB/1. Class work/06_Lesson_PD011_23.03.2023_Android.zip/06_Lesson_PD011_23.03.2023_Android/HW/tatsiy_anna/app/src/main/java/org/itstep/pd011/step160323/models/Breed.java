package org.itstep.pd011.step160323.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.Objects;

public class Breed  implements Parcelable, Cloneable{

    private String title;
    private int image;

    public Breed(String title, int image) {
        this.title = title;
        this.image = image;
    }

    protected Breed(Parcel in) {
        title = in.readString();
        image = in.readInt();
    }

    public static final Creator<Breed> CREATOR = new Creator<Breed>() {
        @Override
        public Breed createFromParcel(Parcel in) {
            return new Breed(in);
        }

        @Override
        public Breed[] newArray(int size) {
            return new Breed[size];
        }
    };

    @NonNull
    @Override
    public Breed clone() {
        try {
            return (Breed) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(title);
        parcel.writeInt(image);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Breed breed = (Breed) o;
        return image == breed.image && Objects.equals(title, breed.title);
    }

    @NonNull
    @Override
    public String toString() {
        return  title;
    }
}
