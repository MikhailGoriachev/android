package org.itstep.pd011.step270323.models;

public class Doctor {
    private long id;       // ид
    private String surname;
    private String name;
    private String patronymic;
    private int id_specialtie;
    private double tax;

    public Doctor(long id, String surname, String name, String patronymic, int id_specialtie, double tax) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.id_specialtie = id_specialtie;
        this.tax = tax;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public int getId_specialtie() {
        return id_specialtie;
    }

    public void setId_specialtie(int id_specialtie) {
        this.id_specialtie = id_specialtie;
    }

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    @Override
    public String toString() {
        return
                "id: " + id + "\n" +
                "фамилия: " + surname + "\n" +
                "имя: " + name + "\n" +
                "отчество: " + patronymic + "\n" +
                "id специальности: " + id_specialtie + "\n"+
                "процент отчисления: " + tax;
    }
}
