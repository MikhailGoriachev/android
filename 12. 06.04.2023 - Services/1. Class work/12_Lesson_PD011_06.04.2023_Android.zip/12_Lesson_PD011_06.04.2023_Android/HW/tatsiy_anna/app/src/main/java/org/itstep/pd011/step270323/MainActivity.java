package org.itstep.pd011.step270323;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import org.itstep.pd011.step270323.activities.DoctorsActivity;
import org.itstep.pd011.step270323.activities.PatientsActivity;
import org.itstep.pd011.step270323.activities.QueriesActivity;
import org.itstep.pd011.step270323.activities.ReceptsActivity;
import org.itstep.pd011.step270323.activities.SpecialtiesActivity;
import org.itstep.pd011.step270323.activities.TableActivity;
import org.itstep.pd011.step270323.activities.WebServiceActivity;
import org.itstep.pd011.step270323.activities.WebViewActivity;
import org.itstep.pd011.step270323.converters.DoctorConverter;
import org.itstep.pd011.step270323.converters.PatientConverter;
import org.itstep.pd011.step270323.converters.ReceiptConverter;
import org.itstep.pd011.step270323.helpers.JsonHelper;
import org.itstep.pd011.step270323.entities.Doctor;
import org.itstep.pd011.step270323.entities.Patient;
import org.itstep.pd011.step270323.entities.Receipt;
import org.itstep.pd011.step270323.repositories.DoctorsDatabaseRepository;
import org.itstep.pd011.step270323.repositories.PatientsDatabaseRepository;
import org.itstep.pd011.step270323.repositories.ReceptsDatabaseRepository;
import java.text.ParseException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnActivityTable).setOnClickListener(v-> startActivity(new Intent(this, TableActivity.class)));
        findViewById(R.id.btnActivityRecepts).setOnClickListener(v-> startActivity(new Intent(this, ReceptsActivity.class)));
        findViewById(R.id.btnActivityTask05).setOnClickListener(v-> startActivity(new Intent(this, QueriesActivity.class)));
        findViewById(R.id.btnLoadData).setOnClickListener(v-> new saveToJSONTask().execute());
        findViewById(R.id.btnShowWebView).setOnClickListener(v->startActivity(new Intent(this, WebViewActivity.class)));
        findViewById(R.id.btnShowWebService).setOnClickListener(v->startActivity(new Intent(this, WebServiceActivity.class)));
    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // обработка выбора в меню по ид пункта
        switch (item.getItemId()) {
            case R.id.mniActivityTable:
                startActivity(new Intent(this, TableActivity.class));
                break;

            case R.id.mniActivity05:
                startActivity(new Intent(this, QueriesActivity.class));
                break;

            case R.id.mniExit:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected

    //Реализуйте выгрузку таблиц ВРАЧИ, ПАЦИЕНТЫ, ПРИЕМ в файлы формата JSON.
    private class saveToJSONTask extends AsyncTask<Void, Void, Boolean>{

        @Override
        protected Boolean doInBackground(Void... params){

            DoctorsDatabaseRepository doctorsRepository = new DoctorsDatabaseRepository(MainActivity.this);
            PatientsDatabaseRepository patientsRepository = new PatientsDatabaseRepository(MainActivity.this);
            ReceptsDatabaseRepository receptsRepository = new ReceptsDatabaseRepository(MainActivity.this);

            doctorsRepository.open();
            List<Doctor> doctors = doctorsRepository.getDoctors();
            doctorsRepository.close();

            List<Patient> patients = null;
            List<Receipt> receipts = null;

            try {
                patientsRepository.open();
                patients = patientsRepository.getPatients();
                patientsRepository.close();

                receptsRepository.open();
                receipts = receptsRepository.getReceipts();
                receptsRepository.close();

            } catch (ParseException e) {
                throw new RuntimeException(e);
            }

            //данные не были прочитаны !
            if(patients == null || receipts == null) return false;

            return (
                    new JsonHelper<Doctor>().exportToJSON(MainActivity.this, doctors, "doctors.json", new DoctorConverter() , Doctor.class) &&
                            new JsonHelper<Patient>().exportToJSON(MainActivity.this,patients, "patients.json", new PatientConverter(), Patient.class) &&
                            new JsonHelper<Receipt>().exportToJSON(MainActivity.this,receipts, "receipts.json", new ReceiptConverter(), Receipt.class));

        }

        // вывод финишного сообщения
        @Override
        protected void onPostExecute(Boolean result){
            super.onPostExecute(result);

            Toast.makeText(MainActivity.this, result?"Данные сохранены":"Не удалось сохранить данные", Toast.LENGTH_LONG).show();
        }
    }
}