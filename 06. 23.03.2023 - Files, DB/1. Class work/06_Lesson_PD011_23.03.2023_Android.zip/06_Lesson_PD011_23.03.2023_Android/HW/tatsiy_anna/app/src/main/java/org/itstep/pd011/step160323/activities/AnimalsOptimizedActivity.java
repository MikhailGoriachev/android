package org.itstep.pd011.step160323.activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.adapters.AnimalsOptimizedAdapter;
import org.itstep.pd011.step160323.helpers.Utils;
import org.itstep.pd011.step160323.models.Animal;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AnimalsOptimizedActivity extends AppCompatActivity {

    private List<Animal> animals;
    private int position;
    public static final int
            ID_ANIMAL_ACTIVITY_EDIT = 1010,
            ID_ANIMAL_ACTIVITY_ADD = 1012;
    private AnimalsOptimizedAdapter animalsOptimizedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animals_optimized);

        initializer();

        RecyclerView rcvModAnimals = findViewById(R.id.lsvAnimalsOptimizedAdapter);
        animalsOptimizedAdapter = new AnimalsOptimizedAdapter(this, animals, this::startAnimalsActivity);
        rcvModAnimals.setAdapter(animalsOptimizedAdapter);
    }

    void initializer() {
        animals = new ArrayList<>(List.of(
                new Animal(Utils.Breeds.get(0), "Феня", 10, 12.5, "Петрова А. Н.", false, false),
                new Animal(Utils.Breeds.get(1),"Лева", 3, 25.5, "Иванов И. Н.",true,false),
                new Animal(Utils.Breeds.get(2),"Багира", 5, 8, "Колпакова Т. Г.",false,false),
                new Animal(Utils.Breeds.get(1),"Боня", 5, 30.5, "Иванов И. Н.",true,true),
                new Animal(Utils.Breeds.get(2),"Барсик", 10, 10.4, "Колпакова Т. Г.",true,false)
        ));
    }

    // обработчик клика по кнопке вызова активности для Animal
    private void startAnimalsActivity(Animal animal ){

        Intent intent = new Intent(this, AnimalActivity.class);

        // передача параметра в активность
        intent.putExtra(Animal.class.getCanonicalName(), animal);

        startActivityForResult(intent,ID_ANIMAL_ACTIVITY_EDIT);
    }

    // обработчик события получения данных из другой активности
    // (функция обратного вызова)
    // requestCode - идентфикатор активности
    // resultCode - код завершения работы в активности
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK) {
            Toast.makeText(this,
                            String.format(Locale.UK, "Ошибка %d в активности с кодом %d", resultCode, requestCode),
                            Toast.LENGTH_LONG)
                    .show();
        } // if

        else {

            assert data != null;
            Animal animal = data.getParcelableExtra(Animal.class.getCanonicalName());

            switch (requestCode){
                case ID_ANIMAL_ACTIVITY_EDIT:
                    animals.set(position,animal);
                    break;

                case ID_ANIMAL_ACTIVITY_ADD:
                    animals.add(animal);
                    break;
            }

            animalsOptimizedAdapter.myNotifyDataSetChanged();
        }

    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mniAdd:

                //TODO: переделать
                Intent intent = new Intent(this, AnimalActivity.class);

                // передача параметра в активность
                intent.putExtra(Animal.class.getCanonicalName(), new Animal());

                startActivityForResult(intent,ID_ANIMAL_ACTIVITY_ADD);
                //TODO: переделать

                break;

            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected
}

