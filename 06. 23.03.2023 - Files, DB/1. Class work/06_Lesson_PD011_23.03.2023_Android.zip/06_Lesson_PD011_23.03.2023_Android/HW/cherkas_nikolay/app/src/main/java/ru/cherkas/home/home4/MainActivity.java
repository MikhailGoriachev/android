package ru.cherkas.home.home4;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import ru.cherkas.home.home4.activities.AnimalActivity;
import ru.cherkas.home.home4.activities.ChipActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    // переход на страницу животные
    public void pageAnimalsClick(View view) {
        Intent intent = new Intent(this, AnimalActivity.class);
        startActivity(intent);
    }
    // переход на страницу корабли
    public void pagesChipClick(View view) {
        Intent intent = new Intent(this, AnimalActivity.class);
        startActivity(intent);
    }
    public void exitClick(View view) {
        finishAffinity();
    }

    // menu
    public void menuChipClick(MenuItem item) {
        Intent intent = new Intent(this, ChipActivity.class);
        startActivity(intent);
    }
    public void menuAnimalClick(MenuItem item) {
        Intent intent = new Intent(this, AnimalActivity.class);
        startActivity(intent);
    }
    public void menuExitClick(MenuItem item) {
        finishAffinity();
    }


}