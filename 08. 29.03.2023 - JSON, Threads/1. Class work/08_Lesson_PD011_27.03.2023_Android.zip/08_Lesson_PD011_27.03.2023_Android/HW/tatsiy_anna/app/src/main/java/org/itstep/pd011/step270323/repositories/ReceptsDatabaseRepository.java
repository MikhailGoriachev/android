package org.itstep.pd011.step270323.repositories;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import org.itstep.pd011.step270323.helpers.DatabaseHelper;
import org.itstep.pd011.step270323.models.Patient;
import org.itstep.pd011.step270323.models.Receipt;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class ReceptsDatabaseRepository {

    // поля для работы с БД
    private final DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    // название таблицы в БД
    static final String TABLE = "Receipts";

    // названия столбцов
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_PRICE = "price";
    public static final String COLUMN_ID_PATIENT = "id_patient";
    public static final String COLUMN_ID_DOCTOR = "id_doctor";

    @SuppressLint("SimpleDateFormat")
    private static final DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

    public  ReceptsDatabaseRepository(Context context){
        dbHelper = new DatabaseHelper(context.getApplicationContext());
        dbHelper.create_db();
    } // DatabaseRepository

    public ReceptsDatabaseRepository open(){
        database = dbHelper.open();
        return this;
    } // open

    public void close(){ dbHelper.close(); }

    private Cursor getAllEntries(){

        String[] columns = new String[] {COLUMN_ID, COLUMN_DATE, COLUMN_PRICE, COLUMN_ID_PATIENT, COLUMN_ID_DOCTOR};

        return  database.query(
                TABLE, columns, null, null, null,
                null, null);
    } // getAllEntries

    // метод паттерна Репозиторий
    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, TABLE);
    }

    // возвращает коллекцию из таблицы БД
    @SuppressLint("Range")
    public List<Receipt> getReceipts() throws ParseException {
        ArrayList<Receipt> receipts = new ArrayList<>();
        Cursor cursor = getAllEntries();  // запрос к БД
        if(cursor.moveToFirst()){
            do{
                // добавление в коллекцию объекта Patient
                receipts.add(getReceiptFromCursor(cursor));
            } while (cursor.moveToNext());
        } // if
        cursor.close();
        return receipts;
    }

    // получить 1 запись по id
    @SuppressLint("Range")
    public Receipt getReceipt(long id) throws ParseException {
        Receipt receipt = null;

        String query = String.format(
                "SELECT * FROM %s WHERE %s=?",
                TABLE,
                COLUMN_ID);

        Cursor cursor = database.rawQuery(query, new String[]{String.valueOf(id)});

        // чтение данных, если они получены
        if(cursor.moveToFirst()){
            receipt = getReceiptFromCursor(cursor);
        } // if

        cursor.close();
        return receipt;
    }

    // метод - оболочка для запроса insert
    public long insert(Receipt receipt){
        return database.insert(TABLE, null, getContentValues(receipt));
    } // insert

    // метод - оболочка для запроса update
    public long update(Receipt receipt){
        return database.update(TABLE, getContentValues(receipt), COLUMN_ID + "=" + receipt.getId(), null);
    } // update

    private ContentValues getContentValues(Receipt receipt){

        ContentValues cv = new ContentValues();

        cv.put(COLUMN_DATE, formatter.format(receipt.getDate()));
        cv.put(COLUMN_PRICE, receipt.getPrice());
        cv.put(COLUMN_ID_PATIENT, receipt.getId_patient());
        cv.put(COLUMN_ID_DOCTOR, receipt.getId_doctor());

        return cv;
    }

    @SuppressLint("Range")
    private Receipt getReceiptFromCursor(Cursor cursor) throws ParseException {

        return new Receipt(
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID)),
                formatter.parse(cursor.getString(cursor.getColumnIndex(COLUMN_DATE))),
                cursor.getInt(cursor.getColumnIndex(COLUMN_PRICE)),
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID_PATIENT)),
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID_DOCTOR)));
    }
}
