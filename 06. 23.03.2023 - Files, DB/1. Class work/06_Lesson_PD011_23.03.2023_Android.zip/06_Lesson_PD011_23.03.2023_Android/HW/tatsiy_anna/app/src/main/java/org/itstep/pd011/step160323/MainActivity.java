package org.itstep.pd011.step160323;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import org.itstep.pd011.step160323.activities.AnimalActivity;
import org.itstep.pd011.step160323.activities.AnimalsOptimizedActivity;
import org.itstep.pd011.step160323.activities.ShipsActivity;
import org.itstep.pd011.step160323.activities.ShipsOptimizedActivity;
import org.itstep.pd011.step160323.models.Animal;
import org.itstep.pd011.step160323.models.Ship;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnAnimalActivity).setOnClickListener(v-> startActivity(new Intent(this, AnimalsOptimizedActivity.class)));
        findViewById(R.id.btnShipActivity).setOnClickListener(v->startActivity(new Intent(this, ShipsOptimizedActivity.class)));
    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // обработка выбора в меню по ид пункта
        switch (item.getItemId()) {
            case R.id.mniAnimalActivity:
                startActivity(new Intent(this, AnimalsOptimizedActivity.class));
                break;
            case R.id.mniShipActivity:
                startActivity(new Intent(this, ShipsOptimizedActivity.class));
                break;
            case R.id.mniExit:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected

    // обработчик клика по кнопке "Выход"
    public void exitClick(View view) {
        // завершает активность, но не приложение
        finish();
    } // exitClick
}