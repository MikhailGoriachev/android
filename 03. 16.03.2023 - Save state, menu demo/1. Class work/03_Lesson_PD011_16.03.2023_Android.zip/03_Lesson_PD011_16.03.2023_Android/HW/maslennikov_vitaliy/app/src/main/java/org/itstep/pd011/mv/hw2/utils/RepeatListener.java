package org.itstep.pd011.mv.hw2.utils;

import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

// Класс, с обработчиком касаний View элементов и реализующий логику повторений действия
public class RepeatListener implements View.OnTouchListener {

    // обработчик для управления вызовами Runnable-коллбэка
    private final Handler handler = new Handler();

    // интервал между первым вызовом действия и последующими
    private final int initialInterval;

    // интервал между последующими вызовами действий
    private final int normalInterval;

    // слушатель клика на элементе, принимается параметром при создании объекта этого класса,
    // содержит логику обработки кликов
    private final View.OnClickListener clickListener;

    // ссылка на текущий элемент, касание которого обрабатывается
    private View touchedView;

    // конструктор, принимает стартовый интервал, последующие и обработчик кликов для элемента
    public RepeatListener(int initialInterval, int normalInterval,
                          View.OnClickListener clickListener) {
        if (clickListener == null)
            throw new IllegalArgumentException("null runnable");
        if (initialInterval < 0 || normalInterval < 0)
            throw new IllegalArgumentException("negative interval");

        this.initialInterval = initialInterval;
        this.normalInterval = normalInterval;
        this.clickListener = clickListener;
    }

    // обработчик событий касания элемента
    public boolean onTouch(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            // касание элемента - первая обработка
            case MotionEvent.ACTION_DOWN:
                handler.removeCallbacks(handlerRunnable);
                // добавить в очередь выполнение коллбэка
                handler.postDelayed(handlerRunnable, initialInterval);
                touchedView = view;
                touchedView.setPressed(true);
                // первый вызов обработки клика по элементу
                clickListener.onClick(view);
                return true;
            // отсутствие касания - удалить коллбэки
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(handlerRunnable);
                touchedView.setPressed(false);
                touchedView = null;
                return true;
        }
        return false;
    }

    // Runnable-коллбэк, срабатываемый по интервалу для цикличного выполнения действия клика
    private final Runnable handlerRunnable = new Runnable() {
        @Override
        public void run() {
            if (touchedView.isEnabled()) {
                // зарегистрировать в хэндлере выполнение этого же коллбэка через интервал времени
                handler.postDelayed(this, normalInterval);
                // вызов обработки клика по элементу
                clickListener.onClick(touchedView);
            } else {
                // если элемент стал disabled - удалить коллбэк из очереди
                handler.removeCallbacks(handlerRunnable);
                touchedView.setPressed(false);
                touchedView = null;
            }
        }
    };
}