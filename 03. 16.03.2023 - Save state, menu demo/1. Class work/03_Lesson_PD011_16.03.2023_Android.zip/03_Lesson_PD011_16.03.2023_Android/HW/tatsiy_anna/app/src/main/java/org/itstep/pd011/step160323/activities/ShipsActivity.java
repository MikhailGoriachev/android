package org.itstep.pd011.step160323.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import org.itstep.pd011.step160323.Helpers.Utils;
import org.itstep.pd011.step160323.MainActivity;
import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.models.Ship;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public class ShipsActivity extends AppCompatActivity {

    private EditText edtType, edtCapacity, edtDestination, edtCargoType, edtWeight, edtCostOf1Ton;

    private TextView txtTotalCost;
    private ImageView imageShip;

    private Ship ship;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ships);

        // получить параметр из вызывающей активности
        Intent intent = getIntent();
        ship = intent.getParcelableExtra(Ship.class.getCanonicalName());

        edtType = findViewById(R.id.edtType);
        edtCapacity = findViewById(R.id.edtCapacity);
        edtDestination = findViewById(R.id.edtDestination);
        edtCargoType = findViewById(R.id.edtCargoType);
        edtWeight = findViewById(R.id.edtWeight);
        edtCostOf1Ton = findViewById(R.id.edtCostOf1Ton);

        txtTotalCost = findViewById(R.id.txtTotalCost);
        txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));

        edtType.setText(ship.getType());
        edtCapacity.setText(String.format(Locale.UK, "%d", ship.getCapacity()));
        edtDestination.setText(ship.getDestination());
        edtCargoType.setText(ship.getCargoType());
        edtWeight.setText(String.format(Locale.UK, "%d", ship.getWeight()));
        edtCostOf1Ton.setText(String.format(Locale.UK, "%d", ship.getCostOf1Ton()));

        // чтение файла изображения из assets и вывод его в ImageView
        // получить файл с изображением и поместить его в ImageView
        imageShip = findViewById(R.id.imageShip);
        try (InputStream inputStream = getApplicationContext().getAssets().open(ship.getImage())) {
            Drawable drawable = Drawable.createFromStream(inputStream, null);

            imageShip.setImageDrawable(drawable);
            imageShip.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        } catch (IOException e) {
            Snackbar snackbar = Snackbar.make(imageShip, "Ошибка чтения файла изображения", Snackbar.LENGTH_INDEFINITE);
            snackbar.setAction("OK", v -> {
            });
            snackbar.show();
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> backClick());
        findViewById(R.id.btnClear).setOnClickListener(v -> clearEdt());

        edtCostOf1Ton.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setCostOf1Ton(Integer.parseInt(edtCostOf1Ton.getText().toString()));
                        txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));
                    } catch (Exception e) {
                        Utils.showError(edtCostOf1Ton, e.getMessage());
                    }
                }
            }
        });

        edtWeight.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setWeight(Integer.parseInt(edtWeight.getText().toString()));
                        txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));
                    } catch (Exception e) {
                        Utils.showError(edtWeight, e.getMessage());
                    }
                }
            }
        });

        edtCargoType.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setCargoType(edtCargoType.getText().toString());
                    } catch (Exception e) {
                        Utils.showError(edtCargoType, e.getMessage());
                    }
                }
            }
        });

        edtDestination.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setDestination(edtDestination.getText().toString());
                    } catch (Exception e) {
                        Utils.showError(edtDestination, e.getMessage());
                    }
                }
            }
        });

        edtCapacity.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setCapacity(Integer.parseInt(edtCapacity.getText().toString()));
                    } catch (Exception e) {
                        Utils.showError(edtCapacity, e.getMessage());
                    }
                }
            }
        });

        edtType.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setType(edtType.getText().toString());
                    } catch (Exception e) {
                        Utils.showError(edtType, e.getMessage());
                    }
                }
            }
        });

        findViewById(R.id.btnIncWeight).setOnClickListener(view -> {
            lostFocus();
            try {
                ship.setWeight(ship.getWeight() + 20);
                txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));
                edtWeight.setText(String.format(Locale.UK, "%d", ship.getWeight()));
            } catch (Exception e) {
                Utils.showError(edtWeight, e.getMessage());
            }

        });

        findViewById(R.id.btnDecWeight).setOnClickListener(view -> {
            lostFocus();
            try {
                ship.setWeight(ship.getWeight() - 20);
                txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));
                edtWeight.setText(String.format(Locale.UK, "%d", ship.getWeight()));
            } catch (Exception e) {
                Utils.showError(edtWeight, e.getMessage());
            }
        });
    }

    //кнопка для очистки полей ввода
    private void clearEdt() {
        lostFocus();
        txtTotalCost.setText("");
        edtType.setText("");
        edtCapacity.setText("0");
        edtDestination.setText("");
        edtCargoType.setText("");
        edtWeight.setText("0");
        edtCostOf1Ton.setText("0");
    }

    // обработка клика по кнопке выхода из активности
    private void backClick() {
        lostFocus();
        Intent intent = new Intent();

        // данные, возвращаемые из активности
        intent.putExtra(Ship.class.getCanonicalName(), ship);

        // установить результат работы активности
        setResult(MainActivity.RESULT_OK, intent);

        // завершить активность
        finish();
    } // back

    //снимаем фокус со всех полей для сохранения данных
    private void lostFocus() {
        edtType.setFocusable(false);
        edtCapacity.setFocusable(false);
        edtDestination.setFocusable(false);
        edtCargoType.setFocusable(false);
        edtWeight.setFocusable(false);
        edtCostOf1Ton.setFocusable(false);
    }
}