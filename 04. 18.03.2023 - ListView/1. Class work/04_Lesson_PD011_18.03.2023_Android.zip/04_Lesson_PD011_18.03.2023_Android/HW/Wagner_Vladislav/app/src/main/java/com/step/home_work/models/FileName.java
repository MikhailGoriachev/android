package com.step.home_work.models;

public class FileName {
    public String field;
    public String fileName;

    public FileName(String field, String fileName) {
        this.field = field;
        this.fileName = fileName;
    }
}
