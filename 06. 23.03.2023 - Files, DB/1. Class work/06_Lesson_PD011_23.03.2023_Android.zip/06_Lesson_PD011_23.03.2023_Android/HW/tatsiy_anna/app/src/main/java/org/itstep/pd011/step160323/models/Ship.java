package org.itstep.pd011.step160323.models;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;

import org.itstep.pd011.step160323.helpers.Utils;

public class Ship implements Parcelable, Cloneable {

    private String type; //название типа судна
    private int capacity; //грузоподъемность
    private int image; //имя файла с изображением
    private String destination; //пункт назначения
    private String cargoType; //тип груза
    private int weight; //вес
    private int costOf1Ton; //стоимость 1 тонны груза

    private boolean anchorage; //якорная стоянка
    private boolean refueling; //дозаправка топливом
    private boolean pilot; //лоцман

    protected Ship(Parcel in) {
        type = in.readString();
        capacity = in.readInt();
        image = in.readInt();
        destination = in.readString();
        cargoType = in.readString();
        weight = in.readInt();
        costOf1Ton = in.readInt();
        anchorage = in.readByte() != 0;
        refueling = in.readByte() != 0;
        pilot = in.readByte() != 0;
    }

    public static final Creator<Ship> CREATOR = new Creator<Ship>() {
        @Override
        public Ship createFromParcel(Parcel in) {
            return new Ship(in);
        }

        @Override
        public Ship[] newArray(int size) {
            return new Ship[size];
        }
    };

    public int totalCost(){
        return weight*costOf1Ton;
    }

    public Ship() {
        this(TypeShip.BULK.getTitle(),
                120200,
                TypeShip.BULK.getImage(),
                "Таганрог",
                "каменный уголь",
                110200,
                100,
                false,false,false);
    }

    public Ship(String type, int capacity, int image, String destination, String cargoType, int weight, int costOf1Ton, boolean anchorage, boolean refueling, boolean pilot) {
        this.type = type;
        this.capacity = capacity;
        this.image = image;
        this.destination = destination;
        this.cargoType = cargoType;
        this.weight = weight;
        this.costOf1Ton = costOf1Ton;
        this.anchorage = anchorage;
        this.refueling = refueling;
        this.pilot = pilot;
    }

    public String getType() {
        return type;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getImage() {
        return image;
    }

    public String getDestination() {
        return destination;
    }

    public String getCargoType() {
        return cargoType;
    }

    public int getWeight() {
        return weight;
    }

    public int getCostOf1Ton() {
        return costOf1Ton;
    }

    public boolean isAnchorage() {
        return anchorage;
    }

    public boolean isRefueling() {
        return refueling;
    }

    public boolean isPilot() {
        return pilot;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setCapacity(int capacity) throws Exception {
        if (capacity > 0){
            throw new Exception("грузоподъемность не может быть < веса груза!");
        }
        this.capacity = capacity;
    }

    public void setDestination(String destination) throws Exception {
        //проверка строки на пустоту
        if (destination == null || destination.isEmpty()){
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.destination = destination;
    }

    public void setCargoType(String cargoType) throws Exception {
        //проверка строки на пустоту
        if (cargoType == null || cargoType.isEmpty()){
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.cargoType = cargoType;
    }
    public void setWeight(int weight) throws Exception {

        if (weight < 0){
            throw new Exception("Вес груза не может быть < 0!");
        }

        this.weight = weight;
    }

    public void setCostOf1Ton(int costOf1Ton) throws Exception {

        if (costOf1Ton < 0){
            throw new Exception("Cтоимость 1 тонны груза не может быть < 0 руб!");
        }
        this.costOf1Ton = costOf1Ton;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public void setAnchorage(boolean anchorage) {
        this.anchorage = anchorage;
    }

    public void setRefueling(boolean refueling) {
        this.refueling = refueling;
    }

    public void setPilot(boolean pilot) {
        this.pilot = pilot;
    }

    @NonNull
    @Override
    public Ship clone() {
        try {
            return (Ship) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    @Override
    public String toString() {
        return "Ship{" +
                "type='" + type + '\'' +
                ", capacity=" + capacity +
                ", image=" + image +
                ", destination='" + destination + '\'' +
                ", cargoType='" + cargoType + '\'' +
                ", weight=" + weight +
                ", costOf1Ton=" + costOf1Ton +
                ", anchorage=" + anchorage +
                ", refueling=" + refueling +
                ", pilot=" + pilot +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(type);
        parcel.writeInt(capacity);
        parcel.writeInt(image);
        parcel.writeString(destination);
        parcel.writeString(cargoType);
        parcel.writeInt(weight);
        parcel.writeInt(costOf1Ton);
        parcel.writeByte((byte) (anchorage ? 1 : 0));
        parcel.writeByte((byte) (refueling ? 1 : 0));
        parcel.writeByte((byte) (pilot ? 1 : 0));
    }

    public static Ship generate(){

         Ship ship = new Ship();

         switch (Utils.getInt(1,4))
         {
             case 1:
                 ship.setType(TypeShip.BULK.getTitle());
                 ship.setImage(TypeShip.BULK.getImage());
                 break;

             case 2:
                 ship.setType(TypeShip.CONTAINER.getTitle());
                 ship.setImage(TypeShip.CONTAINER.getImage());
                 break;

             default:
                 ship.setType(TypeShip.CARGO.getTitle());
                 ship.setImage(TypeShip.CARGO.getImage());
                 break;
         }

         return ship;
    }
}
