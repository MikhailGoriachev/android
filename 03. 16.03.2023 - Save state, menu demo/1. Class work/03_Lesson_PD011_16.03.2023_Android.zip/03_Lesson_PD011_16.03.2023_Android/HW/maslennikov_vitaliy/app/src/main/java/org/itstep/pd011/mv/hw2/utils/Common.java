package org.itstep.pd011.mv.hw2.utils;

public class Common {

    public static int decimalPlaces(double value) {
        int decimalPlaces = 0;
        while (value != Math.floor(value)) {
            value *= 10;
            decimalPlaces++;
        }
        return decimalPlaces;
    }
}
