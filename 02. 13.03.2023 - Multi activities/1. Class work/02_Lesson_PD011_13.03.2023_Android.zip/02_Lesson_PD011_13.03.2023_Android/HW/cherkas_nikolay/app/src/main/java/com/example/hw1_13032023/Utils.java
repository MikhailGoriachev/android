package com.example.hw1_13032023;

public class Utils {
    public static int getRandInteger(int lo, int hi){
        return (int)(Math.random()*((hi-lo)+1))+lo;
    }
}
