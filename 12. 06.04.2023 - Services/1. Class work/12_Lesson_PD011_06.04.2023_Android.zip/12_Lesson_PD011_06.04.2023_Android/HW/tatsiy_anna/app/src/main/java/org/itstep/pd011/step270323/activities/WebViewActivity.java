package org.itstep.pd011.step270323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.itstep.pd011.step270323.R;

import java.util.Scanner;

public class WebViewActivity extends AppCompatActivity {

    WebView wbvMain;      // элемент отображения HTML-страниц

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        // получить и настроить WebView, включение использования JavaScript
        wbvMain = findViewById(R.id.wbv);
        WebSettings webSettings = wbvMain.getSettings();
        webSettings.setJavaScriptEnabled(true);

        loadFile();
    }

    // загрузка контента из HTML-файла в assets
    private void loadFile() {
        // буфер для чтения данных из файла
        StringBuilder sb = new StringBuilder();
        try (Scanner sc = new Scanner(getAssets().open("info.html"))) {
            while(sc.hasNext()) {
                sb.append(sc.nextLine()).append("\n");
            } // while

            // загрузка данных из буфера строки
            wbvMain.loadData(sb.toString(), "text/html", "UTF-8");
        } catch (Exception e) {
            Log.d("MyApp", "Ошибка " + e.getMessage());
        } // try-catch
    } // loadFile

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected
}