package org.goriachev.homework.models;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ShipType {

    // название
    private String name;

    // имя файла
    private String fileName;
}
