package org.goriachev.homework.infrastructure;

public interface ResultCode {
    int RESULT_OK = 0;
    int RESULT_ERROR = 1;
}
