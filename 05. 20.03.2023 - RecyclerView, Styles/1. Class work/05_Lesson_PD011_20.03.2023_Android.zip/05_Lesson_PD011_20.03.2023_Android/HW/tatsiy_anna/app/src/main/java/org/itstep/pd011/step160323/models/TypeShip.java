package org.itstep.pd011.step160323.models;

import org.itstep.pd011.step160323.R;

public enum TypeShip {
    BULK(R.drawable.type_ship01,"Балкер"),
    CONTAINER(R.drawable.type_ship02,"Контейнеровоз"),
    CARGO(R.drawable.type_ship03,"Сухогруз");

    private int image;
    private String title;

    public int getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

    TypeShip(int image, String title) {

        this.image = image;
        this.title = title;
    }
}
