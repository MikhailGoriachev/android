package org.itstep.pd011.step270323.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import org.itstep.pd011.step270323.fragments.WebServicePageFragment;
import org.itstep.pd011.step270323.services.Api;

public class WebServicePageAdapter  extends FragmentStateAdapter {

    public WebServicePageAdapter(FragmentActivity fragmentActivity) {
        super(fragmentActivity);

    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return WebServicePageFragment.newInstance(position);
    }

    // количество страниц - обязательно т.к. FragmentStateAdapter - абстрактный...
    @Override
    public int getItemCount() {
        return 4;
    }
}
