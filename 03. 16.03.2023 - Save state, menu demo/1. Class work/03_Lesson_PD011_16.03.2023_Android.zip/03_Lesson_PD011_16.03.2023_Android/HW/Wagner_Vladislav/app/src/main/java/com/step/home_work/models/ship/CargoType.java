package com.step.home_work.models.ship;

public class CargoType {
    public String type;
    public int tonPrice;

    public CargoType(String type, int tonPrice) {
        this.type = type;
        this.tonPrice = tonPrice;
    }
}
