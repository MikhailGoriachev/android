package org.itstep.pd011.step160323;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import org.itstep.pd011.step160323.activities.AnimalActivity;
import org.itstep.pd011.step160323.activities.AnimalsOptimizedActivity;
import org.itstep.pd011.step160323.activities.ShipsActivity;
import org.itstep.pd011.step160323.models.Animal;
import org.itstep.pd011.step160323.models.Ship;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // коды активностей для вызова
    public static final int
                            ID_SHIP_ACTIVITY = 1020;

    private Ship ship;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ship = new Ship();

        findViewById(R.id.btnAnimalActivity).setOnClickListener(v-> startActivity(new Intent(this, AnimalsOptimizedActivity.class)));
        findViewById(R.id.btnShipActivity).setOnClickListener(v->startShipsActivity());
    }


    // обработчик клика по кнопке вызова активности для Ships
    private void startShipsActivity(){

        Intent intent = new Intent(this, ShipsActivity.class);

        // передача параметра в активность
        intent.putExtra(Ship.class.getCanonicalName(), ship);

        // запуск активнсти с возвратом результата
        startActivityForResult(intent,ID_SHIP_ACTIVITY);
    }

    // обработчик клика по кнопке "Выход"
    public void exitClick(View view) {
        // завершает активность, но не приложение
        finish();
    } // exitClick
}