package org.itstep.pd011.step160323.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.activities.AnimalsOptimizedActivity;
import org.itstep.pd011.step160323.activities.ShipsActivity;
import org.itstep.pd011.step160323.models.Animal;

import java.util.List;
import java.util.function.Consumer;

import kotlin.Function;

public class AnimalsOptimizedAdapter extends ArrayAdapter<Animal> {

    private final LayoutInflater inflater;     // загрузчик разметки элемента - из контекста создания - активность или фрагмент
    private final int            layout;       // ид разметки элемента списка
    private final List<Animal> animalList;      // коллекция данных
    private final Consumer<Integer> consumer;

    // для создания адаптера в точке вызова
    public AnimalsOptimizedAdapter(@NonNull Context context, int resource, @NonNull List<Animal> animals, Consumer<Integer> consumer ){
        super(context, resource, animals);

        this.layout = resource;
        this.inflater = LayoutInflater.from(context);
        this.animalList = animals;
        this.consumer = consumer;
    }

    public View getView(int position, View convertView, ViewGroup parent){

        // 2й вариант оптимизации - использование ViewHolder - внутренний класс
        final ViewHolder viewHolder;

        if (convertView == null) {
            convertView = inflater.inflate(this.layout, parent, false);
            viewHolder = new ViewHolder(convertView, position);

            // сохранить все ссылки на элементы разметки
            // в поле tag convertView, тип tag - Object
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            viewHolder.position = position;
        } // if

        Animal animal = animalList.get(position);

        // вывести поля объекта в элементы интерфейса
        // поместить данные из очередного элемента коллекции в элементы
        // отображения
        viewHolder.imgAnimal.setImageResource(animal.getImage());
        viewHolder.txvName.setText(animal.getName());
        viewHolder.txvBreed.setText(animal.getBreed());
        viewHolder.txvOwner.setText(animal.getOwner());

        // вернуть сформированное представление элемента списка
        return convertView;
    }

    // класс ViewHolder - хранит ссылки на элементы разметки
    // исключает повторные операции поиска элементов в разметке
    private class ViewHolder {
        // элементы интерфейса из разметки элемента
        final ImageView imgAnimal;
        final TextView txvName;
        final TextView txvBreed;
        final TextView txvOwner;

        final LinearLayout llTextViews;

        private int position;

        public ViewHolder(View view, int position) {
            // связать разметку и ссылки на элементы отображения
            imgAnimal = view.findViewById(R.id.imgItem);
            txvName = view.findViewById(R.id.txvName);
            txvBreed = view.findViewById(R.id.txvBreed);
            txvOwner = view.findViewById(R.id.txvOwner);

            llTextViews = view.findViewById(R.id.llTextViews);

            // позиция элемента в коллекции
            this.position = position;

            // назначаем обработчика клика по элементам разметки, т.к. клик в
            // основной активности блокируется слушателями кнопками
            llTextViews.setOnClickListener(v->onClickListner(v, this.position));
            imgAnimal.setOnClickListener(v->onClickListner(v, this.position));

        } // ViewHolder
    } // class ViewHolder

    private void onClickListner(View view, int position) {
         this.consumer.accept(position);
         notifyDataSetChanged();
    }
}
