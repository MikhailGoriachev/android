package org.itstep.pd011.mv.hw2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import org.itstep.pd011.mv.hw2.activities.PetActivity;
import org.itstep.pd011.mv.hw2.activities.ShipActivity;
import org.itstep.pd011.mv.hw2.databinding.ActivityMainBinding;
import org.itstep.pd011.mv.hw2.models.Pet;
import org.itstep.pd011.mv.hw2.models.Ship;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    public static final int ID_PET_ACTIVITY = 1010, ID_SHIP_ACTIVITY = 1020;
    public static final int RESULT_OK = 0, RESULT_ERR = 1;

    ActivityMainBinding binding;

    private Pet pet;
    private Ship ship;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        pet = new Pet();
        ship = new Ship();

        binding.setPet(pet);
        binding.setShip(ship);

        binding.btnPetActivity.setOnClickListener(v -> startPetActivity());
        binding.btnShipActivity.setOnClickListener(v -> startShipActivity());
        binding.btnExit.setOnClickListener(v -> finish());

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mniAnimalProcess:
                startPetActivity();
                break;
            case R.id.mniShipProcess:
                startShipActivity();
                break;
            case R.id.mniExit:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putParcelable(Pet.class.getCanonicalName(), pet);
        outState.putParcelable(Ship.class.getCanonicalName(), ship);

        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        pet = savedInstanceState.getParcelable(Pet.class.getCanonicalName());
        ship = savedInstanceState.getParcelable(Ship.class.getCanonicalName());
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void startPetActivity() {
        Intent intent = new Intent(this, PetActivity.class);
        intent.putExtra(Pet.class.getCanonicalName(), pet);
        startActivityForResult(intent, ID_PET_ACTIVITY);
    }

    private void startShipActivity() {
        Intent intent = new Intent(this, ShipActivity.class);
        intent.putExtra(Ship.class.getCanonicalName(), ship);
        startActivityForResult(intent, ID_SHIP_ACTIVITY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK) {
            Toast.makeText(this,
                            String.format(Locale.UK, "Ошибка %d в активности с кодом %d", resultCode, requestCode),
                            Toast.LENGTH_LONG)
                    .show();
            return;
        }

        if(data == null)
            return;

        switch (requestCode) {
            case ID_PET_ACTIVITY:
                pet = data.getParcelableExtra(Pet.class.getCanonicalName());
                binding.setPet(pet);
                break;
            case ID_SHIP_ACTIVITY:
                ship = data.getParcelableExtra(Ship.class.getCanonicalName());
                binding.setShip(ship);
                break;
        }
    }
}