package ru.cherkas.home.home4.adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import ru.cherkas.home.home4.R;
import ru.cherkas.home.home4.models.Animal;

public class AnimalAdapter extends ArrayAdapter<Animal> {

    private LayoutInflater lif;
    private int resource;
    private List<Animal> animals;
    private Context context;

    public AnimalAdapter(Context context, int resource, ArrayList<Animal> animals) {
        super(context, resource, animals);
        this.lif = LayoutInflater.from(context);
        this.resource = resource;
        this.animals = animals;
        this.context = context;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null){
            convertView = lif.inflate(this.resource, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }
        else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        final Animal animal = animals.get(position);

        String filename = animal.getPhoto();
        try(InputStream inputStream = context.getApplicationContext().getAssets().open(filename)) {
            Drawable drawable = Drawable.createFromStream(inputStream, null);
            viewHolder.image_animal.setImageDrawable(drawable);

        } catch (IOException e) {
            filename = "нет.jpg";
            try(InputStream inputStream = context.getApplicationContext().getAssets().open(filename)) {
                Drawable drawable = Drawable.createFromStream(inputStream, null);
                viewHolder.image_animal.setImageDrawable(drawable);

            } catch (IOException e2) {
                throw new RuntimeException(e2);
            }
        }
        viewHolder.tv_breed.setText(animal.getBreed());
        viewHolder.tv_nick.setText(animal.getNickname());
        viewHolder.tv_owner.setText(animal.getOwner());
        return convertView;
    }

    private static class ViewHolder {
        final TextView tv_breed, tv_nick, tv_owner, tv_age = null, tv_weight = null ;
        final ImageView image_animal;

        public ViewHolder(View view) {
            this.image_animal = view.findViewById(R.id.image_animal);
            this.tv_breed = view.findViewById(R.id.tv_breed);
            this.tv_nick = view.findViewById(R.id.tv_nick);
            this.tv_owner = view.findViewById(R.id.tv_owner);
        }
    }
}