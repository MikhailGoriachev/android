package org.itstep.pd011.step270323.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.helpers.Utils;
import org.itstep.pd011.step270323.interfaces.OnFragmentSendDataListener;

public class QueriesFragment extends Fragment {


    // ссылка на активность, в которой находится фрагмент
    private OnFragmentSendDataListener activivtyRetranslator;

    // обязательный конструктор
    public QueriesFragment() {}

    // при подключении к активности, context -  ссылка на активнсоть
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {
            activivtyRetranslator = (OnFragmentSendDataListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " должен реализовывать интерфейс OnFragmentInteractionListener");
        } // try-catch
    }

    // создание разметки фрагмента
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_queries, container, false);
        ListView listView = view.findViewById(R.id.queriesList);

        // создаем адаптер
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                getContext(),
                android.R.layout.simple_list_item_1,
                Utils.titles);

        // устанавливаем для списка адаптер
        listView.setAdapter(adapter);

        // добавляем для списка слушатель
        listView.setOnItemClickListener((parent, v, position, id) -> activivtyRetranslator.onSendPosition(position));

        return view;
    }
}