package org.itstep.pd011.step1303232.models;

public class Good {

    private String title;
    private int amount;
    private int price;

    public int sum(){
        return amount*price;
    }

    public Good(String title, int amount, int price) {
        this.title = title;
        this.amount = amount;
        this.price = price;
    }

}
