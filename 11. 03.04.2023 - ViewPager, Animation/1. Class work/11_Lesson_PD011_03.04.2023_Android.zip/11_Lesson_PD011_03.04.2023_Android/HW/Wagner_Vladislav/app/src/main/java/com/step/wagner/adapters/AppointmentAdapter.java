package com.step.wagner.adapters;

import static com.step.wagner.infrastructure.Utils.appointmentsRepository;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.step.wagner.R;
import com.step.wagner.async_tasks.CommonTask;
import com.step.wagner.fragments.dialogs.AppointmentEditDialog;
import com.step.wagner.infrastructure.StringWithId;
import com.step.wagner.infrastructure.Utils;
import com.step.wagner.intefaces.AppointmentListener;
import com.step.wagner.models.entities.Appointment;
import com.step.wagner.models.entities.Doctor;
import com.step.wagner.models.entities.Patient;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class AppointmentAdapter extends BaseAdapter<Appointment> {

    //Активность, выводящая список
    private View listParent;

    //Режим вывода списка
    private boolean changeable;

    //Менеджер для вывода диалога
    private FragmentManager fragmentManager;

    public AppointmentAdapter(@NonNull Context context, @NonNull List<Appointment> collection, boolean isChangeable, FragmentManager fragmentManager) {
        super(context, collection);

        this.listParent = ((Activity) context).findViewById(android.R.id.content);
        this.changeable = isChangeable;
        this.fragmentManager = fragmentManager;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup listView, int viewType) {
        View itemView = inflater.inflate(R.layout.appointment_item, listView, false);

        return new ViewHolder(itemView);
    }

    //Задать значения в поля и привязать обработчики
    @SuppressLint("DefaultLocale")
    @Override
    public void onBindViewHolder(@NonNull BaseAdapter.ViewHolder baseHolder, int position) {
        Appointment appointmentItem = collection.get(position);

        //Привести базовый тип ViewHolder, к наследнику
        ViewHolder holder = (ViewHolder) baseHolder;

        //Если выводится таблица,а не результат запроса
        if (changeable) {
            holder.appointmentIdTxv.setText(String.format("Id приема: %d", appointmentItem.getId()));

            holder.editBtn.setOnClickListener(v -> update(position));
            holder.deleteBtn.setOnClickListener(v -> delete(position));

        } else {
            holder.appointmentIdTxv.setVisibility(View.GONE);

            holder.editBtn.setVisibility(View.GONE);
            holder.deleteBtn.setVisibility(View.GONE);
        }

        holder.appointmentDate.setText(String.format("Дата приема: %s", Utils.dateFormat.format(appointmentItem.getAppointmentDate())));
        holder.patientSnpTxv.setText(
                String.format("ФИО пациента: %s.%s.%s",
                        appointmentItem.getPatient().getSurname(),
                        appointmentItem.getPatient().getName().charAt(0),
                        appointmentItem.getPatient().getPatronymic().charAt(0))
        );

        holder.doctorSnpTxv.setText(
                String.format("ФИО доктора: %s.%s.%s",
                        appointmentItem.getDoctor().getSurname(),
                        appointmentItem.getDoctor().getName().charAt(0),
                        appointmentItem.getDoctor().getPatronymic().charAt(0))
        );

        holder.patientDobTxv.setText(String.format("Дата рождения пациента: %s", Utils.dateFormat.format(appointmentItem.getPatient().getBirthDate())));
        holder.patientAddressTxv.setText(String.format("Адрес пациента: %s", appointmentItem.getPatient().getAddress()));
        holder.patientPassportTxv.setText(String.format("Паспорт пациента: %s", appointmentItem.getPatient().getPassport()));

        holder.specialityTxv.setText(String.format("Специальность: %s", appointmentItem.getDoctor().getSpeciality()));
        holder.percentTxv.setText(String.format("%s отчислениий: %.2f", "%", appointmentItem.getDoctor().getPercent()));

    }

    //ViewHolder наследуется от ViewHolder базового класса для возможности применения полиморфизма
    public static class ViewHolder extends BaseAdapter.ViewHolder {

        //Дата приёма
        public final TextView appointmentDate;

        //Id приёма
        public final TextView appointmentIdTxv;

        //ФИО пациента
        public final TextView patientSnpTxv;

        //Дата рождения
        public final TextView patientDobTxv;

        //Адрес проживания
        public final TextView patientAddressTxv;

        //Паспорт
        public final TextView patientPassportTxv;

        //ФИО доктора
        public final TextView doctorSnpTxv;

        //Специальность
        public final TextView specialityTxv;

        //Процент отчислений
        public final TextView percentTxv;


        //Кнопки
        public final Button editBtn;
        //Кнопки
        public final Button deleteBtn;

        //endregion

        //Получить ссылки на текущие элементы
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            //Поля вывода
            this.appointmentIdTxv = itemView.findViewById(R.id.appointmentId);
            this.appointmentDate = itemView.findViewById(R.id.appointmentDate);
            this.patientSnpTxv = itemView.findViewById(R.id.patientSnp);
            this.patientDobTxv = itemView.findViewById(R.id.birthDate);
            this.patientAddressTxv = itemView.findViewById(R.id.address);
            this.patientPassportTxv = itemView.findViewById(R.id.passport);

            this.doctorSnpTxv = itemView.findViewById(R.id.doctorSnp);
            this.specialityTxv = itemView.findViewById(R.id.speciality);
            this.percentTxv = itemView.findViewById(R.id.percent);

            this.editBtn = itemView.findViewById(R.id.btnEdit);
            this.deleteBtn = itemView.findViewById(R.id.btnDelete);


        }
    }

    //Изменение записи
    @SuppressLint("DefaultLocale")
    private void update(int index) {
        Appointment appointment = collection.get(index);

        AppointmentEditDialog appointmentEditDialog = new AppointmentEditDialog();

        Bundle bundle = new Bundle();

        bundle.putParcelable("appointment", appointment);

        appointmentEditDialog.setArguments(bundle);

        //Обработчик клика в диалоге
        appointmentEditDialog.setListener(new AppointmentListener() {
            @Override
            public void onOkClickListener(int id, Date appointmentDate, int doctorId, int patientId) {

                CommonTask task = new CommonTask();
                //Изменить запись приёма в одельной задаче
                task.execute(
                        ()->{

                            //Если полученные значения - некорректны
                            if (appointmentDate == null || doctorId == 0 || patientId == 0)
                                return () -> {
                                    //Вывод сообщения
                                    Utils.showSnackBar(listParent, String.format("Не удалось изменить запись с id: %d", appointment.getId()));

                                    return null;
                                };


                            //Получить объекты докторов и пациентов по id
                            Utils.doctorsRepository.open();
                            Utils.patientsRepository.open();

                            Doctor doctor = Utils.doctorsRepository.getById(doctorId);
                            Patient patient = Utils.patientsRepository.getById(patientId);

                            Utils.doctorsRepository.close();
                            Utils.patientsRepository.close();


                            Appointment editedAppointment = new Appointment(id,appointmentDate,patient,doctor);

                            //Действия после обращения к БД
                            return () -> {

                                //Открыть соединение с БД
                                appointmentsRepository.open();

                                appointmentsRepository.update(editedAppointment);

                                //Переписать коллекцию
                                collection.clear();
                                collection.addAll(appointmentsRepository.getAll());

                                appointmentsRepository.close();

                                notifyDataSetChanged();

                                //Вывод сообщения
                                Utils.showSnackBar(listParent, String.format("Запись с id: %d успешно изменена", appointment.getId()));

                                return null;
                            };
                        }
                );//execute

            }//onOkClickListener
        });

        appointmentEditDialog.show(fragmentManager, "appointment_edit_dialog");



    }//update

    @SuppressLint("DefaultLocale")
    private void delete(int index) {
        Appointment appointment = collection.get(index);

        //Открыть соед
        appointmentsRepository.open();

        appointmentsRepository.delete(appointment.getId());

        //Переписать коллекцию
        collection.clear();
        collection.addAll(appointmentsRepository.getAll());

        appointmentsRepository.close();

        notifyDataSetChanged();

        //Вывод сообщения
        Utils.showSnackBar(listParent, String.format("Запись с id: %d успешно удалена", appointment.getId()));

    }

}
