package org.goriachev.homework.repositories;


import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.database.Cursor;

import androidx.annotation.NonNull;

import org.goriachev.homework.entities.Edition;
import org.goriachev.homework.middleware.PeriodicalsContract;
import org.goriachev.homework.utils.Utils;

import java.util.ArrayList;
import java.util.List;

// Репозиторий изданий
public class EditionsRepository {

    private static final String[] columns = {
            PeriodicalsContract.Columns._ID,
            PeriodicalsContract.Columns.INDEX,
            PeriodicalsContract.Columns.PUBLICATION_TYPE,
            PeriodicalsContract.Columns.NAME,
            PeriodicalsContract.Columns.PRICE,
            PeriodicalsContract.Columns.SUBSCRIBE_DATE,
            PeriodicalsContract.Columns.DURATION
    };

    // все записи
    public static List<Edition> getAll(ContentResolver contentResolver) {
        Cursor cursor = contentResolver.query(
                PeriodicalsContract.CONTENT_URI,
                columns,
                null,
                null,
                null
        );

        var items = getListFromCursor(cursor);

        cursor.close();

        return items;
    }

    // получить запись из курсора
    @SuppressLint("Range")
    public static Edition getItemFromCursor(@NonNull Cursor cursor) {
        return new Edition(
                cursor.getLong(cursor.getColumnIndex(PeriodicalsContract.Columns._ID)),
                cursor.getString(cursor.getColumnIndex(PeriodicalsContract.Columns.INDEX)),
                cursor.getString(cursor.getColumnIndex(PeriodicalsContract.Columns.PUBLICATION_TYPE)),
                cursor.getString(cursor.getColumnIndex(PeriodicalsContract.Columns.NAME)),
                cursor.getInt(cursor.getColumnIndex(PeriodicalsContract.Columns.PRICE)),
                Utils.getDate(cursor.getString(cursor.getColumnIndex(PeriodicalsContract.Columns.SUBSCRIBE_DATE))),
                cursor.getInt(cursor.getColumnIndex(PeriodicalsContract.Columns.DURATION))
        );
    }

    // получить список записей из курсора
    public static List<Edition> getListFromCursor(@NonNull Cursor cursor) {
        List<Edition> list = new ArrayList<>();
        while (cursor.moveToNext()) {
            list.add(getItemFromCursor(cursor));
        }

        return list;
    }

}
