package org.itstep.pd011.step160323.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import org.itstep.pd011.step160323.Helpers.Utils;
import org.itstep.pd011.step160323.MainActivity;
import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.models.Animal;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public class AnimalActivity extends AppCompatActivity {

    private EditText editBreed, edtName, edtAge, edtWeight, edtSurname, edtOwner;
    private ImageView imageAnimal;

    private Animal animal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);

        // получить параметр из вызывающей активности
        Intent intent = getIntent();
        animal = intent.getParcelableExtra(Animal.class.getCanonicalName());

        editBreed = findViewById(R.id.edtBreed);
        edtName = findViewById(R.id.edtName);
        edtAge = findViewById(R.id.edtAge);
        edtWeight = findViewById(R.id.edtWeight);
        edtSurname = findViewById(R.id.edtSurname);
        edtOwner = findViewById(R.id.edtOwner);

        editBreed.setText(animal.getBreed());
        edtName.setText(animal.getName());
        edtAge.setText(String.format(Locale.UK, "%d", animal.getAge()));
        edtWeight.setText(String.format(Locale.UK, "%.2f", animal.getWeight()));
        edtSurname.setText(animal.getSurname());
        edtOwner.setText(animal.getOwner());

        // чтение файла изображения из assets и вывод его в ImageView
        // получить файл с изображением и поместить его в ImageView
        imageAnimal = findViewById(R.id.imageAnimal);
        try (InputStream inputStream = getApplicationContext().getAssets().open(animal.getImage())) {
            Drawable drawable = Drawable.createFromStream(inputStream, null);

            imageAnimal.setImageDrawable(drawable);
            imageAnimal.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        } catch (IOException e) {
            Snackbar snackbar = Snackbar.make(imageAnimal, "Ошибка чтения файла изображения", Snackbar.LENGTH_INDEFINITE);
            snackbar.setAction("OK", v -> {
            });
            snackbar.show();
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> backClick());
        findViewById(R.id.btnClear).setOnClickListener(v -> clearEdt());

        editBreed.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        animal.setBreed(editBreed.getText().toString());
                    } catch (Exception e) {
                        Utils.showError(editBreed, e.getMessage());
                    }
                }
            }
        });

        edtName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        animal.setName(edtName.getText().toString());
                    } catch (Exception e) {
                        Utils.showError(edtName, e.getMessage());
                    }
                }
            }
        });

        edtAge.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        animal.setAge(Integer.parseInt(edtAge.getText().toString()));
                    } catch (Exception e) {
                        Utils.showError(edtAge, e.getMessage());
                    }
                }
            }
        });

        edtWeight.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        animal.setWeight(Double.parseDouble(edtWeight.getText().toString()));
                    } catch (Exception e) {
                        Utils.showError(edtWeight, e.getMessage());
                    }
                }
            }
        });

        edtSurname.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        animal.setSurname(edtSurname.getText().toString());
                    } catch (Exception e) {
                        Utils.showError(edtSurname, e.getMessage());
                    }
                }
            }
        });

        edtOwner.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        animal.setOwner(edtOwner.getText().toString());
                    } catch (Exception e) {
                        Utils.showError(edtOwner, e.getMessage());
                    }
                }
            }
        });

        findViewById(R.id.btnIncAge).setOnClickListener(v -> {
            lostFocus();
            try {
                animal.setAge(animal.getAge() + 1);
                edtAge.setText(String.format(Locale.UK, "%d", animal.getAge()));
            } catch (Exception e) {
                Utils.showError(edtAge, e.getMessage());
            }
        });

        findViewById(R.id.btnDecAge).setOnClickListener(v -> {
            lostFocus();
            try {
                animal.setAge(animal.getAge() - 1);
                edtAge.setText(String.format(Locale.UK, "%d", animal.getAge()));
            } catch (Exception e) {
                Utils.showError(edtAge, e.getMessage());
            }
        });

        findViewById(R.id.btnIncWeight).setOnClickListener(view -> {
            lostFocus();
            try {
                animal.setWeight(animal.getWeight() + 1);
                edtWeight.setText(String.format(Locale.UK, "%.2f", animal.getWeight()));
            } catch (Exception e) {
                Utils.showError(edtAge, e.getMessage());
            }
        });

        findViewById(R.id.btnDecWeight).setOnClickListener(view -> {
            lostFocus();
            try {
                animal.setWeight(animal.getWeight() - 1);
                edtWeight.setText(String.format(Locale.UK, "%.2f", animal.getWeight()));
            } catch (Exception e) {
                Utils.showError(edtAge, e.getMessage());
            }
        });
    }

    //кнопка для очистки полей ввода
    private void clearEdt() {
        lostFocus();
        editBreed.setText("");
        edtName.setText("");
        edtAge.setText("");
        edtWeight.setText("");
        edtSurname.setText("");
        edtOwner.setText("");
    }

    // обработка клика по кнопке выхода из активности
    private void backClick() {

        lostFocus();
        Intent intent = new Intent();

        // данные, возвращаемые из активности
        intent.putExtra(Animal.class.getCanonicalName(), animal);

        // установить результат работы активности
        setResult(MainActivity.RESULT_OK, intent);

        // завершить активность
        finish();
    } // back

    //снимаем фокус со всех полей для сохранения данных
    private void lostFocus(){
        editBreed.setFocusable(false);
        edtName.setFocusable(false);
        edtAge.setFocusable(false);
        edtWeight.setFocusable(false);
        edtSurname.setFocusable(false);
        edtOwner.setFocusable(false);
    }
}