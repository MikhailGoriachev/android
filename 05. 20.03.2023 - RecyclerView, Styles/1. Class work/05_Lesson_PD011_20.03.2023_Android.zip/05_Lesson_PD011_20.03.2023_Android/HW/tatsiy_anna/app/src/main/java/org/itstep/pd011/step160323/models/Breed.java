package org.itstep.pd011.step160323.models;

import org.itstep.pd011.step160323.R;

public enum Breed {


    BADGER(R.drawable.breed01,"Такса"),
    HUSKY(R.drawable.breed02,"Хаски"),
    MAINECOON(R.drawable.breed03,"Mейн кун");

    private final int image;
    private final String title;

    Breed(int image, String title) {
        this.image = image;
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }
}
