package org.itstep.pd011.step270323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.fragments.ResponseFragment;

public class ResponseActivity extends AppCompatActivity {

    public static final String POSITION = "POSITION";
    Integer position = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // при горизонтальной ориентации - выход, для корректного отображения
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            finish();
            return;
        } // if

        setContentView(R.layout.activity_response);

        // получение даннных для фрагмента
        Bundle extras = getIntent().getExtras();
        if (extras != null)
            position = extras.getInt(POSITION);
    }

    // перед началом работы активности, в момент когда фрагмент гарантированно готов к работе,
    // передать данные фрагменту
    @Override
    protected void onResume(){
        super.onResume();
        ResponseFragment fragment = (ResponseFragment) getSupportFragmentManager().findFragmentById(R.id.responseFragment);

        if (fragment != null)
            fragment.setResponse(position);
    }

    //region Меню активности
    @Override // создание меню
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    @Override // обработчик выбора меню
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.mniBack) {
            // возврат из активности
            finish();
        } // if

        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected

}