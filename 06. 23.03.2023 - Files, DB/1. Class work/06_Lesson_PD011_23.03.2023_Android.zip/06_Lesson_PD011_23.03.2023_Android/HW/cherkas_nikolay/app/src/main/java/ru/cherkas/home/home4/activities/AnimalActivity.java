package ru.cherkas.home.home4.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;

import ru.cherkas.home.home4.MainActivity;
import ru.cherkas.home.home4.R;
import ru.cherkas.home.home4.adapters.AnimalAdapter;
import ru.cherkas.home.home4.models.Animal;

public class AnimalActivity extends AppCompatActivity {

    ArrayList<Animal> animals;
    ArrayList<String> breeds;
    int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);

        breeds = new ArrayList<>();
        animals = new ArrayList<>();

        animals.add(new Animal("Шпиц", "Жорик", 1, 1, "Деревянко И.И.", "Шпиц.jpg"));
        animals.add(new Animal("Доберман", "Рекс", 3, 35, "Ефремов С.И.", "Доберман.jpg"));
        animals.add(new Animal("Колли", "Пушок", 5, 45, "Нефедов А.А.", "Колли.jpg"));
        animals.add(new Animal("Терьер", "Принц", 5, 9, "Мазурчак А.С.", "Терьер.jpg"));
        animals.add(new Animal("Мейнкун", "Барсик", 8, 10, "Гамершмидт Е.Ф.", "Мейнкун.jpg"));
        animals.add(new Animal("Бенгальская", "Пушок", 3, 7, "Метунова Н.Ф.", "Бенгальская.jpg"));
        animals.add(new Animal("Сиамская", "Мурзик", 7, 7, "Курзин С.П.", "Сиамская.jpg"));
        animals.add(new Animal("Сибирская", "Снежок", 5, 8, "Лошманов А.А.", "Сибирская.jpg"));
        animals.add(new Animal("Бенгальская", "Лари", 1, 2, "", "Бенгальская.jpg"));
        animals.add(new Animal("Невская", "Киса", 3, 5, "Путин В.В.", "Невская.jpg"));

        // получение из редактирования
        Bundle arg = getIntent().getExtras();
        if (arg != null) {
            Animal animal = arg.getParcelable(Animal.class.getSimpleName());
            animals.set(pos, animal);
        }

        // для спиннера
        for (Animal a : animals){
            breeds.add(a.getBreed());
        }

        ListView animalList = findViewById(R.id.animalList);
        ArrayAdapter<Animal> adapter = new AnimalAdapter(this, R.layout.item_animal, animals);
        animalList.setAdapter(adapter);
        animalList.setOnItemClickListener(this::onItemClickListener);
    }
    // меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_menu, menu);
        return true;
    }
    public void menuMainClick(MenuItem item) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    // переход на страницу редактирования животных
    public void onItemClickListener(AdapterView<?> adapterView, View view, int i, long l) {
        pos = i;
        Animal animal = (Animal) adapterView.getItemAtPosition(i);
        Intent intent = new Intent(this, AnimalEditActivity.class);
        intent.putExtra(Animal.class.getSimpleName(), animal);
        intent.putExtra("breeds", breeds);
        startActivity(intent);
    }

}