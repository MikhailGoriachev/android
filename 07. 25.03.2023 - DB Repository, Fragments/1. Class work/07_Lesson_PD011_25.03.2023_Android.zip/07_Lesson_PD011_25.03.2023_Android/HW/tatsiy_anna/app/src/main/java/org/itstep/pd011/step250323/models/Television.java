package org.itstep.pd011.step250323.models;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import org.itstep.pd011.step250323.helpers.Utils;

public class Television implements Parcelable {

    private String model; //модель
    private String image;
    private double diagonal;
    private int vertical;
    private int horizontal;
    private int price;

    protected Television(Parcel in) {
        model = in.readString();
        image = in.readString();
        diagonal = in.readDouble();
        vertical = in.readInt();
        horizontal = in.readInt();
        price = in.readInt();
    }

    public static final Creator<Television> CREATOR = new Creator<Television>() {
        @Override
        public Television createFromParcel(Parcel in) {
            return new Television(in);
        }

        @Override
        public Television[] newArray(int size) {
            return new Television[size];
        }
    };

    public void setModel(String model) {
        this.model = model;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setDiagonal(double diagonal) {
        this.diagonal = diagonal;
    }

    public void setVertical(int vertical) {
        this.vertical = vertical;
    }

    public void setHorizontal(int horizontal) {
        this.horizontal = horizontal;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getModel() {
        return model;
    }

    public String getImage() {
        return image;
    }

    public double getDiagonal() {
        return diagonal;
    }

    public int getVertical() {
        return vertical;
    }

    public int getHorizontal() {
        return horizontal;
    }

    public int getPrice() {
        return price;
    }

    public Television(String model, String image, double diagonal, int vertical, int horizontal, int price) {
        this.model = model;
        this.image = image;
        this.diagonal = diagonal;
        this.vertical = vertical;
        this.horizontal = horizontal;
        this.price = price;
    }

    @SuppressLint("DefaultLocale")
    public static Television generate(int index){
        return new Television(
                Utils.models[Utils.getInt(0,Utils.models.length)],
                String.format("image%d.jpg", index),
                Utils.getDouble(25,500),
                Utils.getInt(720,2160),
                Utils.getInt(1280,3840),
                Utils.getInt(5000,50000));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(model);
        parcel.writeString(image);
        parcel.writeDouble(diagonal);
        parcel.writeInt(vertical);
        parcel.writeInt(horizontal);
        parcel.writeInt(price);
    }
}
