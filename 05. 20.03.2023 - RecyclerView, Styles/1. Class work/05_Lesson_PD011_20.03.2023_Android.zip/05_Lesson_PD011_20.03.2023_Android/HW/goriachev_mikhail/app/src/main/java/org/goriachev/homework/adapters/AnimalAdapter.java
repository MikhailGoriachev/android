package org.goriachev.homework.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.goriachev.homework.models.Animal;
import org.goriachev.homework.utils.Utils;
import org.goriachev.homework.viewHolders.AnimalViewHolder;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;


public class AnimalAdapter extends ArrayAdapter<Animal> {

    // загрузчик разметки
    private LayoutInflater inflater;

    // id разметки списка
    private final int layoutId;

    // контекст
    final Context context;

    // данные
    private List<Animal> items;

    // обработчик события выбора по элемента
    private Consumer<Integer> onClickHandler;

    // конструктор инициализирующий
    public AnimalAdapter(@NonNull Context context, int resource, @NonNull List<Animal> objects, Consumer<Integer> onClickHandler) {
        super(context, resource, objects);

        this.onClickHandler = onClickHandler;
        this.context = context;
        this.layoutId = resource;
        this.inflater = LayoutInflater.from(context);
        this.items = objects;
    }

    // формирование разметки
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        final AnimalViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(this.layoutId, parent, false);
            holder = new AnimalViewHolder(convertView, position);

            convertView.setTag(holder);
        } else {
            holder = (AnimalViewHolder) convertView.getTag();
            holder.position = position;
        }

        setData(items.get(position), holder, position);

        return convertView;
    }

    // установка данных в поля
    private void setData(Animal animal, AnimalViewHolder holder, int position) {
            Utils.setViewImage(holder.ivwAnimal, "animals/" + animal.getImageFile(), context);
            holder.txvAnimalName.setText(animal.getName());
            holder.txvAnimalBreed.setText(animal.getBreed());
            holder.txvAnimalOwner.setText(animal.getOwner());

            holder.layAnimalItem.setOnClickListener((view) -> onClickHandler.accept(position));
    }
}
