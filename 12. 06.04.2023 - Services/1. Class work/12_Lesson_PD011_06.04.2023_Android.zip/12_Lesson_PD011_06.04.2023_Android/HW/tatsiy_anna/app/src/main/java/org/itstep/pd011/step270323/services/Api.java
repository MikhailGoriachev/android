package org.itstep.pd011.step270323.services;

import org.itstep.pd011.step270323.models.Album;
import org.itstep.pd011.step270323.models.Comment;
import org.itstep.pd011.step270323.models.Post;
import retrofit2.Call;
import java.util.List;
import retrofit2.http.GET;
import retrofit2.http.Url;

// Описание API для REST-операций веб-сервера
public interface Api {

    String BASE_URL = "https://jsonplaceholder.typicode.com/";

    // GET-запросы для получения коллекции записей от веб-сервера
    @GET("albums")
    Call<List<Album>> getAlbums();

    @GET
    Call<Album> getAlbumById(@Url String url);

    @GET("comments")
    Call<List<Comment>> getComments();

    @GET("posts")
    Call<List<Post>> getPosts();
}
