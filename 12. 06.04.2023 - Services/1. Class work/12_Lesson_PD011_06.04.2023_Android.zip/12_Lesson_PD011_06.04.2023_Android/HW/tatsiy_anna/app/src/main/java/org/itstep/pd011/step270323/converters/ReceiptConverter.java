package org.itstep.pd011.step270323.converters;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;

import org.itstep.pd011.step270323.helpers.Shell;
import org.itstep.pd011.step270323.helpers.Utils;
import org.itstep.pd011.step270323.entities.Receipt;

import java.lang.reflect.Type;
import java.text.ParseException;


public class ReceiptConverter extends Shell<Receipt> {

    public JsonElement serialize(Receipt src, Type type,
                                 JsonSerializationContext context){
        JsonObject object = new JsonObject();

        object.addProperty("id", src.getId());
        object.addProperty("date", Utils.formatter.format(src.getDate()));
        object.addProperty("price", src.getPrice());
        object.addProperty("id_patient", src.getId_patient());
        object.addProperty("id_doctor", src.getId_doctor());

        return object;
    }

    public Receipt deserialize(JsonElement json, Type type,
                               JsonDeserializationContext context) throws JsonParseException {

        JsonObject object = json.getAsJsonObject();

        try {
            return new Receipt(
                    object.get("id").getAsLong(),
                    Utils.formatter.parse(object.get("date").getAsString()),
                    object.get("price").getAsInt(),
                    object.get("id_patient").getAsInt(),
                    object.get("id_doctor").getAsInt()
            );
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }
}
