package org.pd011.sotula;

import static org.pd011.sotula.helpers.Utils.getRandDbl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.pd011.sotula.models.Product;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // товар
    Product product;

    // поля
    EditText edtTitle,
            edtAmount,
            edtUnitCost;

    // кнопки
    Button btnCalcSum;

    // поле результата
    TextView txvResult, txvInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // получить поля
        txvResult = findViewById(R.id.txvResult);
        txvInfo = findViewById(R.id.txvInfo);
        edtTitle = findViewById(R.id.edtTitle);
        edtAmount = findViewById(R.id.edtAmount);
        edtUnitCost = findViewById(R.id.edtUnitCost);

        // получить кнопки
        btnCalcSum = findViewById(R.id.btnCalcSum);

    } // onCreate

    // добавить информацию о продукте
    public void addInfoProduct(View view) {

        // значения из полей ввода
        String title = edtTitle.getText().toString();
        String amount = edtAmount.getText().toString();
        String unitCost = edtUnitCost.getText().toString();

        // есть незаполненные поля
        if (title.isEmpty() && amount.isEmpty() && unitCost.isEmpty()) {
            Toast.makeText(this, "Все поля должны быть заполнены", Toast.LENGTH_LONG).show();
            return;
        }

        product = new Product(title, Integer.parseInt(amount), Double.parseDouble(unitCost));

        // вывод внесенных данных
        txvInfo.setText(String.format(
                Locale.UK,
                "Товар \"%s\" в количестве %d шт. по цене %.2f.",
                product.getTitle(),
                product.getAmount(),
                product.getUnitCost()));

        // очистка полей ввода
        edtTitle.setText("");
        edtAmount.setText("");
        edtUnitCost.setText("");

        // очистка отобраения стоимости к оплате
        txvResult.setText("");

        // вкл кнопку расчета итоговой стоимости
        btnCalcSum.setEnabled(true);
    } // addInfoProduct

    // вычислить сумму к оплате
    public void calcSum(View view) {
        txvResult.setText(String.format(
                Locale.UK,
                "Стоимость оплаты: %.2f руб.",
                product.getTotalSum())
        );
    } // calcSum

    // выход
    public void exitClick(View view) {
        finish();
    } // exitClick
}