package com.step.wagner.infrastructure;

public class Parameters {

    //Последнее id сообщения
    public static int messageId = 0;

    //Файл для хранения значений диалога
    public static final String DIALOG_SETTINGS_FILE = "message_dialog";

    public static final String HTML_FILE_NAME = "about.html";
}
