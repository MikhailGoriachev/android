package org.itstep.pd011.step270323.tasks;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.itstep.pd011.step270323.entities.Doctor;
import org.itstep.pd011.step270323.repositories.DoctorsDatabaseRepository;

import java.util.List;

//Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше 2.3% (задавать параметром)
@SuppressLint("StaticFieldLeak")
public class Query02Task extends AsyncTask<Double,Void, List<Doctor>> {

    private final Context context;
    private final ListView listView;
    private final TextView textView;

    public Query02Task(Context context, ListView listView, TextView textView) {

        this.context = context;
        this.listView = listView;
        this.textView = textView;
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        textView.setText("Информация о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданого параметром");
    } // onPreExecute

    @Override
    protected List<Doctor> doInBackground(Double... params) {

        DoctorsDatabaseRepository repository = new DoctorsDatabaseRepository(context);

        repository.open();

        List<Doctor> list = repository.selectDoctorsByInterest(params[0]);

        repository.close();

        return list;
    }

    @Override
    protected void onPostExecute(List<Doctor> params){
        super.onPostExecute(params);

        if(params != null) {
            listView.setAdapter(
                    new ArrayAdapter<>(
                            context,
                            android.R.layout.simple_list_item_1,
                            params)
            );
        }
    }
}
