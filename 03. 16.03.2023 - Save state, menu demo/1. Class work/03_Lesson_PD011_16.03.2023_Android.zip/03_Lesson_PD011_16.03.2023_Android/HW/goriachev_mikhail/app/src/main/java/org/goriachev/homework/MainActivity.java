package org.goriachev.homework;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.goriachev.homework.activities.AnimalEditActivity;
import org.goriachev.homework.models.Animal;
import org.goriachev.homework.utils.Utils;

public class MainActivity extends AppCompatActivity {

    // животное
    private Animal animal;

    // судно


    // элемент для вывода изображения животного
    ImageView ivwAnimal;

    // поля для вывода информации о животном
    TextView txvAnimalName, txvAnimalBreed, txvAnimalAge, txvAnimalWeight, txvAnimalOwner;

    // обработчик события создания активности
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        animal = Animal.factory();

        // поиск элементов о животном
        txvAnimalName = findViewById(R.id.txv_animal_name);
        txvAnimalBreed = findViewById(R.id.txv_animal_breed);
        txvAnimalAge = findViewById(R.id.txv_animal_age);
        txvAnimalWeight = findViewById(R.id.txv_animal_weight);
        txvAnimalOwner = findViewById(R.id.txv_animal_owner);

        onUpdateAnimal();
    }

    // обработка события изменения животного
    private void onUpdateAnimal() {
        if (animal == null)
            return;

        txvAnimalName.setText(animal.getName());
        txvAnimalBreed.setText(animal.getBreed());
        txvAnimalAge.setText(Utils.intFormat(animal.getAge()));
        txvAnimalWeight.setText(Utils.doubleFormat(animal.getWeight()));
        txvAnimalOwner.setText(animal.getOwner());
    }

    // запуск активности редактирования животного
    public void showAnimalEditActivity(View view) {
        Intent intent = new Intent(this, AnimalEditActivity.class);

        intent.putExtra(Animal.class.getCanonicalName(), animal);

        startActivity(intent);
    }

    // завершение активности
    public void finish(View view) {
        finish();
    }
}