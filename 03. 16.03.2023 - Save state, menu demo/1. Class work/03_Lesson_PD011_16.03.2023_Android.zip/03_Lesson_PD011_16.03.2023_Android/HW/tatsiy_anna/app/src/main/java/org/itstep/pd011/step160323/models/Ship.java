package org.itstep.pd011.step160323.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.Arrays;

public class Ship implements Parcelable {

    private String type; //название типа судна
    private int capacity; //грузоподъемность
    private String image; //имя файла с изображением
    private String destination; //пункт назначения
    private String cargoType; //тип груза
    private int weight; //вес
    private int costOf1Ton; //стоимость 1 тонны груза

    protected Ship(Parcel in) {
        type = in.readString();
        capacity = in.readInt();
        image = in.readString();
        destination = in.readString();
        cargoType = in.readString();
        weight = in.readInt();
        costOf1Ton = in.readInt();
    }

    public static final Creator<Ship> CREATOR = new Creator<Ship>() {
        @Override
        public Ship createFromParcel(Parcel in) {
            return new Ship(in);
        }

        @Override
        public Ship[] newArray(int size) {
            return new Ship[size];
        }
    };

    public int totalCost(){
        return weight*costOf1Ton;
    }

    public Ship() {
        this("Сухогруз",
                120200,
                "cargo_ship.jpg",
                "Таганрог",
                "каменный уголь",
                110200,
                10000);
    }

    public Ship(String type, int capacity, String image, String destination, String cargoType, int weight, int costOf1Ton) {
        this.type = type;
        this.capacity = capacity;
        this.image = image;
        this.destination = destination;
        this.cargoType = cargoType;
        this.weight = weight;
        this.costOf1Ton = costOf1Ton;
    }

    public String getType() {
        return type;
    }

    public int getCapacity() {
        return capacity;
    }

    public String getImage() {
        return image;
    }

    public String getDestination() {
        return destination;
    }

    public String getCargoType() {
        return cargoType;
    }

    public int getWeight() {
        return weight;
    }

    public int getCostOf1Ton() {
        return costOf1Ton;
    }

    public void setType(String type) throws Exception {

        //проверка строки на пустоту
        if (type == null || type.isEmpty()){
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.type = type;
    }

    public void setCapacity(int capacity) throws Exception {
        if (capacity < weight){
            throw new Exception("грузоподъемность не может быть < веса груза!");
        }
        this.capacity = capacity;
    }

    public void setDestination(String destination) throws Exception {
        //проверка строки на пустоту
        if (destination == null || destination.isEmpty()){
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.destination = destination;
    }

    public void setCargoType(String cargoType) throws Exception {
        //проверка строки на пустоту
        if (cargoType == null || cargoType.isEmpty()){
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.cargoType = cargoType;
    }
    public void setWeight(int weight) throws Exception {

        if (weight < 20){
            throw new Exception("Вес груза не может быть < 20т!");
        }

        this.weight = weight;
    }

    public void setCostOf1Ton(int costOf1Ton) throws Exception {

        if (costOf1Ton < 100){
            throw new Exception("Cтоимость 1 тонны груза не может быть < 100 руб!");
        }
        this.costOf1Ton = costOf1Ton;
    }

    @NonNull
    @Override
    public String toString() {
        return "Корабль:\n" +
                type + '\n' +
                capacity + " т.\n" +
                destination + '\n' +
                cargoType + '\n' +
                weight + " т.\n" +
                costOf1Ton + " руб.";
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(type);
        parcel.writeInt(capacity);
        parcel.writeString(image);
        parcel.writeString(destination);
        parcel.writeString(cargoType);
        parcel.writeInt(weight);
        parcel.writeInt(costOf1Ton);
    }
}
