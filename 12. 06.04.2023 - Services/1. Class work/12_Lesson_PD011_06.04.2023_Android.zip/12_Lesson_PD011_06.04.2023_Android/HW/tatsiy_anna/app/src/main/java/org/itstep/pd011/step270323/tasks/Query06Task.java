package org.itstep.pd011.step270323.tasks;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import org.itstep.pd011.step270323.repositories.ReceptsDatabaseRepository;

@SuppressLint("StaticFieldLeak")
public class Query06Task extends AsyncTask<Void,Void, Cursor> {

    private final Context context;
    private final ListView listView;
    private final TextView textView;

    public Query06Task(Context context, ListView listView, TextView textView) {
        this.context = context;
        this.listView = listView;
        this.textView = textView;
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        textView.setText("Для каждой даты вычисляет максимальную стоимость приема");
    } // onPreExecute

    @Override
    protected Cursor doInBackground(Void... voids) {

        ReceptsDatabaseRepository repository = new ReceptsDatabaseRepository(context);
        repository.open();
        Cursor cursor = repository.maxPriceGroupByDate();
        repository.close();

        return cursor;
    }

    @Override
    protected void onPostExecute(Cursor params) {
        super.onPostExecute(params);

        if(params != null) {
            listView.setAdapter(
                    new SimpleCursorAdapter(
                            context,
                            android.R.layout.two_line_list_item,
                            params,
                            new String[]{"date", "max"},
                            new int[]{android.R.id.text1, android.R.id.text2},
                            0)
            );
        }
    }
}
