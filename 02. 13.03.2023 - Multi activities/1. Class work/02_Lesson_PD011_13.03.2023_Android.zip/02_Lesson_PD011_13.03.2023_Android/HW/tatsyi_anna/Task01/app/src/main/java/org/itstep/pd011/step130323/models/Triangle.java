package org.itstep.pd011.step130323.models;

import androidx.annotation.NonNull;

import org.itstep.pd011.step130323.utils.Utils;

import java.util.Locale;

public class Triangle {

    public double a;
    public double b;
    public double c;

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
    }

    public Triangle(double min, double max) {

        do{

            a = Utils.getDouble(min,max);
            b = Utils.getDouble(min,max);
            c = Utils.getDouble(min,max);

        }while (!isTriangle());
    }

    private boolean isTriangle(){
        return (a < b + c) && (b < a + c) && (c < a + b);
    }

    public double perimeter(){
        return a+b+c;
    }

    public double area(){
        double p = perimeter()*0.5;
        return Math.sqrt(p*Math.sqrt(p-a)*Math.sqrt(p-b)*Math.sqrt(p-c));
    }

    @NonNull
    @Override
    public String toString() {
        return String.format(Locale.UK,"a=%.2f b=%.2f c=%.2f", a , b, c);
    }
}
