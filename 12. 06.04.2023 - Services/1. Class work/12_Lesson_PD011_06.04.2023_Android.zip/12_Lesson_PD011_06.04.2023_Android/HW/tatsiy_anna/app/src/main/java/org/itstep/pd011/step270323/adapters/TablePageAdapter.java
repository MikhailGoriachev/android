package org.itstep.pd011.step270323.adapters;

import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import org.itstep.pd011.step270323.fragments.TablePageFragment;

public class TablePageAdapter extends FragmentStateAdapter {

    public TablePageAdapter(FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    // создание фрагмента для очередной страницы - при помощи фабричного метода
    // фрагменты могут и отличаться, лишь бы были в иерархии Fragment
    // !!! место для получения различных по разметке фрагментов !!!
    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return TablePageFragment.newInstance(position);
    }

    // количество страниц - обязательно т.к. FragmentStateAdapter - абстрактный...
    @Override
    public int getItemCount() {
        return 4;
    }
}
