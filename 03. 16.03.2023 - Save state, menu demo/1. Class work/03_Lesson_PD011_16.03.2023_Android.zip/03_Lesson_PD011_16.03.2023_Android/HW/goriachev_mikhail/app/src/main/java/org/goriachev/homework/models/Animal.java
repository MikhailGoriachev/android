package org.goriachev.homework.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import org.goriachev.homework.utils.Utils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Setter
//@Getter
//@NoArgsConstructor
public class Animal implements Parcelable {

    // порода
    private String breed;

    // кличка
    private String name;

    // возраст
    private int age;

    // вес
    private double weight;

    // фамилия и инициалы владельца
    private String owner;

    // имя файла с изображением
    private String imageFile;


    protected Animal(Parcel in) {
        breed = in.readString();
        name = in.readString();
        age = in.readInt();
        weight = in.readDouble();
        owner = in.readString();
        imageFile = in.readString();
    }

    public static final Creator<Animal> CREATOR = new Creator<Animal>() {
        @Override
        public Animal createFromParcel(Parcel in) {
            return new Animal(in);
        }

        @Override
        public Animal[] newArray(int size) {
            return new Animal[size];
        }
    };

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getImageFile() {
        return imageFile;
    }

    public void setImageFile(String imageFile) {
        this.imageFile = imageFile;
    }

    public Animal() {
    }

    // конструктор инициализирующий
    public Animal(String breed, String name, int age, double weight, String owner, String imageFile) {
        this.breed = breed;
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.owner = owner;
        this.imageFile = imageFile;
    }

    // фабричный метод
    public static Animal factory() {
        String[] breed = Utils.getItem(Utils.breeds);
        String[] personArr = Utils.getItem(Utils.people);
        String person = String.format("%s %s. %s", personArr[0], personArr[1].charAt(0), personArr[2].charAt(0));

        return new Animal(
                breed[0],
                Utils.getItem(Utils.animalNames),
                Utils.getInt(1, 5),
                Utils.getDouble(2d, 5d),
                person,
                breed[1]
        );
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(breed);
        parcel.writeString(name);
        parcel.writeInt(age);
        parcel.writeDouble(weight);
        parcel.writeString(owner);
        parcel.writeString(imageFile);
    }
}
