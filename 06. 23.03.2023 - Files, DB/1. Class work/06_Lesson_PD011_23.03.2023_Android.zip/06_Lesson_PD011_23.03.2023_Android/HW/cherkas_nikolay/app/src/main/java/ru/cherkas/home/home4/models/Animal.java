package ru.cherkas.home.home4.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Animal implements Parcelable {
    String breed;     // порода
    String nickname;  // кличка
    int age;          // возраст
    double weight;    // вес
    String owner;     // владелец
    String photo;     // файл фото

    protected Animal(Parcel in) {
        breed = in.readString();
        nickname = in.readString();
        age = in.readInt();
        weight = in.readDouble();
        owner = in.readString();
        photo = in.readString();
    }

    public static final Creator<Animal> CREATOR = new Creator<Animal>() {
        @Override
        public Animal createFromParcel(Parcel in) {
            return new Animal(in);
        }

        @Override
        public Animal[] newArray(int size) {
            return new Animal[size];
        }
    };

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Animal(String breed, String nickname, int age, double weight, String owner, String photo) {
        this.breed = breed;
        this.nickname = nickname;
        this.age = age;
        this.weight = weight;
        this.owner = owner;
        this.photo = photo;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "breed='" + breed + '\'' +
                ", nickname='" + nickname + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                ", owner='" + owner + '\'' +
                ", photo='" + photo + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(breed);
        parcel.writeString(nickname);
        parcel.writeInt(age);
        parcel.writeDouble(weight);
        parcel.writeString(owner);
        parcel.writeString(photo);
    }
}
