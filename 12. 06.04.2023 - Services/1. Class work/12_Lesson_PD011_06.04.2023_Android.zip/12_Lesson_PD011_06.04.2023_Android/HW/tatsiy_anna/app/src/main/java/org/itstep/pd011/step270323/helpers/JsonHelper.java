package org.itstep.pd011.step270323.helpers;

import android.content.Context;
import android.content.Entity;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class JsonHelper<T> {

    // экспортирование данных в JSON-файл
    public boolean exportToJSON(Context context, List<T> dataList, String fileName, Shell<T> v, Type type){

        boolean result = false;

        GsonBuilder builder = new GsonBuilder();
        builder.registerTypeAdapter(type, v);
        Gson gson = builder.create();

        String jsonString = gson.toJson(dataList);

        try (FileOutputStream fileOutputStream = context.openFileOutput(fileName, Context.MODE_PRIVATE)) {
            fileOutputStream.write(jsonString.getBytes());
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        } // try-catch

        return result;
    }

    // импортирование данных из JSON-файла
    public List<T> importFromJSON(Context context, String fileName, Shell<T> v, Type type, Type massType){

        try (InputStreamReader streamReader = new InputStreamReader(context.openFileInput(fileName))){

            GsonBuilder builder = new GsonBuilder();
            builder.registerTypeAdapter(type, v);

            Gson gson = builder.create();
            return new ArrayList<>(Arrays.asList(gson.fromJson(streamReader, massType)));
        } catch (Exception e){
            e.printStackTrace();
            return null;
        } // try-catch
    }
}

