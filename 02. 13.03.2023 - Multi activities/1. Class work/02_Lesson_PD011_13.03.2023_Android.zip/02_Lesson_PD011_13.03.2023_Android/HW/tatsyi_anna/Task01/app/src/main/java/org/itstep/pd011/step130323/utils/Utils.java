package org.itstep.pd011.step130323.utils;
import java.util.Random;

public class Utils {

    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }
}
