package org.itstep.pd011.task02.models;

import java.security.InvalidParameterException;

// класс, описывающий товар
public class Product {
    // наименование товара
    private String name;

    // цена единицы товара
    private int    price;

    //region конструкторы
    public Product() { this("мяч резиновый", 120); }
    public Product(String name, int price) {
        this.name = name;
        this.price = price;
    } // Goods
    //endregion

    //region геттеры и сеттеры
    public String getName() { return name; }
    public void setName(String name) {
        if (name.isEmpty())
            throw new InvalidParameterException("Недопустимое наименование товара");

        this.name = name;
    } // setName

    public int getPrice() { return price; }
    public void setPrice(int price) {
        if (price <= 0)
            throw new InvalidParameterException("Недопустимое значение цены товара");

        this.price = price;
    } // setPrice
    //endregion
} // Goods
