package org.itstep.pd011.step270323.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.models.Album;
import org.itstep.pd011.step270323.models.Comment;
import org.itstep.pd011.step270323.models.Post;
import org.itstep.pd011.step270323.services.Api;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class WebServicePageFragment extends Fragment {

    // номер страницы
    private int pageNumber;

    // элемент страницы
    ListView listView;

    private Api api;

    public WebServicePageFragment() {
        // Required empty public constructor
    }

    public static WebServicePageFragment newInstance(int page) {

        WebServicePageFragment fragment = new WebServicePageFragment();

        // номер страницы передать экземпляру фрагмента
        Bundle args = new Bundle();
        args.putInt("num", page);

        fragment.setArguments(args);

        // фрагмент сформирован
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        pageNumber = getArguments() != null ? getArguments().getInt("num") : 1;

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api = retrofit.create(Api.class);
    }

    //TODO: не получается вызвать эту функцию: api.getAlbums().enqueue(getCallback());
    /*
    public Callback<List<T>> getCallback(){
        return new Callback<List<T>>() {

            @Override
            public void onResponse(Call<List<T>> call, Response<List<T>> response) {

                listView.setAdapter(
                        new ArrayAdapter<>(
                                getApplicationContext(),
                                android.R.layout.simple_list_item_1,
                                response.body()
                        )
                );
            }

            @Override
            public void onFailure(Call<List<?>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getClass().toString() + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
    }*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View result = inflater.inflate(R.layout.fragment_web_service_page, container, false);

        listView = result.findViewById(R.id.listWebService);

        int t = pageNumber + 1;

        switch (t) {
            case 1:

                api.getAlbums().enqueue(new Callback<List<Album>>() {

                    @Override
                    public void onResponse(@NonNull Call<List<Album>> call, @NonNull Response<List<Album>> response) {

                        listView.setAdapter(
                                new ArrayAdapter<Album>(
                                        getContext().getApplicationContext(),
                                        android.R.layout.simple_list_item_1,
                                        response.body()
                                )
                        );
                    }

                    @Override
                    public void onFailure(@NonNull Call<List<Album>> call, @NonNull Throwable t) {
                        throw new RuntimeException(t);
                    }
                });

                break;

            case 2:

                api.getAlbumById(String.format(Locale.UK,"albums/%d",1)).enqueue(new Callback<Album>() {

                    @Override
                    public void onResponse(@NonNull Call<Album> call, @NonNull Response<Album> response) {

                        Album album = response.body();

                        assert album != null;
                        listView.setAdapter(
                                new ArrayAdapter<Album>(
                                        getContext().getApplicationContext(),
                                        android.R.layout.simple_list_item_1,
                                        new ArrayList<>(List.of(album))
                                )
                        );
                    }

                    @Override
                    public void onFailure(@NonNull Call<Album> call, @NonNull Throwable t) {
                        throw new RuntimeException(t);
                    }
                });

                break;

            case 3:

                api.getComments().enqueue(new Callback<List<Comment>>() {

                    @Override
                    public void onResponse(@NonNull Call<List<Comment>> call, @NonNull Response<List<Comment>> response) {

                        listView.setAdapter(
                                new ArrayAdapter<Comment>(
                                        getContext().getApplicationContext(),
                                        android.R.layout.simple_list_item_1,
                                        response.body()
                                )
                        );
                    }

                    @Override
                    public void onFailure(@NonNull Call<List<Comment>> call, @NonNull Throwable t) {
                        throw new RuntimeException(t);
                    }
                });

                break;

            case 4:

                api.getPosts().enqueue(new Callback<List<Post>>() {

                    @Override
                    public void onResponse(@NonNull Call<List<Post>> call, @NonNull Response<List<Post>> response) {

                        listView.setAdapter(
                                new ArrayAdapter<Post>(
                                        getContext().getApplicationContext(),
                                        android.R.layout.simple_list_item_1,
                                        response.body()
                                )
                        );
                    }

                    @Override
                    public void onFailure(@NonNull Call<List<Post>> call, @NonNull Throwable t) {
                        throw new RuntimeException(t);
                    }
                });

                break;
        }

        return result;
    }
}