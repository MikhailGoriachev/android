package org.itstep.pd011.step270323.models;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Receipt {
    private long id;       // ид
    private Date date;
    private int price;
    private int id_patient;
    private int id_doctor;

    public Receipt(long id, Date date, int price, int id_patient, int id_doctor) {
        this.id = id;
        this.date = date;
        this.price = price;
        this.id_patient = id_patient;
        this.id_doctor = id_doctor;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getId_patient() {
        return id_patient;
    }

    public void setId_patient(int id_patient) {
        this.id_patient = id_patient;
    }

    public int getId_doctor() {
        return id_doctor;
    }

    public void setId_doctor(int id_doctor) {
        this.id_doctor = id_doctor;
    }

    @SuppressLint("SimpleDateFormat")
    @NonNull
    @Override
    public String toString() {
        return
                "id: " + id + "\n" +
                "дата приема: " + new SimpleDateFormat("dd.MM.yyyy").format(date) + "\n" +
                "стоимость: " + price + "\n" +
                "id пациента: " + id_patient + "\n" +
                "id доктора: " + id_doctor;
    }
}
