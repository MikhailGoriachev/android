package org.itstep.pd011.step270323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.models.Doctor;
import org.itstep.pd011.step270323.models.Receipt;
import org.itstep.pd011.step270323.repositories.DoctorsDatabaseRepository;
import org.itstep.pd011.step270323.repositories.ReceptsDatabaseRepository;

import java.text.ParseException;

public class ReceptsActivity extends AppCompatActivity {

    // элемент отображения списка и его адаптер
    private ListView receiptsList;
    ArrayAdapter<Receipt> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recepts);

        receiptsList = findViewById(R.id.listRecepts);
    }

    // открытие БД
    @Override
    public void onResume() {
        super.onResume();

        // открыть базу данных
        ReceptsDatabaseRepository repository = new ReceptsDatabaseRepository(this);
        repository.open();

        // вывести в ListView при помощи адаптера
        try {
            arrayAdapter = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_list_item_1,
                    repository.getReceipts());
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        receiptsList.setAdapter(arrayAdapter);
        repository.close();

    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected
}