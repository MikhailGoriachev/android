package org.itstep.pd011.mv.hw2.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Max;
import com.mobsandgeeks.saripaar.annotation.Min;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.itstep.pd011.mv.hw2.MainActivity;
import org.itstep.pd011.mv.hw2.R;
import org.itstep.pd011.mv.hw2.models.Ship;
import org.itstep.pd011.mv.hw2.utils.RepeatListener;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@SuppressLint("ClickableViewAccessibility")
public class ShipActivity extends AppCompatActivity implements Validator.ValidationListener {

    @NotEmpty(message = "Поле обязательно для заполнения")
    EditText edtShipType;

    @NotEmpty(message = "Поле обязательно для заполнения")
    @Min(value = 0, message = "Не может быть меньше нуля")
    EditText edtShipCapacity;

    @NotEmpty(message = "Поле обязательно для заполнения")
    EditText edtDestination;

    @NotEmpty(message = "Поле обязательно для заполнения")
    EditText edtCargoType;

    @NotEmpty(message = "Поле обязательно для заполнения")
    @Min(value = 0, message = "Не может быть меньше нуля")
    EditText edtCargoWeight;

    @NotEmpty(message = "Поле обязательно для заполнения")
    @Min(value = 0, message = "Не может быть меньше нуля")
    EditText edtCostPerTon;

    Button btnCancel, btnOk, btnCalc, btnClear, btnDecWeight, btnIncWeight;

    ImageView imvShipImage;

    Ship ship;

    Validator validator;

    TextView txvTotalCost;


    private final int incrementStep = 20;
    private final int pressButtonFirstInterval = 500;
    private final int pressButtonCyclicInterval = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship);

        validator = new Validator(this);
        validator.setValidationListener(this);

        edtShipType = findViewById(R.id.edtShipType);
        edtShipCapacity = findViewById(R.id.edtShipCapacity);
        edtDestination = findViewById(R.id.edtDestination);
        edtCargoType = findViewById(R.id.edtCargoType);
        edtCargoWeight = findViewById(R.id.edtCargoWeight);
        edtCostPerTon = findViewById(R.id.edtCostPerTon);

        btnCancel = findViewById(R.id.btnCancel);
        btnOk = findViewById(R.id.btnOk);
        btnCalc = findViewById(R.id.btnCalc);
        btnClear = findViewById(R.id.btnClear);
        btnDecWeight = findViewById(R.id.btnDecWeight);
        btnIncWeight = findViewById(R.id.btnIncWeight);

        imvShipImage = findViewById(R.id.imvShipImage);
        txvTotalCost = findViewById(R.id.txvTotalCost);

        Intent intent = getIntent();
        ship = intent.getParcelableExtra(Ship.class.getCanonicalName());

        edtShipType.setText(ship.getType());
        edtShipCapacity.setText(String.valueOf(ship.getCapacity()));
        edtDestination.setText(ship.getDestination());
        edtCargoType.setText(ship.getCargoType());
        edtCargoWeight.setText(String.valueOf(ship.getCargoWeight()));
        edtCostPerTon.setText(String.valueOf(ship.getCostPerTon()));

        try (InputStream inputStream = getApplicationContext().getAssets().open(ship.getImageFile())) {
            Drawable drawable = Drawable.createFromStream(inputStream, null);
            imvShipImage.setImageDrawable(drawable);
            imvShipImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        } catch (IOException e) {
            Snackbar.make(imvShipImage, R.string.imageReadErrorMessage, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.btnOkTitle, v -> {})
                    .show();
        }

        edtCargoType.addTextChangedListener(getStringInputTextWatcher(edtCargoType, R.string.fieldRequiredMsg));
        edtDestination.addTextChangedListener(getStringInputTextWatcher(edtDestination, R.string.fieldRequiredMsg));
        edtShipType.addTextChangedListener(getStringInputTextWatcher(edtShipType, R.string.fieldRequiredMsg));
        edtCargoWeight.addTextChangedListener(cargoWeightTextWatcher);
        edtShipCapacity.addTextChangedListener(shipCapacityTextWatcher);
        edtCostPerTon.addTextChangedListener(costPerTonTextWatcher);

        btnIncWeight.setOnTouchListener(weightIncrementListener());
        btnDecWeight.setOnTouchListener(weightDecrementListener());
        btnCancel.setOnClickListener(this::onCancelClick);
        btnOk.setOnClickListener(this::onOkClick);
        btnClear.setOnClickListener(this::onClearClick);
        btnCalc.setOnClickListener(this::onCalculateClick);
    }

    private TextWatcher getStringInputTextWatcher(EditText edtTxt, int messageId) {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String content = edtTxt.getText().toString();

                if (content.isBlank()) {
                    edtTxt.setBackgroundResource(R.drawable.edit_error);
                    edtTxt.setError(getString(messageId));
                } else {
                    edtTxt.setBackgroundResource(R.drawable.edit_normal);
                }
            }
            @Override
            public void afterTextChanged(Editable s) {}
        };
    }

    private final TextWatcher cargoWeightTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String weightText = edtCargoWeight.getText().toString();
            Integer weight = weightText.isBlank() ? null : Integer.parseInt(weightText);

            String capacityText = edtShipCapacity.getText().toString();
            Integer capacity = capacityText.isBlank() ? null : Integer.parseInt(capacityText);

            if (weight == null || weight < 0 || (capacity != null && weight > capacity)) {
                edtCargoWeight.setBackgroundResource(R.drawable.edit_error);
                edtCargoWeight.setError(getString(R.string.invalidCargoWeightMsg));
            } else {
                edtCargoWeight.setBackgroundResource(R.drawable.edit_normal);
                edtCargoWeight.setError(null);
            }

            btnIncWeight.setEnabled(weight != null && (capacity != null && weight + incrementStep <= capacity));
            btnDecWeight.setEnabled(weight != null && weight - incrementStep >= 0);
            txvTotalCost.setText("");
        }
        @Override
        public void afterTextChanged(Editable s) {}
    };


    private final TextWatcher shipCapacityTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String capacityText = edtShipCapacity.getText().toString();
            Integer capacity = capacityText.isBlank() ? null : Integer.parseInt(capacityText);

            if (capacity == null || capacity < 0) {
                edtShipCapacity.setBackgroundResource(R.drawable.edit_error);
                edtShipCapacity.setError(getString(R.string.invalidCapacityMsg));
            } else {
                edtShipCapacity.setBackgroundResource(R.drawable.edit_normal);
            }

            edtCargoWeight.setText(edtCargoWeight.getText().toString());
        }
        @Override
        public void afterTextChanged(Editable s) {}
    };

    private final TextWatcher costPerTonTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String costPerToneText = edtCostPerTon.getText().toString();
            Integer costPerTone = costPerToneText.isBlank() ? null : Integer.parseInt(costPerToneText);

            if (costPerTone == null || costPerTone < 0) {
                edtCostPerTon.setBackgroundResource(R.drawable.edit_error);
                edtCostPerTon.setError(getString(R.string.invalidCostPerTonMsg));
            } else {
                edtCostPerTon.setBackgroundResource(R.drawable.edit_normal);
            }

            txvTotalCost.setText("");
        }
        @Override
        public void afterTextChanged(Editable s) {}
    };


    private View.OnTouchListener weightIncrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            String weightText = edtCargoWeight.getText().toString();
            int weight = weightText.isBlank() ? 0 : Integer.parseInt(weightText);
            edtCargoWeight.setText(String.valueOf(weight + incrementStep));
        });
    }

    private View.OnTouchListener weightDecrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            String weightText = edtCargoWeight.getText().toString();
            int weight = weightText.isBlank() ? 0 : Integer.parseInt(weightText);

            if (weight < 0) {
                Snackbar.make(view, R.string.tooLowAgeMessage, Snackbar.LENGTH_INDEFINITE)
                        .setAction(R.string.btnOkTitle, v -> {})
                        .show();
                return;
            }

            if ((weight - incrementStep * 2) <= 0) {
                btnDecWeight.setEnabled(false);
            }

            edtCargoWeight.setText(String.valueOf(weight - incrementStep));
        });
    }

    public void onCalculateClick(View view) {
        String weightText = edtCargoWeight.getText().toString();
        Integer weight = weightText.isBlank() ? null : Integer.parseInt(weightText);

        String costPerToneText = edtCostPerTon.getText().toString();
        Integer costPerTone = costPerToneText.isBlank() ? null : Integer.parseInt(costPerToneText);

        if(weight == null || costPerTone == null) {
            Snackbar.make(view, R.string.inputWeightAndPriceMsg, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.btnOkTitle, v -> {})
                    .show();
            return;
        }

        long totalCost = (long) weight * costPerTone;

        txvTotalCost.setText(String.valueOf(totalCost));
    }

    public void onClearClick(View view) {
        edtShipType.setText("");
        edtShipCapacity.setText("");
        edtDestination.setText("");
        edtCargoType.setText("");
        edtCargoWeight.setText("0");
        edtCostPerTon.setText("0");
    }

    public void onOkClick(View view) {
        validator.validate();
    }

    public void onCancelClick(View view) {
        finish();
    }

    @Override
    public void onValidationSucceeded() {
        int capacity = Integer.parseInt(edtShipCapacity.getText().toString());
        String cargoType = edtCargoType.getText().toString().trim();
        int cargoWeight = Integer.parseInt(edtCargoWeight.getText().toString());
        String destination = edtDestination.getText().toString().trim();
        int costPerTon = Integer.parseInt(edtCostPerTon.getText().toString());
        String shipType = edtShipType.getText().toString().trim();

        if (cargoWeight > capacity) {
            Snackbar.make(btnOk, getString(R.string.weightMoreCapacityMsg), Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.btnOkTitle, v -> {})
                    .show();
            return;
        }

        ship = new Ship(shipType, capacity, destination, cargoType, cargoWeight, costPerTon, ship.getImageFile());

        Intent intent = new Intent();
        intent.putExtra(Ship.class.getCanonicalName(), ship);

        setResult(MainActivity.RESULT_OK, intent);
        finish();
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(this);

            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Snackbar.make(view, message, Snackbar.LENGTH_LONG).show();
            }
        }
    }
}