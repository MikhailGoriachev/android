
package org.goriachev.homework.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.goriachev.homework.R;
import org.goriachev.homework.adapters.AppointmentAdapter;
import org.goriachev.homework.repositories.AppointmentRepository;


public class AppointmentListFragment extends Fragment {

    private RecyclerView rcvAppointments;

    // репозиторий
    AppointmentRepository repository;


    public AppointmentListFragment() {
        // Required empty public constructor
    }


    public static AppointmentListFragment newInstance(String param1, String param2) {
        AppointmentListFragment fragment = new AppointmentListFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        var view = inflater.inflate(R.layout.fragment_appointment_list, container, false);

        repository = new AppointmentRepository(getContext());

        rcvAppointments = view.findViewById(R.id.rcv_appointments);

        rcvAppointments.setAdapter(new AppointmentAdapter(getContext(), repository.getAll()));

        return view;
    }
}