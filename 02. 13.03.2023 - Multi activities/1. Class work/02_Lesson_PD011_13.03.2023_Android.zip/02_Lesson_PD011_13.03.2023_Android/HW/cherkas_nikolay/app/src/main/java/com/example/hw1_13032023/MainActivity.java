package com.example.hw1_13032023;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.hw1_13032023.models.Triangle;
import android.view.View;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Triangle triangle;
    private TextView txv_side1_data;
    private TextView txv_side2_data;
    private TextView txv_side3_data;
    private  TextView txv_square_res;
    private TextView txv_perimeter_res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txv_side1_data = findViewById(R.id.txv_side1_data);
        txv_side2_data = findViewById(R.id.txv_side2_data);
        txv_side3_data = findViewById(R.id.txv_side3_data);

        txv_perimeter_res = findViewById(R.id.txv_perimeter_res);
        txv_square_res = findViewById(R.id.txv_square_res);

        triangle = new Triangle(1., 1., 1.);
    }
    // обработка обновления данных
    public void setDataClick(View view) {
        triangle.setSide1(Utils.getRandInteger(3, 10));
        triangle.setSide2(Utils.getRandInteger(3, 10));
        triangle.setSide3(Utils.getRandInteger(3, 10));

        txv_side1_data.setText(String.valueOf(triangle.getSide1()));
        txv_side2_data.setText(String.valueOf(triangle.getSide2()));
        txv_side3_data.setText(String.valueOf(triangle.getSide3()));
    }
    // площадь
    public void squareClick(View view) {
        double v = triangle.square();
        txv_square_res.setText(String.format(Locale.UK, "%.3f", v));
    }
    // периметр
    public void perimeterClick(View view) {
        txv_perimeter_res.setText(String.valueOf(triangle.perimeter()));
    }
}