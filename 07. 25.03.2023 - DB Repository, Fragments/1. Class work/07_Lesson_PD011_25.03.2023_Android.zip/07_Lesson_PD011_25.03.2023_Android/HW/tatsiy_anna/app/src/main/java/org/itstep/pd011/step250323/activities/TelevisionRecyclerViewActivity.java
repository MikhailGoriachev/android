package org.itstep.pd011.step250323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import org.itstep.pd011.step250323.R;
import org.itstep.pd011.step250323.adapters.TelevisionRecyclerViewAdapter;
import org.itstep.pd011.step250323.models.Television;

import java.util.ArrayList;
import java.util.List;

public class TelevisionRecyclerViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_television_recycler_view);

        Bundle bundle = getIntent().getExtras();
        ArrayList<Television> televisions =  bundle.getParcelableArrayList("mylist");

        RecyclerView rcvModAnimals = findViewById(R.id.lsvTelevisionOptimizedAdapter);
        TelevisionRecyclerViewAdapter adapter = new TelevisionRecyclerViewAdapter(this, televisions);
        rcvModAnimals.setAdapter(adapter);
    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected
}