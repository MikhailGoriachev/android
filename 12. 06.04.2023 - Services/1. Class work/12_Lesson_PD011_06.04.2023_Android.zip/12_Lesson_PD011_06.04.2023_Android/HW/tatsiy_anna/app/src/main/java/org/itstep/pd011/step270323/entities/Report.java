package org.itstep.pd011.step270323.entities;

//Вычисляет размер заработной платы врача за каждый прием.
// Включает поля Фамилия врача, Имя врача, Отчество врача,
// Специальность врача, Стоимость приема, Зарплата.
// Сортировка по полю Специальность врача

public class Report {

    private long id;            // ид приема
    private String surname;     //Фамилия врача
    private String dname;       //Имя врача
    private String patronymic;  //Отчество врача
    private String sname;       //Специальность врача
    private int price;          //Стоимость приема
    private double profit;      //Зарплата врача

    public Report(long id, String surname, String dname, String patronymic, String sname, int price, double profit) {
        this.id = id;
        this.surname = surname;
        this.dname = dname;
        this.patronymic = patronymic;
        this.sname = sname;
        this.price = price;
        this.profit = profit;
    }

    public long getId() {
        return id;
    }

    public String getSurname() {
        return surname;
    }

    public String getDname() {
        return dname;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public String getSname() {
        return sname;
    }

    public int getPrice() {
        return price;
    }

    public double getProfit() {
        return profit;
    }
}
