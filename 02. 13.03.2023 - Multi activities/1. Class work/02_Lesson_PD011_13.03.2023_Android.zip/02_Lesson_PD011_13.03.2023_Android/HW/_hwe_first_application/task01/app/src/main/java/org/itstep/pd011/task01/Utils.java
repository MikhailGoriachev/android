package org.itstep.pd011.task01;

import java.util.Random;

// вспомогательные методы приложения
public class Utils {
    private static Random random = new Random();

    // генерация случайных чисел типа double, [lo, hi]
    public static double getRandom(double lo, double hi) {
        return lo + (hi - lo) * random.nextDouble();
    } // getRandom

    // проверка на существование треугольника
    public static boolean isTriangle(double a, double b, double c) {
        return a > 0 && b > 0 && c > 0 && a + b > c && a + c > b && b + c > a;
    } // isTriangle
} // class Utils
