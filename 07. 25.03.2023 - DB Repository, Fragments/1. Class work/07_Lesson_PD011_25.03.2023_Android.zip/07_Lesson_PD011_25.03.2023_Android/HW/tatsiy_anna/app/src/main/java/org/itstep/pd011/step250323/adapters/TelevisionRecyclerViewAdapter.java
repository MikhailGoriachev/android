package org.itstep.pd011.step250323.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.itstep.pd011.step250323.R;
import org.itstep.pd011.step250323.helpers.Utils;
import org.itstep.pd011.step250323.models.Television;

import java.util.List;
import java.util.Locale;

public class TelevisionRecyclerViewAdapter extends RecyclerView.Adapter<TelevisionRecyclerViewAdapter.ViewHolder> {
    private final Context context;               // пример использования Context в адаптере
    private final LayoutInflater inflater;     // загрузчик разметки элемента - из контекста создания - активность или фрагмент
    private final List<Television> televisions; // коллекция данных

    // для создания адаптера в точке вызова
    public TelevisionRecyclerViewAdapter(@NonNull Context context, @NonNull List<Television> televisions){

        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.televisions = televisions;
    }

    // возвращает экземпляр ViewHolder
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        return new ViewHolder(inflater.inflate(R.layout.television_recycler_item,parent,false));
    }

    // возвращает количество записей в коллекции
    @Override
    public int getItemCount() {
        return televisions.size();
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position){

        Television television = televisions.get(position);

        // вывести данные в элементы разметки view
        Utils.setViewImage(viewHolder.imgTelevision, television.getImage(), context);
        viewHolder.txvModel.setText(television.getModel());
        viewHolder.txvDiagonal.setText(String.format(Locale.UK,"Диагональ: %.2f",television.getDiagonal()));
        viewHolder.txvResolution.setText(String.format(Locale.UK,"Разрешение: %dx%d",television.getVertical(),television.getHorizontal()));
        viewHolder.txvPrice.setText(String.format(Locale.UK,"%d ₽",television.getPrice()));
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        final ImageView imgTelevision;
        final TextView txvModel;
        final TextView txvDiagonal;
        final TextView txvResolution;
        final TextView txvPrice;

        public ViewHolder(View view){
            super(view);

            imgTelevision = view.findViewById(R.id.imgItemTelevisions);
            txvModel = view.findViewById(R.id.txvModel);
            txvDiagonal = view.findViewById(R.id.txvDiagonal);
            txvResolution = view.findViewById(R.id.txvResolution);
            txvPrice = view.findViewById(R.id.txvPrice);
        }
    }
}
