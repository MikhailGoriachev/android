package org.itstep.pd011.mv.hw2.adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.databinding.BindingAdapter;
import org.itstep.pd011.mv.hw2.R;
import java.io.IOException;
import java.io.InputStream;

public class ShipBindingAdapters {

    @BindingAdapter(value = {"validateNotEmptyString", "error"})
    public static void validateNotEmpty(EditText editText, String value, String error) {
        if(TextUtils.isEmpty(value)) {
            editText.setError(error);
            editText.setBackgroundResource(R.drawable.edit_error);
        } else {
            editText.setError(null);
            editText.setBackgroundResource(R.drawable.edit_normal);
        }
    }

    @BindingAdapter(value = {"validateCargoWeight", "capacity", "error"})
    public static void validateCargoWeight(EditText editText, Integer weight, Integer capacity, String error) {
        if (weight < 0 || weight > capacity) {
            editText.setError(error);
            editText.setBackgroundResource(R.drawable.edit_error);
        } else {
            editText.setError(null);
            editText.setBackgroundResource(R.drawable.edit_normal);
        }
    }

    @BindingAdapter(value = {"validateCapacity", "error"})
    public static void validateCapacity(EditText editText, Integer capacity, String error) {
        if (capacity < 0) {
            editText.setError(error);
            editText.setBackgroundResource(R.drawable.edit_error);
        } else {
            editText.setError(null);
            editText.setBackgroundResource(R.drawable.edit_normal);
        }
    }

    @BindingAdapter(value = {"validateCostPerTon", "error"})
    public static void validateCostPerTon(EditText editText, Integer cost, String error) {
        if (cost < 0) {
            editText.setError(error);
            editText.setBackgroundResource(R.drawable.edit_error);
        } else {
            editText.setError(null);
            editText.setBackgroundResource(R.drawable.edit_normal);
        }
    }

    @BindingAdapter(value = {"totalCost", "costPerTon"})
    public static void setTotalCost(TextView textView, int weight, int costPerTon) {
        long totalCost = (long) weight * costPerTon;
        textView.setText(String.valueOf(totalCost));
    }

    @BindingAdapter("imageFile")
    public static void setImageFile(ImageView imageView, String fileName) {
        Context context = imageView.getContext();
        try (InputStream inputStream = context.getAssets().open(fileName)) {
            Drawable drawable = Drawable.createFromStream(inputStream, null);
            imageView.setImageDrawable(drawable);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
