package org.itstep.pd011.step270323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.adapters.ReceptsAdapter;
import org.itstep.pd011.step270323.adapters.WebServicePageAdapter;
import org.itstep.pd011.step270323.entities.Receipt;
import org.itstep.pd011.step270323.helpers.Utils;
import org.itstep.pd011.step270323.models.Album;
import org.itstep.pd011.step270323.models.Comment;
import org.itstep.pd011.step270323.models.Post;
import org.itstep.pd011.step270323.services.Api;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import kotlin.jvm.internal.PropertyReference0Impl;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class WebServiceActivity extends AppCompatActivity {

    ViewPager2 pager;         // страничный интерфейс
    FragmentStateAdapter pageAdapter;   // адаптер страницы
    TabLayout tabLayout;     // заголовки для переходов по страницам

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_service);

        pager = findViewById(R.id.vpgWebService);
        tabLayout = findViewById(R.id.tbLWebService);
        pageAdapter = new WebServicePageAdapter(this);

        pager.setAdapter(pageAdapter);

        TabLayoutMediator tabLayoutMediator = new TabLayoutMediator(tabLayout, pager, (tab, position) -> {

            // разметка заголовка страницы
            tab.setCustomView(R.layout.tab_header);
            TextView txvHeaderPage = Objects.requireNonNull(tab.getCustomView()).findViewById(R.id.txvHeaderPage);

            // настройка заголовков
            txvHeaderPage.setText(Utils.tableHeadersWebService[position + 1]);
        });

        // подключить настройщика к области вывода заголовоков
        tabLayoutMediator.attach();
    }


    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.web_service_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mniGetAlbums:
                //pageAdapter.createFragment(1);
                break;

            case R.id.mniGetAlbumById:
                //pageAdapter.createFragment(2);
                break;

            case R.id.mniGetComments:
                //pageAdapter.createFragment(3);
                break;

            case R.id.mniGetPosts:
                //pageAdapter.createFragment(4);
                break;

            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);

    } // onOptionsItemSelected
}