package org.itstep.pd011.step270323.helpers;

import android.annotation.SuppressLint;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class Utils {

    @SuppressLint("SimpleDateFormat")
    public static final DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

    public static Random random = new Random();

    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return random.ints(min, max).findFirst().getAsInt();
    }

    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * random.nextDouble();
    }

    //случайная дата c диапазоном от 2023-02-08 до 2023-03-31
    public static Date getDate(){

        long rangeBegin = Timestamp.valueOf("2023-02-08 00:00:00").getTime();
        long rangeEnd = Timestamp.valueOf("2023-03-31 00:00:00").getTime();
        long diff = rangeEnd - rangeBegin + 1;
        return new Timestamp(rangeBegin + (long)(Math.random() * diff));
    }

    public static String[] titles = {
            "Выбирает информацию о пациентах с фамилиями, начинающимися на заданную параметром последовательность букв",
            "Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше 2.3%",
            "Выбирает информацию о приемах за некоторый период",
            "Выбирает информацию о докторах, специальность которых задана параметром",
            "Вычисляет размер заработной платы врача за каждый прием.",
            "Для каждой даты вычисляет максимальную стоимость приема",
            "Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема"
    };

    public static String[] tableHeadersTables = {"Не выбран","Врачи","Пациенты","Приемы","Специальности"};

    public static String[] tableHeadersWebService = {"Не выбран","Альбомы","Выбрать альбом по Id","Комментарии","Посты"};
}
