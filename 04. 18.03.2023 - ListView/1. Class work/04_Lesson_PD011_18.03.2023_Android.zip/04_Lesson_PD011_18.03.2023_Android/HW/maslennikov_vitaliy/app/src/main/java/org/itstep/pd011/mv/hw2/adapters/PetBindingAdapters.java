package org.itstep.pd011.mv.hw2.adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.databinding.BindingAdapter;
import org.itstep.pd011.mv.hw2.R;
import java.io.IOException;
import java.io.InputStream;

public class PetBindingAdapters {

    @BindingAdapter(value = {"validateNotEmptyString", "error"})
    public static void validateNotEmpty(EditText editText, String value, String error) {
        if(TextUtils.isEmpty(value)) {
            editText.setError(error);
            editText.setBackgroundResource(R.drawable.edit_error);
        } else {
            editText.setError(null);
            editText.setBackgroundResource(R.drawable.edit_normal);
        }
    }

    @BindingAdapter(value = {"validateAge", "error"})
    public static void validateAge(EditText editText, Integer age, String error) {
        if (age <= 0) {
            editText.setError(error);
            editText.setBackgroundResource(R.drawable.edit_error);
        } else {
            editText.setError(null);
            editText.setBackgroundResource(R.drawable.edit_normal);
        }
    }

    @BindingAdapter(value = {"validateWeight", "error"})
    public static void validateWeight(EditText editText, double weight, String error) {
        if (weight <= 0) {
            editText.setError(error);
            editText.setBackgroundResource(R.drawable.edit_error);
        } else {
            editText.setError(null);
            editText.setBackgroundResource(R.drawable.edit_normal);
        }
    }

    @BindingAdapter("imageFile")
    public static void setImageFile(ImageView imageView, String fileName) {
        Context context = imageView.getContext();
        try (InputStream inputStream = context.getAssets().open(fileName)) {
            Drawable drawable = Drawable.createFromStream(inputStream, null);
            imageView.setImageDrawable(drawable);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
