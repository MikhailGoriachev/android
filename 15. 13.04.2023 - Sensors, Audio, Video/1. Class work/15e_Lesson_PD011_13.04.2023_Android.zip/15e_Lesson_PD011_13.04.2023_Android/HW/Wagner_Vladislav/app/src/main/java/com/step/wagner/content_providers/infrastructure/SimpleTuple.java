package com.step.wagner.content_providers.infrastructure;

public class SimpleTuple<Val1,Val2> {
    public Val1 value1;
    public Val2 value2;

    public SimpleTuple(Val1 value1, Val2 value2) {
        this.value1 = value1;
        this.value2 = value2;
    }
}
