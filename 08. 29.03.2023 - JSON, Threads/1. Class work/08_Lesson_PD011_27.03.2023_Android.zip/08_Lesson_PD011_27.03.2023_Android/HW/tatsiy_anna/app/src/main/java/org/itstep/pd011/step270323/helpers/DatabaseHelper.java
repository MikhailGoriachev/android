package org.itstep.pd011.step270323.helpers;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static String DB_PATH;             // полный путь к базе данных
    private static final String DB_NAME   = "Appointment.db";
    private static final int SCHEMA = 1;       // версия базы данных
    private final Context myContext;

    public DatabaseHelper(Context context){
        super(context, DB_NAME, null, SCHEMA);
        this.myContext = context;

        // получить полный путь к базе данных
        DB_PATH = context.getFilesDir().getPath() + "/" + DB_NAME;
    }

    @Override
    public void onCreate(SQLiteDatabase db) { }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {}

    // собственные действия для создании БД
    public void create_db(){

        // если файл БД есть, просто выходим, иначе - копируем файл
        // из папки assets
        if (new File(DB_PATH).exists()) return;

        // разрешение записи в файл базы данных - для файлового потока тоже
        this.getReadableDatabase();

        // получаем локальную бд как поток
        try (InputStream oldDatbase = myContext.getAssets().open(DB_NAME)) {

            // Создать файл, в котором и будет размещаться БД
            OutputStream newDatabase = new FileOutputStream(DB_PATH);

            // побайтово копируем данные
            byte[] buffer = new byte[1024];
            int length;
            while ((length = oldDatbase.read(buffer)) > 0) {
                newDatabase.write(buffer, 0, length);
            }

            // принудительно записать последний, не полный буфер
            // для полного буфера вызов игнорирует запись
            newDatabase.flush();

            // закрыть файловые потоки
            newDatabase.close();
        } catch(IOException ex){
            Log.d("DatabaseHelper", ex.getMessage());
        } // try-catch
    }

    // подключение к БД
    public SQLiteDatabase open() throws SQLException {
        return SQLiteDatabase.openDatabase(DB_PATH, null, SQLiteDatabase.OPEN_READWRITE);
    } // open
}
