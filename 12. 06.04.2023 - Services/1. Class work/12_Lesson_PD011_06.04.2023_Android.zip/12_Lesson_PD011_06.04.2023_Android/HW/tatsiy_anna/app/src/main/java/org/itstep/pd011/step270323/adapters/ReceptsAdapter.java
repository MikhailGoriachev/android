package org.itstep.pd011.step270323.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.helpers.Utils;
import org.itstep.pd011.step270323.entities.Receipt;
import org.itstep.pd011.step270323.repositories.ReceptsDatabaseRepository;

import java.util.List;

public class ReceptsAdapter extends ArrayAdapter<Receipt> {

    private final LayoutInflater inflater;     // загрузчик разметки элемента - из контекста создания - активность или фрагмент
    private final int            layout;       // ид разметки элемента списка
    private List<Receipt> receipts;
    private final ReceptsDatabaseRepository repository;

    public void setReceipts(List<Receipt> receipts) {
        this.receipts = receipts;
    }

    public ReceptsAdapter(@NonNull Context context, int resource, List<Receipt> receipts, ReceptsDatabaseRepository repository){
        super(context, resource, receipts);

        this.layout = resource;
        this.inflater = LayoutInflater.from(context);
        this.receipts = receipts;
        this.repository = repository;
    }


    public View getView(int position, View convertView, ViewGroup parent){

        // 2й вариант оптимизации - использование ViewHolder - внутренний класс
        final ReceptsAdapter.ViewHolder viewHolder;

        if (convertView == null){
            convertView = inflater.inflate(this.layout, parent, false);
            viewHolder = new ViewHolder(convertView, position);

            // сохранить все ссылки на элементы разметки
            // в поле tag convertView, тип tag - Object
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ReceptsAdapter.ViewHolder) convertView.getTag();
            viewHolder.position = position;
        } // if

        viewHolder.txvTitle.setText(receipts.get(position).toString());

        return convertView;
    }

    // класс ViewHolder - хранит ссылки на элементы разметки
    // исключает повторные операции поиска элементов в разметке
    private class ViewHolder{

        // элементы интерфейса из разметки элемента
        final TextView txvTitle;
        final Button btnEdit;
        final Button btnDelete;

        private int position;

        public ViewHolder(View view, int position){

            txvTitle = view.findViewById(R.id.txvTitle);
            btnEdit = view.findViewById(R.id.btnEdit);
            btnDelete = view.findViewById(R.id.btnDelete);

            // позиция элемента в коллекции
            this.position = position;

            btnEdit.setOnClickListener(v->{
                receipts.get(position).setDate(Utils.getDate());
                repository.update(receipts.get(position));
                notifyDataSetChanged();
            });

            btnDelete.setOnClickListener(v -> {
                repository.delete(receipts.remove(position).getId());
                notifyDataSetChanged();
            });
        }

    }
}

