package org.itstep.pd011.mv.hw2.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import androidx.databinding.library.baseAdapters.BR;

public class Pet extends BaseObservable implements Parcelable  {

    public static final int ageMinValue = 1;
    public static final double weightMinValue = 0.1;

    private String breed;
    private String name;
    private int age;
    private double weight;
    private String owner;
    private String imageFile;
    private boolean specialDiet;

    // полувольное содержание
    private boolean semiVoluntary;

    public Pet() {this("Золотистый Ретривер", "Граф", 4, 42,
            "Андреев Ю.А.", "retriever.jpg", false, false);}

    public Pet(String breed, String name, int age, double weight, String owner, String imageFile, boolean isSpecialDiet, boolean isSemiVoluntary) {
        this.breed = breed;
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.owner = owner;
        this.imageFile = imageFile;
        this.specialDiet = isSpecialDiet;
        this.semiVoluntary = isSemiVoluntary;
    }

    protected Pet(Parcel in) {
        breed = in.readString();
        name = in.readString();
        age = in.readInt();
        weight = in.readDouble();
        owner = in.readString();
        imageFile = in.readString();
        specialDiet = in.readByte() != 0;
        semiVoluntary = in.readByte() != 0;
    }

    public static final Creator<Pet> CREATOR = new Creator<Pet>() {
        @Override
        public Pet createFromParcel(Parcel in) {
            return new Pet(in);
        }

        @Override
        public Pet[] newArray(int size) {
            return new Pet[size];
        }
    };

    @Bindable
    public boolean isSpecialDiet() {
        return specialDiet;
    }

    public void setSpecialDiet(boolean specialDiet) {
        this.specialDiet = specialDiet;
        notifyPropertyChanged(BR.specialDiet);

    }

    @Bindable
    public boolean isSemiVoluntary() {
        return semiVoluntary;
    }

    public void setSemiVoluntary(boolean semiVoluntary) {
        this.semiVoluntary = semiVoluntary;
        notifyPropertyChanged(BR.semiVoluntary);
    }

    @Bindable
    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
        notifyPropertyChanged(BR.breed);
    }

    @Bindable
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        notifyPropertyChanged(BR.name);
    }

    @Bindable
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
        notifyPropertyChanged(BR.age);
    }

    @Bindable
    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
        notifyPropertyChanged(BR.weight);
    }

    @Bindable
    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
        notifyPropertyChanged(BR.owner);
    }

    @Bindable
    public String getImageFile() {
        return imageFile;
    }

    public void setImageFile(String imageFile) {
        this.imageFile = imageFile;
        notifyPropertyChanged(BR.imageFile);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(breed);
        parcel.writeString(name);
        parcel.writeInt(age);
        parcel.writeDouble(weight);
        parcel.writeString(owner);
        parcel.writeString(imageFile);
        parcel.writeByte((byte) (specialDiet ? 1 : 0));
        parcel.writeByte((byte) (semiVoluntary ? 1 : 0));
    }
}