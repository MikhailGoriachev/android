package org.itstep.pd011.step160323.models;

//В эту активность передавайте данные о домашнем животном: порода,
// кличка, возраст, вес, фамилия и
// инициалы владельца, имя файла с изображением в папке assets.

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Animal implements Parcelable {

    private String breed;   //порода
    private String name;    //кличка
    private int age;        //возраст
    private double weight;  //вес
    private String surname; //фамилия
    private String owner;   //инициалы владельца
    private final String image;   //имя файла с изображением

    public Animal() { this("Такса","Феня",10,12.5,"Петров","Петрова А. Н.","dog.jpg");
    }

    public Animal(String breed, String name, int age, double weight, String surname, String owner, String image) {
        this.breed = breed;
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.surname = surname;
        this.owner = owner;
        this.image = image;
    }

    public String getBreed() {
        return breed;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    public String getSurname() {
        return surname;
    }

    public String getOwner() {
        return owner;
    }

    public String getImage() {
        return image;
    }

    public void setBreed(String breed) throws Exception {

        //проверка строки на пустоту
        if (breed == null || breed.isEmpty()){
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.breed = breed;
    }

    public void setName(String name) throws Exception {

        //проверка строки на пустоту
        if (name == null || name.isEmpty()){
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.name = name;
    }

    public void setAge(int age) throws Exception {

        if (age < 1){
            throw new Exception("Возраст не может быть отрицательным!");
        }
        this.age = age;
    }

    public void setWeight(double weight) throws Exception {

        if (weight < 1) {
            throw new Exception("Вес не может быть отрицательным!");
        }
        this.weight = weight;
    }

    public void setSurname(String surname) throws Exception {

        //проверка строки на пустоту
        if (surname == null || surname.isEmpty()){
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.surname = surname;
    }

    public void setOwner(String owner) throws Exception {

        //проверка строки на пустоту
        if (owner == null || owner.isEmpty()){
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.owner = owner;
    }

    protected Animal(Parcel in) {
        breed = in.readString();
        name = in.readString();
        age = in.readInt();
        weight = in.readDouble();
        surname = in.readString();
        owner = in.readString();
        image = in.readString();
    }

    public static final Creator<Animal> CREATOR = new Creator<Animal>() {
        @Override
        public Animal createFromParcel(Parcel in) {
            return new Animal(in);
        }

        @Override
        public Animal[] newArray(int size) {
            return new Animal[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(breed);
        parcel.writeString(name);
        parcel.writeInt(age);
        parcel.writeDouble(weight);
        parcel.writeString(surname);
        parcel.writeString(owner);
        parcel.writeString(image);
    }

    @NonNull
    @Override
    public String toString() {
        return "Животное:\n" +
                breed + '\n' +
                name + '\n' +
                age + " лет\n" +
                weight + " кг.\n" +
                surname + '\n' +
                owner;
    }
}
