package org.itstep.pd011.step270323.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.entities.Report;

import java.util.List;
import java.util.Locale;

public class ReportAdapter extends ArrayAdapter<Report> {

    private final LayoutInflater inflater;     // загрузчик разметки элемента - из контекста создания - активность или фрагмент
    private final int            layout;       // ид разметки элемента списка
    private final List<Report> reports;

    public ReportAdapter(@NonNull Context context, int resource, @NonNull List<Report> reports) {
        super(context, resource, reports);

        this.inflater = LayoutInflater.from(context);
        this.layout = resource;
        this.reports = reports;
    }

    public View getView(int position, View convertView, ViewGroup parent){

        // 2й вариант оптимизации - использование ViewHolder - внутренний класс
        final ReportAdapter.ViewHolder viewHolder;

        if (convertView == null){
            convertView = inflater.inflate(this.layout, parent, false);
            viewHolder = new ReportAdapter.ViewHolder(convertView, position);

            // сохранить все ссылки на элементы разметки
            // в поле tag convertView, тип tag - Object
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ReportAdapter.ViewHolder) convertView.getTag();
            viewHolder.position = position;
        } // if

        Report r = reports.get(position);

        viewHolder.textId.setText(String.format(Locale.UK,"Id приема: %d",r.getId()));
        viewHolder.textDoctor.setText(String.format(Locale.UK,"ФИО врача: %s %s %s", r.getSurname(), r.getDname(), r.getPatronymic()));
        viewHolder.textPrice.setText(String.format(Locale.UK, "Стоимость приема %d ₽", r.getPrice()));
        viewHolder.textSpecialtie.setText(String.format(Locale.UK,"Специальность врача: %s", r.getSname()));
        viewHolder.textProfit.setText(String.format(Locale.UK,"Зарплата: %.0f ₽", r.getProfit()));

        return convertView;
    }

    private class ViewHolder{

        // элементы интерфейса из разметки элемента
        final TextView textId;
        final TextView textDoctor;
        final TextView textSpecialtie;
        final TextView textPrice;
        final TextView textProfit;

        private int position;

        public ViewHolder(View view, int position){

            textId = view.findViewById(R.id.txvId);
            textDoctor = view.findViewById(R.id.txvDoctor);
            textSpecialtie = view.findViewById(R.id.txvSpecialtie);
            textPrice = view.findViewById(R.id.txvPrice);
            textProfit = view.findViewById(R.id.txvProfit);

            // позиция элемента в коллекции
            this.position = position;
        }
    }
}
