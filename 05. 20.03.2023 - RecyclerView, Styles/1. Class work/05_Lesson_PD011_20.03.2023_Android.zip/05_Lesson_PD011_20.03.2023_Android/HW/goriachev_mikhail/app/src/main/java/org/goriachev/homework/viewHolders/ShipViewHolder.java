package org.goriachev.homework.viewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.goriachev.homework.R;

public class ShipViewHolder {

    // элемент для вывода изображения судна
    public ImageView ivwShip;

    // поля для вывода информации о судне
    public TextView txvShipType, txvShipCargoWeight, txvShipPrice;

    public final LinearLayout layShipItem;

    // позиция элемента в коллекции
    public int position;


    // конструктор инициализирующий
    public ShipViewHolder(View view, int position) {

        this.position = position;

        layShipItem = view.findViewById(R.id.lay_ship_item);

        // поиск элементов о судне
        txvShipType = view.findViewById(R.id.txv_ship_type);
        txvShipCargoWeight = view.findViewById(R.id.txv_ship_weight);
        txvShipPrice = view.findViewById(R.id.txv_ship_price);

        ivwShip = view.findViewById(R.id.ivw_ship_image);

    }
}
