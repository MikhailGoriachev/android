package org.itstep.pd011.step270323.converters;

import org.itstep.pd011.step270323.helpers.Shell;
import org.itstep.pd011.step270323.entities.Doctor;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;

import java.lang.reflect.Type;

public class DoctorConverter extends Shell<Doctor> {

    public JsonElement serialize(Doctor src, Type type, JsonSerializationContext context ){

        JsonObject object = new JsonObject();
        object.addProperty("id", src.getId());
        object.addProperty("surname", src.getSurname());
        object.addProperty("name", src.getName());
        object.addProperty("patronymic", src.getPatronymic());
        object.addProperty("id_specialtie", src.getId_specialtie());
        object.addProperty("tax", src.getTax());

        return object;
    }

    public Doctor deserialize (JsonElement json, Type type,
                               JsonDeserializationContext context) throws JsonParseException {

        JsonObject object = json.getAsJsonObject();

        return new Doctor(
                object.get("id").getAsLong(),
                object.get("surname").getAsString(),
                object.get("name").getAsString(),
                object.get("patronymic").getAsString(),
                object.get("id_specialtie").getAsInt(),
                object.get("tax").getAsDouble()
        );
    }
}
