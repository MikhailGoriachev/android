package org.itstep.pd011.step160323.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.adapters.AnimalsOptimizedAdapter;
import org.itstep.pd011.step160323.models.Animal;
import org.itstep.pd011.step160323.models.Breed;
import java.util.ArrayList;
import java.util.List;

public class AnimalsOptimizedActivity extends AppCompatActivity {

    private List<Animal> animals;
    public static final int
            ID_ANIMAL_ACTIVITY = 1010;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animals_optimized);

        initializer();

        // 1. Получение ссылки на ListView
        ListView listView = findViewById(R.id.lsvAnimalsOptimizedAdapter);

        AnimalsOptimizedAdapter animalsOptimizedAdapter = new AnimalsOptimizedAdapter(
                this, R.layout.animal_item_action,
                animals,this::startAnimalsActivity
        );

        // 3. Назаначение адаптера
        listView.setAdapter(animalsOptimizedAdapter);
    }

    void initializer() {
        animals = new ArrayList<>(List.of(
                new Animal(),
                new Animal(Breed.HUSKY.getTitle(),"Лева", 3, 25.5, "Иванов", "Иванов И. Н.",Breed.HUSKY.getImage(),true,false),
                new Animal(Breed.MAINECOON.getTitle(),"Багира", 5, 8, "Колпакова", "Колпакова Т. Г.",Breed.MAINECOON.getImage(),false,false),
                new Animal(Breed.HUSKY.getTitle(),"Боня", 5, 30.5, "Иванов", "Иванов И. Н.",Breed.HUSKY.getImage(),true,true),
                new Animal(Breed.MAINECOON.getTitle(),"Барсик", 10, 10.4, "Колпакова", "Колпакова Т. Г.",Breed.MAINECOON.getImage(),true,false)
        ));
    }

    // обработчик клика по кнопке вызова активности для Animal
    private void startAnimalsActivity(int pos){

        Intent intent = new Intent(this, AnimalActivity.class);

        // передача параметра в активность
        intent.putExtra(Animal.class.getCanonicalName(), animals.get(pos));

        startActivityForResult(intent,ID_ANIMAL_ACTIVITY);
    }
}

