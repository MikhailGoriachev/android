package ru.cherkas.home.home4.models;

public class Cargo {
    private String type;  // тип груза
    private String title; // название груза
    private int price;    // цена за тону

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Cargo(String type, String title, int price) {
        this.type = type;
        this.title = title;
        this.price = price;
    }
}
