package org.goriachev.homework.viewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.goriachev.homework.R;

public class AnimalViewHolder {

    // элемент для вывода изображения животного
    public final ImageView ivwAnimal;

    // поля для вывода информации о животном
    public final TextView txvAnimalName, txvAnimalBreed, txvAnimalOwner;

    public final LinearLayout layAnimalItem;

    // позиция элемента в коллекции
    public int position;


    // конструктор инициализирующий
    public AnimalViewHolder(View view, int position) {

        this.position = position;

        layAnimalItem = view.findViewById(R.id.lay_animal_item);

        txvAnimalName = view.findViewById(R.id.txv_animal_name);
        txvAnimalBreed = view.findViewById(R.id.txv_animal_breed);
        txvAnimalOwner = view.findViewById(R.id.txv_animal_owner);

        ivwAnimal = view.findViewById(R.id.ivw_animal_image);
    }
}
