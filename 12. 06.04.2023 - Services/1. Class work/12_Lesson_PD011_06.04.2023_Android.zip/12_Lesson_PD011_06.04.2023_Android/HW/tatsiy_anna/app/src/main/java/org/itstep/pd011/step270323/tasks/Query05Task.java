package org.itstep.pd011.step270323.tasks;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.ListView;
import android.widget.TextView;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.adapters.ReportAdapter;
import org.itstep.pd011.step270323.entities.Report;
import org.itstep.pd011.step270323.repositories.ReceptsDatabaseRepository;

import java.util.List;

//Вычисляет размер заработной платы врача за каждый прием.

@SuppressLint("StaticFieldLeak")
public class Query05Task extends AsyncTask<Void,Void, List<Report>> {

    private final Context context;
    private final ListView listView;
    private final TextView textView;

    public Query05Task(Context context, ListView listView, TextView textView) {
        this.context = context;
        this.listView = listView;
        this.textView = textView;
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        textView.setText("Вычисляет размер заработной платы врача за каждый прием.");
    } // onPreExecute

    @Override
    protected List<Report> doInBackground(Void... voids) {

        ReceptsDatabaseRepository repository = new ReceptsDatabaseRepository(context);
        repository.open();

        List<Report> list = repository.generateReport();

        repository.close();

        return list;
    }

    @Override
    protected void onPostExecute(List<Report> params) {
        super.onPostExecute(params);

        if(params != null) {
            listView.setAdapter(
                    new ReportAdapter(
                            context,
                            R.layout.report_item,
                            params)
            );
        }
    }
}
