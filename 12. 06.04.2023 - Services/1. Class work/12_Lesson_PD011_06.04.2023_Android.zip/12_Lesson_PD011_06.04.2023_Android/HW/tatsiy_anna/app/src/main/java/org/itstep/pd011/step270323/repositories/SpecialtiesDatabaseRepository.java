package org.itstep.pd011.step270323.repositories;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import org.itstep.pd011.step270323.helpers.DatabaseHelper;
import org.itstep.pd011.step270323.entities.Specialtie;
import java.util.ArrayList;
import java.util.List;

public class SpecialtiesDatabaseRepository {

    // поля для работы с БД
    private final DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    // название таблицы в БД
    static final String TABLE = "Specialties";

    // названия столбцов
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";

    public SpecialtiesDatabaseRepository(Context context){
        dbHelper = new DatabaseHelper(context.getApplicationContext());
        dbHelper.create_db();
    } // DatabaseRepository

    public SpecialtiesDatabaseRepository open(){
        database = dbHelper.open();
        return this;
    } // open

    public void close(){ dbHelper.close(); }

    private Cursor getAllEntries(){

        String[] columns = new String[] {COLUMN_ID, COLUMN_NAME};

        return  database.query(
                TABLE, columns, null, null, null,
                null, null);
    } // getAllEntries

    // метод паттерна Репозиторий
    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, TABLE);
    }

    // возвращает коллекцию пользователей из таблицы БД
    @SuppressLint("Range")
    public List<Specialtie> getSpecialties(){
        ArrayList<Specialtie> specialties = new ArrayList<>();
        Cursor cursor = getAllEntries();  // запрос к БД
        if(cursor.moveToFirst()){
            do{
                // добавление в коллекцию объекта Patient
                specialties.add(getSpecialtieFromCursor(cursor));
            } while (cursor.moveToNext());
        } // if
        cursor.close();
        return specialties;
    }

    @SuppressLint("Range")
    public Specialtie getSpecialtie(long id) {
        Specialtie specialtie = null;

        String query = String.format(
                "SELECT * FROM %s WHERE %s=?",
                TABLE,
                COLUMN_ID);

        Cursor cursor = database.rawQuery(query, new String[]{String.valueOf(id)});

        // чтение данных, если они получены
        if(cursor.moveToFirst()){
            specialtie = getSpecialtieFromCursor(cursor);
        } // if

        cursor.close();
        return specialtie;
    }

    // метод - оболочка для запроса insert
    public long insert(Specialtie specialtie){
        return database.insert(TABLE, null, getContentValues(specialtie));
    } // insert

    // метод - оболочка для запроса update
    public long update(Specialtie specialtie){
        return database.update(TABLE, getContentValues(specialtie), COLUMN_ID + "=" + specialtie.getId(), null);
    } // update

    private ContentValues getContentValues(Specialtie specialtie){

        ContentValues cv = new ContentValues();

        cv.put(COLUMN_NAME, specialtie.getName());
        return cv;
    }

    @SuppressLint("Range")
    private Specialtie getSpecialtieFromCursor(Cursor cursor){

        return new Specialtie(
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
    }
}
