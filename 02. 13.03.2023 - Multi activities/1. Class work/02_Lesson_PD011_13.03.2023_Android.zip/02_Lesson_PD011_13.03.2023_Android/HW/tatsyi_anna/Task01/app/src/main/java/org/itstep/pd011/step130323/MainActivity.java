package org.itstep.pd011.step130323;

import androidx.appcompat.app.AppCompatActivity;
import org.itstep.pd011.step130323.models.Triangle;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Triangle triangle;
    private TextView txvSides;
    private TextView txvPerimeter;
    private TextView txvArea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        triangle = new Triangle(1,6);

        txvSides = findViewById(R.id.txvSides);
        txvPerimeter = findViewById(R.id.txvPerimeter);
        txvArea = findViewById(R.id.txvArea);

        txvSides.setText(triangle.toString());
    }

    public void generate(View view){
        triangle = new Triangle(1,6);
        txvSides.setText(triangle.toString());

        txvPerimeter.setText("Здесь будет периметр");
        txvArea.setText("Здесь будет площадь");
    }

    public void calcPerimeter(View view){
        txvPerimeter.setText(String.format(Locale.UK,"%.3f",triangle.perimeter()));
    }

    public void calcArea(View view){
        txvArea.setText(String.format(Locale.UK,"%.3f",triangle.area()));
    }
}