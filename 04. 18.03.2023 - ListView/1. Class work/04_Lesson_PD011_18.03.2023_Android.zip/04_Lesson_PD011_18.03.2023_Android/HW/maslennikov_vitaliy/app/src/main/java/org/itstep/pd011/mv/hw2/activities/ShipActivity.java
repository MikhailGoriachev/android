package org.itstep.pd011.mv.hw2.activities;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.google.android.material.snackbar.Snackbar;
import org.itstep.pd011.mv.hw2.MainActivity;
import org.itstep.pd011.mv.hw2.R;
import org.itstep.pd011.mv.hw2.databinding.ActivityShipBinding;
import org.itstep.pd011.mv.hw2.models.Ship;
import org.itstep.pd011.mv.hw2.infrastructure.RepeatListener;

@SuppressLint("ClickableViewAccessibility")
public class ShipActivity extends AppCompatActivity {
    private final int incrementStep = 20;
    private final int pressButtonFirstInterval = 500;
    private final int pressButtonCyclicInterval = 100;

    Ship ship;

    ActivityShipBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_ship);

        Intent intent = getIntent();
        ship = intent.getParcelableExtra(Ship.class.getCanonicalName());

        binding.setShip(ship);
        binding.setStep(incrementStep);

        binding.btnIncWeight.setOnTouchListener(weightIncrementListener());
        binding.btnDecWeight.setOnTouchListener(weightDecrementListener());
        binding.btnCancel.setOnClickListener(this::onCancelClick);
        binding.btnOk.setOnClickListener(this::onOkClick);
        binding.btnClear.setOnClickListener(this::onClearClick);
    }

    private View.OnTouchListener weightIncrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
           ship.setCargoWeight(ship.getCargoWeight() + incrementStep);
        });
    }

    private View.OnTouchListener weightDecrementListener() {
        return new RepeatListener(pressButtonFirstInterval, pressButtonCyclicInterval, view -> {
            if(ship.getCargoWeight() - incrementStep >= 0)
                ship.setCargoWeight(ship.getCargoWeight() - incrementStep);
        });
    }

    public void onClearClick(View view) {
        binding.edtShipType.setText("");
        binding.edtShipCapacity.setText(String.valueOf(0));
        binding.edtDestination.setText("");
        binding.edtCargoType.setText("");
        binding.edtCargoWeight.setText(String.valueOf(0));
        binding.edtCostPerTon.setText(String.valueOf(0));
    }

    public void onOkClick(View view) {
        Integer errorMessage = null;

        if (ship.getType().isBlank()) {
            errorMessage = R.string.requireTypeMsg;
        } else if (ship.getDestination().isBlank()) {
            errorMessage = R.string.requireDestinationMsg;
        } else if (ship.getCargoType().isBlank()) {
            errorMessage = R.string.requireCargoTypeMsg;
        } else if (ship.getCargoWeight() < 0) {
            errorMessage = R.string.invalidCargoWeightMsg;
        } else if (ship.getCapacity() < 0) {
            errorMessage = R.string.invalidCapacityMsg;
        } else if (ship.getCostPerTon() < 0) {
            errorMessage = R.string.invalidCostPerTonMsg;
        } else if (ship.getCargoWeight() > ship.getCapacity()) {
            errorMessage = R.string.weightMoreCapacityMsg;
        }

        if (errorMessage != null) {
            Snackbar.make(view, errorMessage, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.btnOkTitle, v -> {})
                    .show();
            return;
        }

        Intent intent = new Intent();
        intent.putExtra(Ship.class.getCanonicalName(), ship);

        setResult(MainActivity.RESULT_OK, intent);
        finish();
    }

    public void onCancelClick(View view) {
        finish();
    }

   @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putParcelable(Ship.class.getCanonicalName(), ship);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        ship = savedInstanceState.getParcelable(Ship.class.getCanonicalName());
    }

}
