package org.itstep.pd011.step270323.models;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Patient {

    private long id;       // ид
    private String surname;
    private String name;
    private String patronymic;
    private Date dateOfBirth;
    private String address;

    public Patient(long id, String surname, String name, String patronymic, Date dateOfBirth, String address) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @SuppressLint("SimpleDateFormat")
    @NonNull
    @Override
    public String toString() {

        return
                "id: " + id + "\n"+
                "фамилия: " + surname + "\n" +
                "имя: " + name + "\n" +
                "отчество: " + patronymic + "\n" +
                "дата рождения: " +  new SimpleDateFormat("dd.MM.yyyy").format(dateOfBirth) + "\n" +
                "адрес проживания: '" + address;
    }
}
