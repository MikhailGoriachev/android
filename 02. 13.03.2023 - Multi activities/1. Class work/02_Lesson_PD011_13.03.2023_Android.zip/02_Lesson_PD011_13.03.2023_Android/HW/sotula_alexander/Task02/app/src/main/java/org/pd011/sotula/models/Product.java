package org.pd011.sotula.models;

public class Product {

    String title;
    int amount;
    double unitCost;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public double getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(double unitCost) {
        this.unitCost = unitCost;
    }

    public Product(String title, int amount, double unitCost) {
        this.title = title;
        this.amount = amount;
        this.unitCost = unitCost;
    }

    public double getTotalSum() {
        return unitCost * amount;
    }
}
