package ru.cherkas.home.home4.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import ru.cherkas.home.home4.R;
import ru.cherkas.home.home4.models.Ship;

public class ChipActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chip);

        Bundle arg = getIntent().getExtras();

        Ship ship;
        if (arg != null) {
            ship = arg.getParcelable(Ship.class.getSimpleName());

        }
    }
}