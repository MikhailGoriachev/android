package org.itstep.pd011.step160323.helpers;

import android.graphics.PorterDuff;
import android.text.Editable;
import android.text.TextWatcher;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.util.function.Consumer;
import java.util.function.Predicate;

import com.google.android.material.snackbar.Snackbar;

import org.itstep.pd011.step160323.R;

import java.io.InputStream;

public class Utils {

    public static void showError(EditText editText, String msg) {
        Snackbar snackbar = Snackbar.make(editText, msg, Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("OK", g -> {
        });
        snackbar.show();
    }

    public static void setImage(int id, ImageView imageView, Context context) {

        try (InputStream inputStream = context.getResources().openRawResource(id)) {
            Drawable drawable = Drawable.createFromStream(inputStream, null);

            imageView.setImageDrawable(drawable);
            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // добавление обработчика события изменения текста
    public static void addTextChangedListener(EditText editText, Consumer<String> onTextChangedHandler) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                onTextChangedHandler.accept(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    // проверка валидации по предикату и установка ошибки
    public static boolean isValidEditText(EditText editText, Predicate<String> predicate, String errorMessage, Context context) {
        if (!predicate.test(editText.getText().toString())) {
            editText.setError(errorMessage);
            editText.getBackground()
                    .setColorFilter(context.getResources().getColor(R.color.red),
                            PorterDuff.Mode.SRC_ATOP);
            return false;

        }

        editText.getBackground()
                .setColorFilter(context.getResources().getColor(R.color.black),
                        PorterDuff.Mode.SRC_ATOP);

        return true;

    }

}
