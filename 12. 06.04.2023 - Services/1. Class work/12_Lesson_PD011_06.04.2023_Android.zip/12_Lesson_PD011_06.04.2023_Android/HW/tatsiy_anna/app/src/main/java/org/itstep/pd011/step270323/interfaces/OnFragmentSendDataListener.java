package org.itstep.pd011.step270323.interfaces;

public interface OnFragmentSendDataListener {
     void onSendPosition(Integer position);
}
