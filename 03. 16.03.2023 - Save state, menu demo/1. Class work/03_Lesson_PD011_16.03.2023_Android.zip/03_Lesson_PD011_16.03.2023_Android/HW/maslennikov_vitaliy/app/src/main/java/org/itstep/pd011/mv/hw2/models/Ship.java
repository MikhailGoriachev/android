package org.itstep.pd011.mv.hw2.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.mobsandgeeks.saripaar.annotation.Max;
import com.mobsandgeeks.saripaar.annotation.Min;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.itstep.pd011.mv.hw2.R;

public class Ship implements Parcelable {

    public static final int maxCapacity = 15000;


    String type;
    int capacity;
    String destination;
    String cargoType;
    int cargoWeight;
    int costPerTon;
    String imageFile;

    public Ship() {this("Балкер-углевоз", 15000, "Севастополь", "Каменный уголь", 14500, 5000, "coiler.jpg");}


    public Ship(String type, int capacity, String destination, String cargoType, int cargoWeight, int costPerTon, String imageFile) {
        this.type = type;
        this.capacity = capacity;
        this.destination = destination;
        this.cargoType = cargoType;
        this.cargoWeight = cargoWeight;
        this.costPerTon = costPerTon;
        this.imageFile = imageFile;
    }

    protected Ship(Parcel in) {
        type = in.readString();
        capacity = in.readInt();
        destination = in.readString();
        cargoType = in.readString();
        cargoWeight = in.readInt();
        costPerTon = in.readInt();
        imageFile = in.readString();
    }

    public static final Creator<Ship> CREATOR = new Creator<Ship>() {
        @Override
        public Ship createFromParcel(Parcel in) {
            return new Ship(in);
        }

        @Override
        public Ship[] newArray(int size) {
            return new Ship[size];
        }
    };

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getCargoType() {
        return cargoType;
    }

    public void setCargoType(String cargoType) {
        this.cargoType = cargoType;
    }

    public int getCargoWeight() {
        return cargoWeight;
    }

    public void setCargoWeight(int cargoWeight) {
        this.cargoWeight = cargoWeight;
    }

    public int getCostPerTon() {
        return costPerTon;
    }

    public void setCostPerTon(int costPerTon) {
        this.costPerTon = costPerTon;
    }

    public String getImageFile() {
        return imageFile;
    }

    public void setImageFile(String imageFile) {
        this.imageFile = imageFile;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(type);
        parcel.writeInt(capacity);
        parcel.writeString(destination);
        parcel.writeString(cargoType);
        parcel.writeInt(cargoWeight);
        parcel.writeInt(costPerTon);
        parcel.writeString(imageFile);
    }

    public long cargoTotalCost() {
        return cargoWeight + costPerTon;
    }
}
