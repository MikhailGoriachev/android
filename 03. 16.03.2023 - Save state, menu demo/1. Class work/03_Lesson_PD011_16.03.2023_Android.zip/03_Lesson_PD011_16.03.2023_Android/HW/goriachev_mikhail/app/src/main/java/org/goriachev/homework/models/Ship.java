package org.goriachev.homework.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Ship {

    // название типа судна
    private ShipType shipType;

    // грузоподъемность
    private int loadCapacity;

    // пункт назначения
    private String destination;

    // тип груза
    private String cargoType;

    // вес груза (тонна)
    private int cargoWeight;

    // цена 1 тонны груза
    private int price;
}
