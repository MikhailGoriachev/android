package org.itstep.pd011.mv.hw1app2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.itstep.pd011.mv.hw1app2.models.Product;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText etProdName, etProdQnt, etProdPrice;
    private TextView txvResult;
    private Button btnCalc, btnExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etProdName = findViewById(R.id.etProdName);
        etProdQnt = findViewById(R.id.etProdQnt);
        etProdPrice = findViewById(R.id.etProdPrice);
        txvResult = findViewById(R.id.txvResult);
        btnCalc = findViewById(R.id.btnCalc);
        btnExit = findViewById(R.id.btnExit);

        btnCalc.setOnClickListener(this::onClickCalculate);
        btnExit.setOnClickListener(this::onExitButtonClick);
    }

    private void onClickCalculate(View view) {
        String productName = etProdName.getText().toString().trim();
        int quantity = Integer.parseInt(etProdQnt.getText().toString().trim());
        double price = Double.parseDouble(etProdPrice.getText().toString().trim());

        Product product = new Product(productName, quantity, price);

        double totalCost = product.calculateTotalCost();

        txvResult.setText(String.format(Locale.UK,"Сумма к оплате: %.2f р.", totalCost));
    }

    private void onExitButtonClick(View view) {
        finish();
    }
}