package org.itstep.pd011.step1303232;

import androidx.appcompat.app.AppCompatActivity;
import org.itstep.pd011.step1303232.models.Good;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText edtTitle,edtAmount, edtPrice;
    private TextView txvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txvResult = findViewById(R.id.txvResult);
        edtTitle = findViewById(R.id.edtTitle);
        edtAmount = findViewById(R.id.edtAmount);
        edtPrice = findViewById(R.id.edtPrice);
    }

    public void solveTask(View view) {

        Good good = new Good(
                edtTitle.getText().toString()
                , Integer.parseInt(edtAmount.getText().toString())
                , Integer.parseInt(edtPrice.getText().toString()));

        txvResult.setText(String.format(Locale.UK,"%d",good.sum()));
    } //solveTask
}