package org.itstep.pd011.step270323.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.helpers.Utils;
import org.itstep.pd011.step270323.tasks.Query01Task;
import org.itstep.pd011.step270323.tasks.Query02Task;
import org.itstep.pd011.step270323.tasks.Query03Task;
import org.itstep.pd011.step270323.tasks.Query04Task;
import org.itstep.pd011.step270323.tasks.Query05Task;
import org.itstep.pd011.step270323.tasks.Query06Task;
import org.itstep.pd011.step270323.tasks.Query07Task;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ResponseFragment extends Fragment {

    // элемент вывода принятых данных
    private ListView listView;
    private TextView textView;

    @SuppressLint("SimpleDateFormat")
    private static final DateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

    // обязательный конструктор
    public ResponseFragment() {
    }

    // связь с разметкой
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_response, container, false);
        listView = view.findViewById(R.id.responseList);
        textView = view.findViewById(R.id.responseTxt);

        return view;
    }

    @SuppressLint("SetTextI18n")
    public void setResponse(Integer position) {

        switch (position) {

            case 0:

                //Выбирает информацию о пациентах с фамилиями, начинающимися на заданную параметром последовательность букв
                String param = "А";
                new Query01Task(getContext(), listView, textView).execute(param);
                break;

            case 1:
                //Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше 2.3% (задавать параметром)
                double param01 = 90;
                new Query02Task(getContext(), listView, textView).execute(param01);
                break;

            case 2:
                //Выбирает информацию о приемах за некоторый период, заданный параметрами
                Date param02 = Utils.getDate();
                Date param03 = new Date();
                new Query03Task(getContext(), listView, textView).execute(param02, param03);
                break;

            case 3:
                //Выбирает информацию о докторах, специальность которых задана параметром
                String param04 = "Аллерголог";
                new Query04Task(getContext(), listView, textView).execute(param04);
                break;

            case 4:
                //Вычисляет размер заработной платы врача за каждый прием.
                new Query05Task(getContext(), listView, textView).execute();
                break;

            case 5:
                //Для каждой даты вычисляет максимальную стоимость приема
                new Query06Task(getContext(), listView, textView).execute();
                break;

            case 6:
                //Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема
                new Query07Task(getContext(), listView, textView).execute();
                break;
        }
    }

}