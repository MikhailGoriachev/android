package org.itstep.pd011.step250323.helpers;

import android.graphics.PorterDuff;
import android.text.Editable;
import android.text.TextWatcher;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.EditText;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.google.android.material.snackbar.Snackbar;


import java.io.InputStream;

public class Utils {

    public static Random random = new Random();

    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return random.ints(min, max).findFirst().getAsInt();
    }

    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * random.nextDouble();
    }

    public static void showError(EditText editText, String msg) {
        Snackbar snackbar = Snackbar.make(editText, msg, Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("OK", g -> {
        });
        snackbar.show();
    }

    // установка картинки
    public static void setViewImage(ImageView imageView, String fileName, Context context) {
        try (InputStream stream = context.getAssets().open(fileName)) {
            Drawable drawable = Drawable.createFromStream(stream, null);
            imageView.setImageDrawable(drawable);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public  static  String[] models = {
            "LG 43LM5772PLA",
            "Samsung UE43T5300AU","Philips 43PFS6825",
            "LG 50UQ90006LD","Samsung UE50AU7100U","TCL 50P617",
            "Sony XR-55X90J","LG 50QNED816QA",
            "Samsung QE55Q80AAU",
            "HISENSE 55E7HQ","Sony XR-75X95K","Samsung QE55QN85AAU",
            "LG OLED65G2 OLED","LG OLED65C2RLA","Sony XR-65A90J",
            "LG OLED55B2RLA","HAIER H65S9UG PRO","Sony XR-75Z9J",
            "Samsung QE75QN900AU","LG 65QNED966PA"
    };

}
