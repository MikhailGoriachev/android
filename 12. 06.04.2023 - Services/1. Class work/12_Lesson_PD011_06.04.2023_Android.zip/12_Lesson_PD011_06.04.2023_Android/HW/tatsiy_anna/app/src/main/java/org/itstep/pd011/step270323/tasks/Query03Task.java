package org.itstep.pd011.step270323.tasks;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.itstep.pd011.step270323.entities.Receipt;
import org.itstep.pd011.step270323.repositories.ReceptsDatabaseRepository;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

//Выбирает информацию о приемах за некоторый период, заданный параметрами

@SuppressLint("StaticFieldLeak")
public class Query03Task extends AsyncTask<Date,Void, List<Receipt>> {

    private final Context context;
    private final ListView listView;
    private final TextView textView;

    public Query03Task(Context context, ListView listView, TextView textView) {
        this.context = context;
        this.listView = listView;
        this.textView = textView;
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        textView.setText("Выбирает информацию о приемах за некоторый период, заданный параметрами");
    } // onPreExecute

    @Override
    protected List<Receipt> doInBackground(Date... dates) {

        List<Receipt> list = null;

        ReceptsDatabaseRepository repository = new ReceptsDatabaseRepository(context);
        repository.open();

        try {
            list = repository.selectByDateBetween(dates[0],dates[1]);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        repository.close();

        return list;
    }

    @Override
    protected void onPostExecute(List<Receipt> params) {
        super.onPostExecute(params);

        if(params != null) {
            listView.setAdapter(
                    new ArrayAdapter<>(
                            context,
                            android.R.layout.simple_list_item_1,
                            params)
            );
        }
    }
}
