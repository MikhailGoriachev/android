package ru.cherkas.home.home4.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

import ru.cherkas.home.home4.R;
import ru.cherkas.home.home4.models.Animal;

public class AnimalEditActivity extends AppCompatActivity {
    EditText edit_nickname, edit_age, edit_weight, edit_owner;
    Spinner spinner_breed;
    ImageView image;
    Animal animal;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_edit);
        spinner_breed = findViewById(R.id.spinner_edit_breed);
        edit_nickname = findViewById(R.id.edit_nickname);
        edit_age = findViewById(R.id.edit_age);
        edit_weight = findViewById(R.id.edit_weight);
        edit_owner = findViewById(R.id.edit_owner);
        image = findViewById(R.id.shoise_image);

        Bundle arg = getIntent().getExtras();
        if (arg != null){
            animal = arg.getParcelable(Animal.class.getSimpleName());

            // для спиннера
            ArrayList<String> breeds = arg.getStringArrayList("breeds");
            ArrayAdapter<String> adapter =
                    new ArrayAdapter(this, android.R.layout.simple_list_item_1, breeds);
            adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
            spinner_breed.setAdapter(adapter);
            // Выставляет текущее значение спиннера
            spinner_breed.setSelection(adapter.getPosition(animal.getBreed()));
            // обработчик спиннера
            spinner_breed.setOnItemSelectedListener(itemSelectedListener);

            edit_nickname.setText(animal.getNickname());
            edit_age.setText(String.format(Locale.UK, "%d", animal.getAge()));
            edit_weight.setText(String.format(Locale.UK,"%.3f", animal.getWeight()));
            edit_owner.setText(animal.getOwner());
            // фото
            setPhoto();
        }
    }

    // слушатель спиннера
    AdapterView.OnItemSelectedListener itemSelectedListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            String item = (String)adapterView.getItemAtPosition(i);
            animal.setBreed(item);
            animal.setPhoto(item + ".jpg");
            setPhoto();
        }
        @Override
        public void onNothingSelected(AdapterView<?> adapterView) { }
    };
    // фото
    public void setPhoto(){
        String filename = animal.getPhoto();
        try(InputStream inputStream = getApplicationContext().getAssets().open(filename)) {
            Drawable drawable = Drawable.createFromStream(inputStream, null);
            image.setImageDrawable(drawable);
        }
        catch (IOException e) {
            filename = "нет.jpg";
            try(InputStream inputStream = getApplicationContext().getAssets().open(filename)) {
                Drawable drawable = Drawable.createFromStream(inputStream, null);
                image.setImageDrawable(drawable);

            } catch (IOException e2) {
                throw new RuntimeException(e2);
            }
        }
    }
    // возраст добавить
    public void addAgeClick(View view){
        animal.setAge(animal.getAge() + 1);
        edit_age.setText(String.format(Locale.UK, "%d", animal.getAge()));
    }
    // удавить возраст
    public void minusAgeClick(View view){
        animal.setAge(animal.getAge() - 1);
        edit_age.setText(String.format(Locale.UK,"%d", animal.getAge()));
    }
    // добавить вес
    public void addWeightClick(View view){
        animal.setWeight(animal.getWeight() + 1);
        edit_weight.setText(String.format(Locale.UK,"%.3f", animal.getWeight()));
    }
    // убавить вес
    public void minusWeightClick(View view){
        animal.setWeight(animal.getWeight() - 1);
        edit_weight.setText(String.format(Locale.UK,"%.3f", animal.getWeight()));
    }
    public void backClick(View view){
        animal.setNickname(edit_nickname.getText().toString());
        animal.setWeight(Double.parseDouble(edit_weight.getText().toString()));
        animal.setAge(Integer.parseInt(edit_age.getText().toString()));
        animal.setOwner(edit_owner.getText().toString());
        image = findViewById(R.id.shoise_image);
        Intent intent = new Intent(this, AnimalActivity.class);
        intent.putExtra(Animal.class.getSimpleName(), animal);
        startActivity(intent);
    }


}