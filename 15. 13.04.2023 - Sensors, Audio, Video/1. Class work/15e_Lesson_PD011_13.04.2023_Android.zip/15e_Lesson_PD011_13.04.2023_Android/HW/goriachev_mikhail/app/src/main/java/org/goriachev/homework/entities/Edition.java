package org.goriachev.homework.entities;


import java.util.Date;

// Периодическое издание
public class Edition {

    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    // индекс издания по каталогу (строка из цифр и букв)
    private String index;

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    // вид издания (газета, журнал, альманах, каталог, …)
    private String publicationType;

    public String getPublicationType() {
        return publicationType;
    }

    public void setPublicationType(String publicationType) {
        this.publicationType = publicationType;
    }

    // наименование издания (название газеты, журнала, …)
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // цена 1 экземпляра (в руб.)
    private int price;

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    // дата начала подписки
    private Date subscribeDate;

    public Date getSubscribeDate() {
        return subscribeDate;
    }

    public void setSubscribeDate(Date subscribeDate) {
        this.subscribeDate = subscribeDate;
    }

    // длительность подписки (количество месяцев)
    private int duration;

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }


    public Edition() {
    }

    public Edition(long id, String index, String publicationType, String name, int price, Date subscribeDate, int duration) {
        this.id = id;
        this.index = index;
        this.publicationType = publicationType;
        this.name = name;
        this.price = price;
        this.subscribeDate = subscribeDate;
        this.duration = duration;
    }
}
