package org.itstep.pd011.step160323.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;

import org.itstep.pd011.step160323.helpers.Utils;
import org.itstep.pd011.step160323.MainActivity;
import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.models.Animal;
import org.itstep.pd011.step160323.models.Breed;

import java.util.Locale;

public class AnimalActivity extends AppCompatActivity {

    private EditText edtName, edtAge, edtWeight, edtSurname, edtOwner;
    private ImageView imageAnimal;
    private Animal animal, oldAnimal;
    private Breed selectBreed;

    private int newAge;
    private double newWeight;
    private Button saveButton;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch swtSpecialDiet, swtFreeKeeping;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);

        // получить параметр из вызывающей активности
        Intent intent = getIntent();
        animal = intent.getParcelableExtra(Animal.class.getCanonicalName());
        oldAnimal = animal.clone();

        edtName = findViewById(R.id.edtName);
        edtAge = findViewById(R.id.edtAge);
        edtWeight = findViewById(R.id.edtWeight);
        edtSurname = findViewById(R.id.edtSurname);
        edtOwner = findViewById(R.id.edtOwner);
        imageAnimal = findViewById(R.id.imageAnimal);
        swtSpecialDiet = findViewById(R.id.swt_animal_special_diet);
        swtFreeKeeping = findViewById(R.id.swt_animal_free_keeping);
        saveButton = findViewById(R.id.btnSave);

        // установка валидаторов (обработчиков ввода)
        setValidators();

        setParamsForEdit(animal.getBreed());

        newAge = animal.getAge();
        newWeight = animal.getWeight();

        findViewById(R.id.btnBack).setOnClickListener(v -> backClick());
        findViewById(R.id.btnClear).setOnClickListener(this::reset);
        saveButton.setOnClickListener(this::save);

        ((RadioGroup) findViewById(R.id.rgrBreed))
                .setOnCheckedChangeListener(this::onImageRBchanged);

        findViewById(R.id.btnIncAge).setOnClickListener(v -> edtAge.setText(String.format(Locale.UK, "%d", ++newAge)));
        findViewById(R.id.btnDecAge).setOnClickListener(v -> {

            if (newAge - 1 < 0)
                Utils.showError(edtAge, "Возраст не может быть отрицательным!");
            else
                edtAge.setText(String.format(Locale.UK, "%d", --newAge));
        });

        findViewById(R.id.btnIncWeight).setOnClickListener(view -> edtWeight.setText(String.format(Locale.UK, "%.2f", ++newWeight)));
        findViewById(R.id.btnDecWeight).setOnClickListener(view -> {

            if (newWeight - 1 < 0)
                Utils.showError(edtWeight, "Вес не может быть отрицательным!");
            else
                edtWeight.setText(String.format(Locale.UK, "%.2f", --newWeight));
        });
    }

    //обработка радио кнопок
    @SuppressLint("NonConstantResourceId")
    private void onImageRBchanged(RadioGroup group, int checkedId) {

        switch (checkedId) {
            case R.id.rbtBreed01:
                selectBreed = Breed.BADGER;
                break;

            case R.id.rbtBreed02:
                selectBreed = Breed.HUSKY;
                break;

            case R.id.rbtBreed03:
                selectBreed = Breed.MAINECOON;
                break;
        }

        Utils.setImage(selectBreed.getImage(), imageAnimal, getApplicationContext());
    }

    private void setParamsForEdit(String breed) {

        switch (breed) {
            case "Такса":
                selectBreed = Breed.BADGER;
                ((RadioButton) findViewById(R.id.rbtBreed01)).setChecked(true);
                break;
            case "Хаски":
                selectBreed = Breed.HUSKY;
                ((RadioButton) findViewById(R.id.rbtBreed02)).setChecked(true);
                break;
            default:
                selectBreed = Breed.MAINECOON;
                ((RadioButton) findViewById(R.id.rbtBreed03)).setChecked(true);
        }

        Utils.setImage(animal.getImage(), imageAnimal, getApplicationContext());
        edtName.setText(animal.getName());
        edtAge.setText(String.format(Locale.UK, "%d", animal.getAge()));
        edtWeight.setText(String.format(Locale.UK, "%.2f", animal.getWeight()));
        edtSurname.setText(animal.getSurname());
        edtOwner.setText(animal.getOwner());
        swtSpecialDiet.setChecked(animal.isSpecialDiet());
        swtFreeKeeping.setChecked(animal.isVoluntary());
    }

    // обработка клика по кнопке выхода из активности
    private void backClick() {
        Intent intent = new Intent();

        // данные, возвращаемые из активности
        intent.putExtra(Animal.class.getCanonicalName(), animal);

        // установить результат работы активности
        setResult(AnimalsOptimizedActivity.RESULT_OK, intent);

        // завершить активность
        finish();
    } // back

    //сохранить изменения
    private void save(View view) {
        try {
            animal.setImage(selectBreed.getImage());
            animal.setBreed(selectBreed.getTitle());
            animal.setName(edtName.getText().toString());
            animal.setAge(Integer.parseInt(edtAge.getText().toString()));
            animal.setWeight(Double.parseDouble(edtWeight.getText().toString()));
            animal.setSurname(edtSurname.getText().toString());
            animal.setOwner(edtOwner.getText().toString());
            animal.setSpecialDiet(swtSpecialDiet.isChecked());
            animal.setVoluntary(swtFreeKeeping.isChecked());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // сбросить поля ввода
    public void reset(View view) {
        animal = oldAnimal.clone();
        setParamsForEdit(animal.getBreed());
    }

    // установка валидаторов (обработчиков ввода)
    private void setValidators() {

        Utils.addTextChangedListener(edtName, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtName, (s) -> !s.isEmpty(),
                        "Поле клички должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtAge, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtAge, (s) -> {
                            if (s.isEmpty()) return false;
                            else return Integer.parseInt(s) >= 0;
                        },
                        "Поле возраста должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtWeight, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtWeight, (s) -> {
                            if (s.isEmpty()) return false;
                            else return Double.parseDouble(s) >= 0.1;
                        },
                        "Поле веса должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtSurname, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtSurname, (s) -> !s.isEmpty(),
                        "Поле фамилии должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtOwner, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtOwner, (s) -> !s.isEmpty(),
                        "Поле владельца должно быть заполнено",
                        getApplicationContext())));
    }

}