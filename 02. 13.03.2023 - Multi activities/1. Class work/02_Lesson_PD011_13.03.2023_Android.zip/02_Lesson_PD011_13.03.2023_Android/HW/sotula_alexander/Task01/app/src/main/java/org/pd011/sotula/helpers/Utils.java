package org.pd011.sotula.helpers;

import java.util.Random;

public class Utils {

    private static Random rand = new Random();

    // случайное вещественное число
    public static double getRandDbl(double min, double max) {
        return min + (max - min) * rand.nextDouble();
    }

}