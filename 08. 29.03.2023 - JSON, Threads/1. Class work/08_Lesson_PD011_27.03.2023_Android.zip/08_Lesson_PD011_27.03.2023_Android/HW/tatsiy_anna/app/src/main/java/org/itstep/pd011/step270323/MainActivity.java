package org.itstep.pd011.step270323;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import org.itstep.pd011.step270323.activities.DoctorsActivity;
import org.itstep.pd011.step270323.activities.PatientsActivity;
import org.itstep.pd011.step270323.activities.ReceptsActivity;
import org.itstep.pd011.step270323.activities.SpecialtiesActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // обработка выбора в меню по ид пункта
        switch (item.getItemId()) {
            case R.id.mniActivity01:
                startActivity(new Intent(this, DoctorsActivity.class));
                break;
            case R.id.mniActivity02:
                startActivity(new Intent(this, PatientsActivity.class));
                break;
            case R.id.mniActivity03:
                startActivity(new Intent(this, ReceptsActivity.class));
                break;
            case R.id.mniActivity04:
                startActivity(new Intent(this, SpecialtiesActivity.class));
                break;

            case R.id.mniExit:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected
}