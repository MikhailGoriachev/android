package org.itstep.pd011.step270323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.models.Doctor;
import org.itstep.pd011.step270323.models.Specialtie;
import org.itstep.pd011.step270323.repositories.DoctorsDatabaseRepository;
import org.itstep.pd011.step270323.repositories.SpecialtiesDatabaseRepository;

public class SpecialtiesActivity extends AppCompatActivity {

    // элемент отображения списка и его адаптер
    private ListView specialtiesList;
    ArrayAdapter<Specialtie> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specialties);

        specialtiesList = findViewById(R.id.listSpecialties);
    }

    // открытие БД
    @Override
    public void onResume() {
        super.onResume();

        // открыть базу данных
        SpecialtiesDatabaseRepository repository = new SpecialtiesDatabaseRepository(this);
        repository.open();

        // вывести в ListView при помощи адаптера
        arrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                repository.getSpecialties());

        specialtiesList.setAdapter(arrayAdapter);
        repository.close();

    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.back_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected
}