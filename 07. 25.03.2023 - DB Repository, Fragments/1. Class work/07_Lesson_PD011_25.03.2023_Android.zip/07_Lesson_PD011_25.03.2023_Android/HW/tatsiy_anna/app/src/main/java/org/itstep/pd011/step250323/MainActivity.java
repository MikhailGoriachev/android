package org.itstep.pd011.step250323;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import org.itstep.pd011.step250323.activities.TelevisionGridActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnActivityTask01).setOnClickListener(v-> startActivity(new Intent(this, TelevisionGridActivity.class)));
        //findViewById(R.id.btnActivityTask02).setOnClickListener(v->startActivity(new Intent(this, ShipsOptimizedActivity.class)));
    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // обработка выбора в меню по ид пункта
        switch (item.getItemId()) {
            case R.id.mniActivity01:
                startActivity(new Intent(this, TelevisionGridActivity.class));
                break;
            case R.id.mniActivity02:
                //startActivity(new Intent(this, ShipsOptimizedActivity.class));
                break;
            case R.id.mniExit:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected

    // обработчик клика по кнопке "Выход"
    public void exitClick(View view) {
        // завершает активность, но не приложение
        finish();
    } // exitClick
}