package com.step.home_work.converters;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonSerializer;
import com.step.home_work.models.entities.Appointment;

// Чтобы можно использовать 1 класс Helper'a
//Я использую это в JsonHelper
public abstract class BaseConverter<T> implements JsonSerializer<T>, JsonDeserializer<T>  {
}
