package org.itstep.pd011.step160323.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.helpers.Utils;
import org.itstep.pd011.step160323.models.Ship;

import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

public class ShipsOptimizedAdapter extends ArrayAdapter<Ship> {

    private final LayoutInflater inflater;     // загрузчик разметки элемента - из контекста создания - активность или фрагмент
    private final int            layout;       // ид разметки элемента списка
    private final List<Ship> ships; // коллекция данных
    private final Consumer<Integer> consumer;

    // для создания адаптера в точке вызова
    public ShipsOptimizedAdapter(@NonNull Context context, int resource, @NonNull List<Ship> ships, Consumer<Integer> consumer ) {
        super(context, resource, ships);

        this.layout = resource;
        this.inflater = LayoutInflater.from(context);
        this.ships = ships;
        this.consumer = consumer;
    }

    public View getView(int position, View convertView, ViewGroup parent){

        // 2й вариант оптимизации - использование ViewHolder - внутренний класс
        final ShipsOptimizedAdapter.ViewHolder viewHolder;

        if (convertView == null){
            convertView = inflater.inflate(this.layout, parent, false);
            viewHolder = new ShipsOptimizedAdapter.ViewHolder(convertView, position);

            // сохранить все ссылки на элементы разметки
            // в поле tag convertView, тип tag - Object
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ShipsOptimizedAdapter.ViewHolder) convertView.getTag();
            viewHolder.position = position;
        } // if

        Ship ship = ships.get(position);

        // вывести поля объекта в элементы интерфейса
        // поместить данные из очередного элемента коллекции в элементы
        // отображения
        viewHolder.imgItem.setImageResource(ship.getImage());
        viewHolder.txvType.setText(ship.getType());
        viewHolder.txvWeight.setText(String.format(Locale.UK,"Вес: %d т.",ship.getWeight()));
        viewHolder.txvCostOf1Ton.setText(String.format(Locale.UK,"Стоимость 1 т: %d $",ship.getCostOf1Ton()));
        viewHolder.txvTotalCost.setText(String.format(Locale.UK,"Общая стоимость: %d $",ship.totalCost()));

        // вернуть сформированное представление элемента списка
        return convertView;
    }

    // класс ViewHolder - хранит ссылки на элементы разметки
    // исключает повторные операции поиска элементов в разметке
    private class ViewHolder{

        // элементы интерфейса из разметки элемента
        final ImageView imgItem;

        final TextView txvType;
        final TextView txvWeight;
        final TextView txvCostOf1Ton;
        final TextView txvTotalCost;

        final Button btnIncWeight;
        final Button btnDecWeight;
        final Button btnIncCostOf1Ton;
        final Button btnDecCostOf1Ton;

        final LinearLayout llTextViews;
        private int position;

        public ViewHolder(View view, int position){

            // связать разметку и ссылки на элементы отображения
            imgItem = view.findViewById(R.id.imgItem);
            llTextViews = view.findViewById(R.id.llTextViewsShip);

            txvType = view.findViewById(R.id.txvType);
            txvWeight = view.findViewById(R.id.txvWeight);
            txvCostOf1Ton = view.findViewById(R.id.txvCostOf1Ton);
            txvTotalCost = view.findViewById(R.id.txvTotalCost);

            btnIncWeight = view.findViewById(R.id.btnIncWeight);
            btnDecWeight = view.findViewById(R.id.btnDecWeight);
            btnIncCostOf1Ton = view.findViewById(R.id.btnIncCostOf1Ton);
            btnDecCostOf1Ton = view.findViewById(R.id.btnDecCostOf1Ton);

            // позиция элемента в коллекции
            this.position = position;

            // назначаем обработчика клика по элементам разметки, т.к. клик в
            // основной активности блокируется слушателями кнопками
            llTextViews.setOnClickListener(v->onClickListner(v, this.position));
            imgItem.setOnClickListener(v->onClickListner(v, this.position));

        }
    }

    private void onClickListner(View view, int position) {
        this.consumer.accept(position);
    }

    public void myNotifyDataSetChanged() { notifyDataSetChanged();}
}
