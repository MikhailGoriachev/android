package org.itstep.pd011.step160323.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import org.itstep.pd011.step160323.helpers.Utils;
import org.itstep.pd011.step160323.MainActivity;
import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.models.Ship;
import org.itstep.pd011.step160323.models.TypeShip;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public class ShipsActivity extends AppCompatActivity {

    private EditText edtCapacity, edtDestination, edtWeight, edtCostOf1Ton;
    private ImageView imageShip;
    private Ship ship, oldShip;

    private TypeShip selectType;
    private double newWeight;
    private Button saveButton;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch swtAnchorage, swtRefueling, swtPilot;
    private TextView txtTotalCost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ships);

        // получить параметр из вызывающей активности
        Intent intent = getIntent();
        ship = intent.getParcelableExtra(Ship.class.getCanonicalName());

        edtCapacity = findViewById(R.id.edtCapacity);
        edtDestination = findViewById(R.id.edtDestination);
        edtWeight = findViewById(R.id.edtWeight);
        edtCostOf1Ton = findViewById(R.id.edtCostOf1Ton);

        txtTotalCost = findViewById(R.id.txtTotalCost);
        txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));

        edtCapacity.setText(String.format(Locale.UK, "%d", ship.getCapacity()));
        edtDestination.setText(ship.getDestination());
        edtWeight.setText(String.format(Locale.UK, "%d", ship.getWeight()));
        edtCostOf1Ton.setText(String.format(Locale.UK, "%d", ship.getCostOf1Ton()));

        findViewById(R.id.btnBack).setOnClickListener(v -> backClick());

        edtCostOf1Ton.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setCostOf1Ton(Integer.parseInt(edtCostOf1Ton.getText().toString()));
                        txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));
                    } catch (Exception e) {
                        Utils.showError(edtCostOf1Ton, e.getMessage());
                    }
                }
            }
        });

        edtWeight.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setWeight(Integer.parseInt(edtWeight.getText().toString()));
                        txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));
                    } catch (Exception e) {
                        Utils.showError(edtWeight, e.getMessage());
                    }
                }
            }
        });



        edtDestination.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setDestination(edtDestination.getText().toString());
                    } catch (Exception e) {
                        Utils.showError(edtDestination, e.getMessage());
                    }
                }
            }
        });

        edtCapacity.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    try {
                        ship.setCapacity(Integer.parseInt(edtCapacity.getText().toString()));
                    } catch (Exception e) {
                        Utils.showError(edtCapacity, e.getMessage());
                    }
                }
            }
        });



        findViewById(R.id.btnIncWeight).setOnClickListener(view -> {

            try {
                ship.setWeight(ship.getWeight() + 20);
                txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));
                edtWeight.setText(String.format(Locale.UK, "%d", ship.getWeight()));
            } catch (Exception e) {
                Utils.showError(edtWeight, e.getMessage());
            }

        });

        findViewById(R.id.btnDecWeight).setOnClickListener(view -> {

            try {
                ship.setWeight(ship.getWeight() - 20);
                txtTotalCost.setText(String.format(Locale.UK,"Стоимость груза: %d руб.",ship.totalCost()));
                edtWeight.setText(String.format(Locale.UK, "%d", ship.getWeight()));
            } catch (Exception e) {
                Utils.showError(edtWeight, e.getMessage());
            }
        });
    }


    // обработка клика по кнопке выхода из активности
    private void backClick() {

        Intent intent = new Intent();

        // данные, возвращаемые из активности
        intent.putExtra(Ship.class.getCanonicalName(), ship);

        // установить результат работы активности
        setResult(MainActivity.RESULT_OK, intent);

        // завершить активность
        finish();
    } // back


}