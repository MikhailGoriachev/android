package org.itstep.pd011.step270323.helpers;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonSerializer;

//класс оболочка для шаблонного класса JsonHelper (так как я не могу написать требование, чтоб тип V implements JsonSerializer<T>, JsonDeserializer<T>)
public abstract class Shell<T> implements JsonSerializer<T>, JsonDeserializer<T> {
}
