package org.goriachev.homework.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.goriachev.homework.R;
import org.goriachev.homework.models.Animal;
import org.goriachev.homework.utils.Utils;

public class AnimalEditActivity extends AppCompatActivity {

    // животное
    private Animal animal;

    // элемент для вывода изображения животного
    ImageView ivwAnimal;

    // поля для вывода информации о животном
    TextView txvAnimalName, txvAnimalBreed, txvAnimalAge, txvAnimalWeight, txvAnimalOwner;


    // обработчик события создания активности
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_edit);

        animal = getIntent().getParcelableExtra(Animal.class.getCanonicalName());

        // поиск элементов о животном
        txvAnimalName = findViewById(R.id.txv_animal_name);
        txvAnimalBreed = findViewById(R.id.txv_animal_breed);
        txvAnimalAge = findViewById(R.id.txv_animal_age);
        txvAnimalWeight = findViewById(R.id.txv_animal_weight);
        txvAnimalOwner = findViewById(R.id.txv_animal_owner);

        onUpdateAnimal();
    }

    // обработка события изменения животного
    private void onUpdateAnimal() {
        if (animal == null)
            return;

        txvAnimalName.setText(animal.getName());
        txvAnimalBreed.setText(animal.getBreed());
        txvAnimalAge.setText(Utils.intFormat(animal.getAge()));
        txvAnimalWeight.setText(Utils.doubleFormat(animal.getWeight()));
        txvAnimalOwner.setText(animal.getOwner());
    }

    // завершение активности
    public void finish(View view) {
        finish();
    }
}