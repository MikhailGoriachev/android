package org.itstep.pd011.task02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.itstep.pd011.task02.models.Product;
import org.itstep.pd011.task02.models.Purchase;

import java.util.Locale;

/*
 * Разработайте приложение с одной активностью для ввода данных о покупке.
 * Описание товара должно быть реализовано отдельным классом.
 * Вводите наименование товара, количество, цену единицы товара.
 * Рассчитайте и выведите сумму к оплате:
 *
 *     Сумма_к_оплате = цена_единицы * количество_товара.
 *
 * Используйте кнопки Button, элементы ввода EditText, элементы отображения
 * */

public class MainActivity extends AppCompatActivity {
    // покупка товара
    Purchase purchase;

    // элементы интерфейса
    Button btnCalc, btnClear, btnQuit;
    EditText edtProductName, edtProductPrice, edtProductQuantity;
    TextView txvAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // создаем объект для работы активности
        purchase = new Purchase();

        // элементы редактирования
        edtProductName = findViewById(R.id.edtProductName);
        edtProductPrice = findViewById(R.id.edtProductPrice);
        edtProductQuantity = findViewById(R.id.edtProductQuantity);

        // настройка слушателей события "Изменение текста в редакторе"
        // при изменении любого редактора будем очищать поле выводоа
        // стоимости покупки
        edtProductName.addTextChangedListener(watcher);
        edtProductPrice.addTextChangedListener(watcher);
        edtProductQuantity.addTextChangedListener(watcher);

        // элемент вывода рассчитанной цены товара
        txvAmount = findViewById(R.id.txvAmount);

        // управляющие кнопки
        btnCalc = findViewById(R.id.btnCalc);
        btnClear = findViewById(R.id.btnClear);
        btnQuit = findViewById(R.id.btnQuit);

        // назначение обработчиков клика по кнопкам
        btnCalc.setOnClickListener(v -> calcAmount());
        btnClear.setOnClickListener(v -> clearFields());
        btnQuit.setOnClickListener(v -> finish());
    } // onCreate

    // обработчик изменения текста - при изменении вводам
	// анонимный класс от интефейса TextWatcher
    private final TextWatcher watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

        // чистим поле вывода результата расчета, при изменении текста в поле ввода
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // вывод строки из ресурса
            txvAmount.setText(R.string.str_empty_amount);
        } // onTextChanged

        @Override
        public void afterTextChanged(Editable editable) { }
    };


    // вычисление стоимости покупки и вывод результата
    private void calcAmount() {
        try {
            // получить ссылку на товар - для сокращения кода
            Product product = purchase.getGoods();

            // прочитать наименование товара и цену единицы товара
            purchase.getGoods().setName(edtProductName.getText().toString());
            purchase.getGoods().setPrice(Integer.parseInt(edtProductPrice.getText().toString()));

            // установить количество товара в покупке
            purchase.setQuantity(Integer.parseInt(edtProductQuantity.getText().toString()));

            // вычисление стоимости покупки и вывод вычисленной стоимости
            int amount = purchase.calcAmount();
            txvAmount.setText(String.format(Locale.UK, "%d.00 руб.", amount));
        } catch (Exception ex) {
            // формирование и вывод сообщений об ошибке
            Toast toast = Toast.makeText(this,
                    "Ошибка, система говорит:\n" + ex.getMessage(), Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);

            toast.show();
        } // try-catсh
    } // calcAmount


    // очистка полей ввода и поля вывода результата
    private void clearFields() {
        edtProductName.setText("");
        edtProductPrice.setText("");
        edtProductQuantity.setText("");

        txvAmount.setText(R.string.str_empty_amount);
    } // clearFields
} // class MainActivity