package org.itstep.pd011.step270323.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;
import org.itstep.pd011.step270323.R;
import org.itstep.pd011.step270323.adapters.ReceptsAdapter;
import org.itstep.pd011.step270323.converters.ReceiptConverter;
import org.itstep.pd011.step270323.helpers.JsonHelper;
import org.itstep.pd011.step270323.entities.Receipt;
import org.itstep.pd011.step270323.repositories.ReceptsDatabaseRepository;
import java.text.ParseException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class ReceptsActivity extends AppCompatActivity {

    // элемент отображения списка и его адаптер
    private ListView receiptsList;
    private ReceptsAdapter adapter;
    private ReceptsDatabaseRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recepts);

        receiptsList = findViewById(R.id.listRecepts);
        repository = new ReceptsDatabaseRepository(this);
    }

    // открытие БД
    @Override
    public void onResume() {
        super.onResume();

        // открыть базу данных
        repository.open();

        // вывести в ListView при помощи адаптера
        try {
            adapter = new ReceptsAdapter(
                    this,
                    R.layout.recepts_item_action,
                    repository.getReceipts(), repository);

        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        receiptsList.setAdapter(adapter);
        repository.close();

    }

    // region Работа с главным меню активности
    // обработчик события создани меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.tables_menu, menu);
        return super.onCreateOptionsMenu(menu);
    } // onCreateOptionsMenu

    // обработчик события выбора в меню
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mniAdd:
                repository.insert(Receipt.generate());
                onResume();
                break;

            case R.id.mniRecover:
                    // загрузить коллекцию из JSON-файла
                try {

                    LoadTask loadTask = new LoadTask();
                    loadTask.execute();

                    List<Receipt> result = loadTask.get(2000, TimeUnit.MILLISECONDS);

                    if (result != null) {
                        adapter = new ReceptsAdapter(
                                ReceptsActivity.this,
                                R.layout.recepts_item_action,
                                result, repository);

                        receiptsList.setAdapter(adapter);
                    }

                } catch (ExecutionException | InterruptedException | TimeoutException e) {
                    throw new RuntimeException(e);
                }
                break;

            case R.id.mniBack:
                finish();
                break;
        } // switch
        return super.onOptionsItemSelected(item);
    } // onOptionsItemSelected

    private class LoadTask extends AsyncTask<Void, Void, List<Receipt>> {

        @Override
        protected List<Receipt> doInBackground(Void... params){

            // чтение коллекции из JSON-файла
            return new JsonHelper<Receipt>().importFromJSON(ReceptsActivity.this, "receipts.json", new ReceiptConverter(), Receipt.class, Receipt[].class);
        }

        // вывод финишного сообщения
        @Override
        protected void onPostExecute(List<Receipt> result){
            super.onPostExecute(result);

            Toast.makeText(ReceptsActivity.this,(result != null) ? "Данные прочитаны из JSON" : "Не удалось прочитать данные" , Toast.LENGTH_LONG).show();
        }

    }
}