package org.itstep.pd011.task02.models;

import java.security.InvalidParameterException;

// класс, описывющий покупку некоторого количества товара
public class Purchase {
    // закупаемый товар
    private Product product;

    // количество закупаемого товара
    private int quantity;

    //region конструкторы
    public Purchase() { this(new Product(), 1); } // Purchase

    public Purchase(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    } // Purchase
    //endregion

    // ------------------------------------------------------------
    //region геттеры и сеттеры
    public Product getGoods() { return product; }
    public void setGoods(Product product) {
        this.product = product;
    } // setGoods

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) {
        if (quantity <= 0)
            throw new InvalidParameterException("Недопустимое количество товара");

        this.quantity = quantity;
    } // setQuantity
    //endregion

    // ------------------------------------------------------------
    // вычисление суммы к оплате
    // Сумма_к_оплате = цена_единицы * количество_товара
    public int calcAmount() {
        return product.getPrice() * quantity;
    } // calcAmount
} // class Purchase
