package org.itstep.pd011.step270323.repositories;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import org.itstep.pd011.step270323.helpers.DatabaseHelper;
import org.itstep.pd011.step270323.helpers.Utils;
import org.itstep.pd011.step270323.entities.Receipt;
import org.itstep.pd011.step270323.entities.Report;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReceptsDatabaseRepository {

    // поля для работы с БД
    private final DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    // название таблицы в БД
    static final String TABLE = "Receipts";

    // названия столбцов
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_PRICE = "price";
    public static final String COLUMN_ID_PATIENT = "id_patient";
    public static final String COLUMN_ID_DOCTOR = "id_doctor";

    String[] columns = new String[] {COLUMN_ID, COLUMN_DATE, COLUMN_PRICE, COLUMN_ID_PATIENT, COLUMN_ID_DOCTOR};

    public  ReceptsDatabaseRepository(Context context){
        dbHelper = new DatabaseHelper(context.getApplicationContext());
        dbHelper.create_db();
    } // DatabaseRepository

    public ReceptsDatabaseRepository open(){
        database = dbHelper.open();
        return this;
    } // open

    public void close(){ dbHelper.close(); }

    public List<Receipt> getReceipts() throws ParseException {

        return getFromCursor(
                database.query(
                        TABLE, columns, null, null, null,
                        null, null));

    } // getAllEntries

    //Выбирает информацию о приемах за некоторый период, заданный параметрами
    public List<Receipt> selectByDateBetween(Date d1, Date d2) throws ParseException {
        return getFromCursor(
                database.rawQuery(String.format(Locale.UK,
                        "SELECT * " +
                        "  FROM Receipts " +
                        "  where date between '%s' and '%s' ", Utils.formatter.format(d1) , Utils.formatter.format(d2)) ,null)
        );
    }

    //Вычисляет размер заработной платы врача за каждый прием.
    // Включает поля Фамилия врача, Имя врача, Отчество врача,
    // Специальность врача, Стоимость приема, Зарплата.
    // Сортировка по полю Специальность врача
    @SuppressLint("Range")
    public List<Report> generateReport(){

        Cursor cursor = database.rawQuery(
                "SELECT  " +
                        "Receipts._id as _id, " +
                        "    Doctors.surname as surname, " +
                        "    Doctors.name as dname, " +
                        "    Doctors.patronymic as patronymic, " +
                        "    Specialties.name as sname, " +
                        "    Receipts.price as price, " +
                        "    (Doctors.tax - 13)/100*Receipts.price as profit " +
                        "  FROM Receipts join (Doctors join Specialties on Doctors.id_specialtie = Specialties._id) on Receipts.id_doctor = Doctors._id " +
                        "  Order by Specialties.name " ,null);

        ArrayList<Report> reports = new ArrayList<>();

        if(cursor.moveToFirst()){
            do{
                reports.add(new Report(
                        cursor.getLong(cursor.getColumnIndex("_id")),
                        cursor.getString(cursor.getColumnIndex("surname")),
                        cursor.getString(cursor.getColumnIndex("dname")),
                        cursor.getString(cursor.getColumnIndex("patronymic")),
                        cursor.getString(cursor.getColumnIndex("sname")),
                        cursor.getInt(cursor.getColumnIndex("price")),
                        cursor.getDouble(cursor.getColumnIndex("profit"))));
            } while (cursor.moveToNext());
        } // if

        cursor.close();
        return reports;
    }

    //Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
    public Cursor maxPriceGroupByDate(){
        return database.rawQuery(
                "SELECT " +
                        "Receipts._id as _id,"+
                "    Receipts.date as date," +
                "    MAX(Receipts.price) as max" +
                "  FROM Receipts" +
                "  group by Receipts.date",null);
    }

    //Выполняет группировку по полю Специальность.
    // Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема
    public Cursor avgTaxGroupBySpecialty(){
        return database.rawQuery(
                "SELECT " +
                "       Specialties._id as _id, " +
                "       Specialties.name as name, " +
                "       AVG(tax) as avg " +
                "  FROM Doctors join Specialties on Doctors.id_specialtie = Specialties._id " +
                "  group by Specialties._id, Specialties.name",null);
    }

    // метод паттерна Репозиторий
    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, TABLE);
    }

    // возвращает коллекцию из таблицы БД
    @SuppressLint("Range")
    private List<Receipt> getFromCursor(Cursor cursor) throws ParseException {
        ArrayList<Receipt> receipts = new ArrayList<>();
        if(cursor.moveToFirst()){
            do{
                // добавление в коллекцию объекта Patient
                receipts.add(getReceiptFromCursor(cursor));
            } while (cursor.moveToNext());
        } // if
        cursor.close();
        return receipts;
    }

    // получить 1 запись по id
    @SuppressLint("Range")
    public Receipt getReceipt(long id) throws ParseException {
        Receipt receipt = null;

        String query = String.format(
                "SELECT * FROM %s WHERE %s=?",
                TABLE,
                COLUMN_ID);

        Cursor cursor = database.rawQuery(query, new String[]{String.valueOf(id)});

        // чтение данных, если они получены
        if(cursor.moveToFirst()){
            receipt = getReceiptFromCursor(cursor);
        } // if

        cursor.close();
        return receipt;
    }

    // метод - оболочка для запроса insert
    public long insert(Receipt receipt){
        return database.insert(TABLE, null, getContentValues(receipt));
    } // insert

    // метод - оболочка для запроса delete
    public long delete(long id){
        return database.delete(TABLE, "_id = ?", new String[]{String.valueOf(id)});
    } // delete

    // метод - оболочка для запроса update
    public long update(Receipt receipt){
        return database.update(TABLE, getContentValues(receipt), COLUMN_ID + "=" + receipt.getId(), null);
    } // update

    private ContentValues getContentValues(Receipt receipt){

        ContentValues cv = new ContentValues();

        cv.put(COLUMN_DATE, Utils.formatter.format(receipt.getDate()));
        cv.put(COLUMN_PRICE, receipt.getPrice());
        cv.put(COLUMN_ID_PATIENT, receipt.getId_patient());
        cv.put(COLUMN_ID_DOCTOR, receipt.getId_doctor());

        return cv;
    }

    @SuppressLint("Range")
    private Receipt getReceiptFromCursor(Cursor cursor) throws ParseException {

        return new Receipt(
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID)),
                Utils.formatter.parse(cursor.getString(cursor.getColumnIndex(COLUMN_DATE))),
                cursor.getInt(cursor.getColumnIndex(COLUMN_PRICE)),
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID_PATIENT)),
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID_DOCTOR)));
    }
}
