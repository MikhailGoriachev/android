package org.itstep.pd011.step270323.repositories;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import org.itstep.pd011.step270323.helpers.DatabaseHelper;
import org.itstep.pd011.step270323.entities.Doctor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DoctorsDatabaseRepository {

    // поля для работы с БД
    private final DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    // название таблицы в БД
    static final String TABLE = "Doctors";

    // названия столбцов
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_SURNAME = "surname";
    public static final String COLUMN_PATRONYMIC = "patronymic";
    public static final String COLUMN_ID_SPECIALTIE = "id_specialtie";
    public static final String COLUMN_TAX = "tax";

    private static final String[] columns = new String[] {COLUMN_ID, COLUMN_NAME, COLUMN_SURNAME, COLUMN_PATRONYMIC, COLUMN_ID_SPECIALTIE, COLUMN_TAX};

    public  DoctorsDatabaseRepository(Context context){
        dbHelper = new DatabaseHelper(context.getApplicationContext());
        dbHelper.create_db();
    } // DatabaseRepository

    public DoctorsDatabaseRepository open(){
        database = dbHelper.open();
        return this;
    } // open

    public void close(){ dbHelper.close(); }

    // метод паттерна Репозиторий
    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, TABLE);
    }

    private List<Doctor> getFromCursor(Cursor cursor){
        ArrayList<Doctor> doctors = new ArrayList<>();
        if(cursor.moveToFirst()){
            do{
                // добавление в коллекцию объекта Doctor
                doctors.add(getDoctorFromCursor(cursor));
            } while (cursor.moveToNext());
        } // if
        cursor.close();
        return doctors;
    }

    @SuppressLint("Range")
    public List<Doctor> getDoctors(){
        return getFromCursor(
                database.query(
                        TABLE, columns, null, null, null,
                        null, null)
        );
    }

    //Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше 2.3% (задавать параметром)
    public List<Doctor> selectDoctorsByInterest(double interest){
        return getFromCursor(
                database.rawQuery(String.format(Locale.UK,"SELECT * FROM Doctors WHERE tax > %f", interest) ,null)
        );
    }

    //Выбирает информацию о докторах, специальность которых задана параметром
    public List<Doctor> selectDoctorsBySpecialty(String specialty){
        return getFromCursor(
                database.rawQuery(String.format(Locale.UK,
                        "SELECT * " +
                        "  FROM Doctors join Specialties on Doctors.id_specialtie = Specialties._id " +
                        "  where Specialties.name = '%s' ", specialty) ,null)
        );
    }

    // получить одного доктора по id
    @SuppressLint("Range")
    public Doctor getDoctor(long id){
        Doctor doctor = null;

        String query = String.format(
                "SELECT * FROM %s WHERE %s=?",
                TABLE,
                COLUMN_ID);

        Cursor cursor = database.rawQuery(query, new String[]{String.valueOf(id)});

        // чтение данных, если они получены
        if(cursor.moveToFirst()){
            doctor = getDoctorFromCursor(cursor);
        } // if

        cursor.close();
        return doctor;
    }

    // метод - оболочка для запроса insert
    public long insert(Doctor doctor){
        return database.insert(TABLE, null, getContentValues(doctor));
    } // insert

    // метод - оболочка для запроса update
    public long update(Doctor doctor){
        return database.update(TABLE, getContentValues(doctor), COLUMN_ID + "=" + doctor.getId(), null);
    } // update

    private ContentValues getContentValues(Doctor doctor){

        ContentValues cv = new ContentValues();

        cv.put(COLUMN_SURNAME, doctor.getSurname());
        cv.put(COLUMN_NAME, doctor.getName());
        cv.put(COLUMN_PATRONYMIC, doctor.getPatronymic());
        cv.put(COLUMN_ID_SPECIALTIE, doctor.getId_specialtie());
        cv.put(COLUMN_TAX,doctor.getTax());

        return cv;
    }

    @SuppressLint("Range")
    private Doctor getDoctorFromCursor(Cursor cursor){

        return new Doctor(
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(COLUMN_SURNAME)),
                cursor.getString(cursor.getColumnIndex(COLUMN_NAME)),
                cursor.getString(cursor.getColumnIndex(COLUMN_PATRONYMIC)),
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID_SPECIALTIE)),
                cursor.getDouble(cursor.getColumnIndex(COLUMN_TAX)));
    }
}
