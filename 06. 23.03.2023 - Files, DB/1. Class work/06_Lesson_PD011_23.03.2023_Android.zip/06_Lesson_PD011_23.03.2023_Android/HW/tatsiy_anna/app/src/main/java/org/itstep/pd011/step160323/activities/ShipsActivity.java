package org.itstep.pd011.step160323.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import org.itstep.pd011.step160323.helpers.Utils;
import org.itstep.pd011.step160323.MainActivity;
import org.itstep.pd011.step160323.R;
import org.itstep.pd011.step160323.models.Ship;
import org.itstep.pd011.step160323.models.TypeShip;

import java.util.Locale;

public class ShipsActivity extends AppCompatActivity {

    private EditText edtCapacity, edtDestination, edtWeight, edtCostOf1Ton;
    private ImageView imageShip;
    private Ship ship, oldShip;

    private TypeShip selectType;
    private int newWeight;
    private Button saveButton;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch swtAnchorage, swtRefueling, swtPilot;
    private TextView txtTotalCost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ships);

        // получить параметр из вызывающей активности
        Intent intent = getIntent();
        ship = intent.getParcelableExtra(Ship.class.getCanonicalName());
        oldShip = ship.clone();
        newWeight = ship.getWeight();

        txtTotalCost = findViewById(R.id.txtTotalCost);

        edtWeight = findViewById(R.id.edtWeight);
        edtCapacity = findViewById(R.id.edtCapacity);
        edtDestination = findViewById(R.id.edtDestination);
        edtCostOf1Ton = findViewById(R.id.edtCostOf1Ton);

        imageShip = findViewById(R.id.imageShip);

        swtAnchorage = findViewById(R.id.swt_anchorage);
        swtRefueling = findViewById(R.id.swt_refueling);
        swtPilot = findViewById(R.id.swt_pilot);

        saveButton = findViewById(R.id.btnSave);

        // установка валидаторов (обработчиков ввода)
        setValidators();
        setParamsForEdit(ship.getType());

        findViewById(R.id.btnBack).setOnClickListener(v -> backClick());
        findViewById(R.id.btnClear).setOnClickListener(this::reset);
        saveButton.setOnClickListener(this::save);

        ((RadioGroup) findViewById(R.id.rgrType))
                .setOnCheckedChangeListener(this::onImageRBchanged);


        findViewById(R.id.btnIncWeight).setOnClickListener(view -> edtWeight.setText(String.format(Locale.UK, "%d",  newWeight +=20)));
        findViewById(R.id.btnDecWeight).setOnClickListener(view -> {

            if (newWeight < 20)
                Utils.showError(edtWeight, "Вес не может быть отрицательным!");
            else
                edtWeight.setText(String.format(Locale.UK, "%d", newWeight-=20));
        });
    }

    //обработка радио кнопок
    @SuppressLint("NonConstantResourceId")
    private void onImageRBchanged(RadioGroup group, int checkedId) {

        switch (checkedId) {
            case R.id.rbtType01:
                selectType = TypeShip.BULK;
                break;

            case R.id.rbtType02:
                selectType = TypeShip.CONTAINER;
                break;

            case R.id.rbtType03:
                selectType = TypeShip.CARGO;
                break;

        }

        Utils.setImage(selectType.getImage(), imageShip, getApplicationContext());
    }


    //сохранить изменения
    private void save(View view) {
        try {
            ship.setImage(selectType.getImage());
            ship.setType(selectType.getTitle());

            ship.setCapacity(Integer.parseInt(edtCapacity.getText().toString()));
            ship.setDestination(edtDestination.getText().toString());
            ship.setCostOf1Ton(Integer.parseInt(edtCostOf1Ton.getText().toString()));
            ship.setWeight(Integer.parseInt(edtWeight.getText().toString()));

            ship.setAnchorage(swtAnchorage.isChecked());
            ship.setRefueling(swtRefueling.isChecked());
            ship.setPilot(swtPilot.isChecked());

            txtTotalCost.setText(String.format(Locale.UK, "Стоимость груза: %d руб.", ship.totalCost()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setParamsForEdit(String type) {

        switch (type) {
            case "Балкер":
                selectType = TypeShip.BULK;
                ((RadioButton) findViewById(R.id.rbtType01)).setChecked(true);
                break;

            case "Контейнеровоз":
                selectType = TypeShip.CONTAINER;
                ((RadioButton) findViewById(R.id.rbtType02)).setChecked(true);
                break;

            case "Сухогруз":
                selectType = TypeShip.CARGO;
                ((RadioButton) findViewById(R.id.rbtType03)).setChecked(true);
                break;
        }

        Utils.setImage(ship.getImage(), imageShip, getApplicationContext());
        edtWeight.setText(String.format(Locale.UK, "%d", ship.getWeight()));
        edtDestination.setText(ship.getDestination());
        edtCapacity.setText(String.format(Locale.UK, "%d", ship.getCapacity()));
        edtCostOf1Ton.setText(String.format(Locale.UK, "%d", ship.getCostOf1Ton()));
        swtAnchorage.setChecked(ship.isAnchorage());
        swtRefueling.setChecked(ship.isRefueling());
        swtPilot.setChecked(ship.isPilot());

        txtTotalCost.setText(String.format(Locale.UK, "Стоимость груза: %d руб.", ship.totalCost()));
    }

    // сбросить поля ввода
    public void reset(View view) {
        ship = oldShip.clone();
        setParamsForEdit(ship.getType());
    }


    // установка валидаторов (обработчиков ввода)
    private void setValidators() {
        Utils.addTextChangedListener(edtDestination, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtDestination, (s) -> !s.isEmpty(),
                        "Поле пункта назначения должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtWeight, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtWeight, (s) -> {
                            //int v = Integer.parseInt(edtCapacity.getText().toString());
                            if (s.isEmpty()) return false;
                            else return ((Integer.parseInt(s) >= 0) /*&& (Integer.parseInt(s) <= v)*/);
                        },
                        "Поле веса должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtCostOf1Ton, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtCostOf1Ton, (s) -> {
                            if (s.isEmpty()) return false;
                            else return Integer.parseInt(s) >= 0;
                        },
                        "Поле стоимость 1 тонный груза должно быть заполнено",
                        getApplicationContext())));

        Utils.addTextChangedListener(edtCapacity, (value) -> saveButton.setEnabled(
                Utils.isValidEditText(edtCapacity, (s) -> {
                            if (s.isEmpty()) return false;
                            else
                                return Integer.parseInt(s) >= Integer.parseInt(edtWeight.getText().toString());
                        },
                        "Поле грузоподъемности должно быть заполнено и не быть меньше массы груза",
                        getApplicationContext())));

    }


    // обработка клика по кнопке выхода из активности
    private void backClick() {

        Intent intent = new Intent();

        // данные, возвращаемые из активности
        intent.putExtra(Ship.class.getCanonicalName(), ship);

        // установить результат работы активности
        setResult(MainActivity.RESULT_OK, intent);

        // завершить активность
        finish();
    } // back


}