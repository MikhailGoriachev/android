package org.itstep.pd011.step160323.models;

//В эту активность передавайте данные о домашнем животном: порода,
// кличка, возраст, вес, фамилия и
// инициалы владельца, имя файла с изображением в папке assets.

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Animal implements Parcelable, Cloneable {

    private String breed;           //порода
    private String name;            //кличка
    private int age;                 //возраст
    private double weight;          //вес
    private String surname;         //фамилия
    private String owner;           //инициалы владельца
    private int image;     //id файла с изображением
    private boolean specialDiet;    //специальная диета
    private boolean voluntary;      //полу-вольное содержание

    public Animal() {
        this(Breed.BADGER.getTitle(), "Феня", 10, 12.5, "Петров", "Петрова А. Н.", Breed.BADGER.getImage(), false, false);
    }

    public Animal(String breed, String name, int age, double weight, String surname, String owner, int image, boolean specialDiet, boolean voluntary) {
        this.breed = breed;
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.surname = surname;
        this.owner = owner;
        this.image = image;
        this.specialDiet = specialDiet;
        this.voluntary = voluntary;
    }

    protected Animal(Parcel in) {
        breed = in.readString();
        name = in.readString();
        age = in.readInt();
        weight = in.readDouble();
        surname = in.readString();
        owner = in.readString();
        image = in.readInt();
        specialDiet = in.readByte() != 0;
        voluntary = in.readByte() != 0;
    }

    public static final Creator<Animal> CREATOR = new Creator<Animal>() {
        @Override
        public Animal createFromParcel(Parcel in) {
            return new Animal(in);
        }

        @Override
        public Animal[] newArray(int size) {
            return new Animal[size];
        }
    };

    public String getBreed() {
        return breed;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    public String getSurname() {
        return surname;
    }

    public String getOwner() {
        return owner;
    }

    public int getImage() {
        return image;
    }

    public boolean isSpecialDiet() {
        return specialDiet;
    }

    public boolean isVoluntary() {
        return voluntary;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void setName(String name) throws Exception {

        //проверка строки на пустоту
        if (name == null || name.isEmpty()) {
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.name = name;
    }

    public void setAge(int age) throws Exception {

        if (age < 1) {
            throw new Exception("Возраст не может быть отрицательным!");
        }
        this.age = age;
    }

    public void setWeight(double weight) throws Exception {

        if (weight < 0) {
            throw new Exception("Вес не может быть отрицательным!");
        }
        this.weight = weight;
    }

    public void setSurname(String surname) throws Exception {

        //проверка строки на пустоту
        if (surname == null || surname.isEmpty()) {
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.surname = surname;
    }

    public void setOwner(String owner) throws Exception {

        //проверка строки на пустоту
        if (owner == null || owner.isEmpty()) {
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.owner = owner;
    }

    public void setSpecialDiet(boolean specialDiet) {
        this.specialDiet = specialDiet;
    }

    public void setVoluntary(boolean voluntary) {
        this.voluntary = voluntary;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(breed);
        parcel.writeString(name);
        parcel.writeInt(age);
        parcel.writeDouble(weight);
        parcel.writeString(surname);
        parcel.writeString(owner);
        parcel.writeInt(image);
        parcel.writeByte((byte) (specialDiet ? 1 : 0));
        parcel.writeByte((byte) (voluntary ? 1 : 0));
    }

    @NonNull
    @Override
    public Animal clone() {
        try {
            return (Animal) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    @Override
    public String toString() {
        return "Animal{" +
                "breed='" + breed + '\'' +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                ", surname='" + surname + '\'' +
                ", owner='" + owner + '\'' +
                ", image='" + image + '\'' +
                ", specialDiet=" + specialDiet +
                ", voluntary=" + voluntary +
                '}';
    }
}

