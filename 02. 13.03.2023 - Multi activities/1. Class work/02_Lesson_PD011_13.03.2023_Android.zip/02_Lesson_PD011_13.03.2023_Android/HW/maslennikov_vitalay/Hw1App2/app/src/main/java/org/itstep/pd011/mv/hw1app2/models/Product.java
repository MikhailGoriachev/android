package org.itstep.pd011.mv.hw1app2.models;

public class Product {
    private String name;
    private int quantity;
    private double price;

    public Product(String name, int quantity, double price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public double calculateTotalCost() {
        return quantity * price;
    }
}
