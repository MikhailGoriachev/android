package org.itstep.pd011.step160323.Helpers;

import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

public class Utils {

    public static void showError(EditText editText, String msg){
        Snackbar snackbar = Snackbar.make(editText, msg, Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("OK", g-> {});
        snackbar.show();
    }
}
