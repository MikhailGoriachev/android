package org.itstep.pd011.step160323;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import org.itstep.pd011.step160323.activities.AnimalActivity;
import org.itstep.pd011.step160323.activities.ShipsActivity;
import org.itstep.pd011.step160323.models.Animal;
import org.itstep.pd011.step160323.models.Ship;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // коды активностей для вызова
    public static final int ID_ANIMAL_ACTIVITY = 1010,
                            ID_SHIP_ACTIVITY = 1020;

    private Animal animal;
    private Ship ship;

    TextView txvAnimal, txvShip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // данные для обработки
        animal = new Animal();
        ship = new Ship();

        txvAnimal = findViewById(R.id.txvAnimal);
        txvShip = findViewById(R.id.txvShip);

        txvAnimal.setText(animal.toString());
        txvShip.setText(ship.toString());

        findViewById(R.id.btnAnimalActivity).setOnClickListener(v->startAnimalActivity());
        findViewById(R.id.btnShipActivity).setOnClickListener(v->startShipsActivity());
    }

    // обработчик клика по кнопке вызова активности для Animals
    private void startAnimalActivity(){

        Intent intent = new Intent(this, AnimalActivity.class);

        // передача параметра в активность
        intent.putExtra(Animal.class.getCanonicalName(), animal);

        // запуск активнсти с возвратом результата
        startActivityForResult(intent,ID_ANIMAL_ACTIVITY);
    }

    // обработчик клика по кнопке вызова активности для Ships
    private void startShipsActivity(){

        Intent intent = new Intent(this, ShipsActivity.class);

        // передача параметра в активность
        intent.putExtra(Ship.class.getCanonicalName(), ship);

        // запуск активнсти с возвратом результата
        startActivityForResult(intent,ID_SHIP_ACTIVITY);
    }

    // обработчик события получения данных из другой активности
    // (функция обратного вызова)
    // requestCode - идентфикатор активности
    // resultCode - код завершения работы в активности
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK) {
            Toast.makeText(this,
                            String.format(Locale.UK, "Ошибка %d в активности с кодом %d", resultCode, requestCode),
                            Toast.LENGTH_LONG)
                    .show();
            return;
        } // if

        // при успешной работе активностей - принять данные, вывести в TextView
        switch (requestCode){
            case ID_ANIMAL_ACTIVITY:
                assert data != null;
                animal = data.getParcelableExtra(Animal.class.getCanonicalName());
                txvAnimal.setText(animal.toString());
                break;

            case ID_SHIP_ACTIVITY:
                assert data != null;
                ship = data.getParcelableExtra(Ship.class.getCanonicalName());
                txvShip.setText(ship.toString());
                break;
        }
    }

    // обработчик клика по кнопке "Выход"
    public void exitClick(View view) {
        // завершает активность, но не приложение
        finish();
    } // exitClick
}