package org.itstep.pd011.step270323.repositories;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import org.itstep.pd011.step270323.helpers.DatabaseHelper;
import org.itstep.pd011.step270323.models.Patient;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class PatientsDatabaseRepository {

    // поля для работы с БД
    private final DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    // название таблицы в БД
    static final String TABLE = "Patients";

    // названия столбцов
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_SURNAME = "surname";
    public static final String COLUMN_PATRONYMIC = "patronymic";
    public static final String COLUMN_ID_DATE_OF_BIRTH = "Date_of_Birth";
    public static final String COLUMN_ADDRESS = "address";

    @SuppressLint("SimpleDateFormat")
    private static final DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

    public  PatientsDatabaseRepository(Context context){
        dbHelper = new DatabaseHelper(context.getApplicationContext());
        dbHelper.create_db();
    } // DatabaseRepository

    public PatientsDatabaseRepository open(){
        database = dbHelper.open();
        return this;
    } // open

    public void close(){ dbHelper.close(); }

    private Cursor getAllEntries(){

        String[] columns = new String[] {COLUMN_ID, COLUMN_NAME, COLUMN_SURNAME, COLUMN_PATRONYMIC, COLUMN_ID_DATE_OF_BIRTH, COLUMN_ADDRESS};

        return  database.query(
                TABLE, columns, null, null, null,
                null, null);
    } // getAllEntries

    // метод паттерна Репозиторий
    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, TABLE);
    }

    // возвращает коллекцию пользователей из таблицы БД
    @SuppressLint("Range")
    public List<Patient> getPatients() throws ParseException {
        ArrayList<Patient> patients = new ArrayList<>();
        Cursor cursor = getAllEntries();  // запрос к БД
        if(cursor.moveToFirst()){
            do{
                // добавление в коллекцию объекта Patient
                patients.add(getPatientFromCursor(cursor));
            } while (cursor.moveToNext());
        } // if
        cursor.close();
        return patients;
    }

    // получить одного пациента по id
    @SuppressLint("Range")
    public Patient getPatient(long id) throws ParseException {
        Patient patient = null;

        String query = String.format(
                "SELECT * FROM %s WHERE %s=?",
                TABLE,
                COLUMN_ID);

        Cursor cursor = database.rawQuery(query, new String[]{String.valueOf(id)});

        // чтение данных, если они получены
        if(cursor.moveToFirst()){
            patient = getPatientFromCursor(cursor);
        } // if

        cursor.close();
        return patient;
    }

    // метод - оболочка для запроса insert
    public long insert(Patient patient){
        return database.insert(TABLE, null, getContentValues(patient));
    } // insert

    // метод - оболочка для запроса update
    public long update(Patient patient){
        return database.update(TABLE, getContentValues(patient), COLUMN_ID + "=" + patient.getId(), null);
    } // update

    private ContentValues getContentValues(Patient patient){

        ContentValues cv = new ContentValues();

        cv.put(COLUMN_SURNAME, patient.getSurname());
        cv.put(COLUMN_NAME, patient.getName());
        cv.put(COLUMN_PATRONYMIC, patient.getPatronymic());
        cv.put(COLUMN_ID_DATE_OF_BIRTH, formatter.format(patient.getDateOfBirth()));
        cv.put(COLUMN_ADDRESS,patient.getAddress());

        return cv;
    }

    @SuppressLint("Range")
    private Patient getPatientFromCursor(Cursor cursor) throws ParseException {

        return new Patient(
                cursor.getInt(cursor.getColumnIndex(COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(COLUMN_SURNAME)),
                cursor.getString(cursor.getColumnIndex(COLUMN_NAME)),
                cursor.getString(cursor.getColumnIndex(COLUMN_PATRONYMIC)),
                formatter.parse(cursor.getString(cursor.getColumnIndex(COLUMN_ID_DATE_OF_BIRTH))),
                cursor.getString(cursor.getColumnIndex(COLUMN_ADDRESS)));
    }
}
