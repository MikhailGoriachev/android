package org.itstep.pd011.step160323.models;

//В эту активность передавайте данные о домашнем животном: порода,
// кличка, возраст, вес, фамилия и
// инициалы владельца, имя файла с изображением в папке assets.

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import org.itstep.pd011.step160323.helpers.Utils;

public class Animal implements Parcelable, Cloneable {
    private Breed breed;           //порода
    private String name;            //кличка
    private int age;                 //возраст
    private double weight;          //вес
    private String owner;           //инициалы владельца
    private boolean specialDiet;    //специальная диета
    private boolean voluntary;      //полу-вольное содержание

    public Animal() {
        this(Utils.Breeds.get(0), "", 0, 0, "", false, false);
    }

    public Animal(Breed breed, String name, int age, double weight, String owner, boolean specialDiet, boolean voluntary) {
        this.breed = breed;
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.owner = owner;
        this.specialDiet = specialDiet;
        this.voluntary = voluntary;
    }


    protected Animal(Parcel in) {
        breed = in.readParcelable(Breed.class.getClassLoader());
        name = in.readString();
        age = in.readInt();
        weight = in.readDouble();
        owner = in.readString();
        specialDiet = in.readByte() != 0;
        voluntary = in.readByte() != 0;
    }

    public static final Creator<Animal> CREATOR = new Creator<Animal>() {
        @Override
        public Animal createFromParcel(Parcel in) {
            return new Animal(in);
        }

        @Override
        public Animal[] newArray(int size) {
            return new Animal[size];
        }
    };

    public Breed getBreed() {
        return breed;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    public String getOwner() {
        return owner;
    }

    public boolean isSpecialDiet() {
        return specialDiet;
    }

    public boolean isVoluntary() {
        return voluntary;
    }

    public void setBreed(Breed breed) {
        this.breed = breed;
    }

    public void setName(String name) throws Exception {

        //проверка строки на пустоту
        if (name == null || name.isEmpty()) {
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.name = name;
    }

    public void setAge(int age) throws Exception {

        if (age < 1) {
            throw new Exception("Возраст не может быть отрицательным!");
        }
        this.age = age;
    }

    public void setWeight(double weight) throws Exception {

        if (weight < 0) {
            throw new Exception("Вес не может быть отрицательным!");
        }
        this.weight = weight;
    }

    public void setOwner(String owner) throws Exception {

        //проверка строки на пустоту
        if (owner == null || owner.isEmpty()) {
            throw new Exception("Поле обязательно к заполнению!");
        }

        this.owner = owner;
    }

    public void setSpecialDiet(boolean specialDiet) {
        this.specialDiet = specialDiet;
    }

    public void setVoluntary(boolean voluntary) {
        this.voluntary = voluntary;
    }

    @NonNull
    @Override
    public Animal clone() {
        try {
            return (Animal) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeParcelable(breed, i);
        parcel.writeString(name);
        parcel.writeInt(age);
        parcel.writeDouble(weight);
        parcel.writeString(owner);
        parcel.writeByte((byte) (specialDiet ? 1 : 0));
        parcel.writeByte((byte) (voluntary ? 1 : 0));
    }
}

